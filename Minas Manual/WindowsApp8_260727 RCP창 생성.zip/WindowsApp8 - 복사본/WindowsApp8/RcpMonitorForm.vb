﻿Public Class RcpMonitorForm

    Public Sub UpdateRcpLabels(lotRcps As String(), slotRcps As String(,))
        If Me.InvokeRequired Then
            Me.Invoke(New MethodInvoker(Sub() UpdateRcpLabels(lotRcps, slotRcps)))
            Return
        End If

        For roomNo As Integer = 1 To 4
            SetLabelText($"lblRoom{roomNo}LotRcp", lotRcps(roomNo))

            For slotNo As Integer = 1 To 11
                SetLabelText($"lblRoom{roomNo}SlotRcp{slotNo}", slotRcps(roomNo, slotNo))
            Next
        Next
    End Sub

    Private Sub SetLabelText(labelName As String, value As String)
        Dim foundControls() As Control = Me.Controls.Find(labelName, True)

        If foundControls IsNot Nothing AndAlso foundControls.Length > 0 Then
            foundControls(0).Text = If(value, "")
        End If
    End Sub

End Class
﻿Partial Public Class Form1


    ''' <summary>
    ''' [테스트 버튼] LD CST OFF 조건을 수동으로 발생시켜 LD GLS Count Reset 동작을 확인합니다.
    ''' 실제 운영에서는 PLC Bit 조건 성립 시 HandleLDCstOffDetected("PLC ...")를 호출합니다.
    ''' </summary>
    Private Sub btnTestLDReset_Click(sender As Object, e As EventArgs) Handles btnTestLDReset.Click
        HandleLDCstOffDetected("TEST BUTTON")
    End Sub

    ''' <summary>
    ''' [테스트 버튼] PLC Bit Rising Edge가 1회 발생한 상황을 수동으로 테스트합니다.
    ''' 
    ''' 실제 PLC Bit 신호 판정 로직은 추후 별도로 구현할 예정이므로,
    ''' 현재 버튼은 PLC Bit가 OFF에서 ON으로 1회 변했다고 가정하고
    ''' IncreaseULDGLSCount()만 호출합니다.
    ''' 
    ''' 테스트 결과:
    '''   - 내부 uldGlsCount 값이 1 증가합니다.
    '''   - 화면의 ULD GLS Count 표시값도 증가된 값으로 갱신됩니다.
    ''' </summary>
    Private Sub btnTestULDIncrease_Click(sender As Object, e As EventArgs) Handles btnTestULDIncrease.Click
        IncreaseULDGLSCount()
        If logger IsNot Nothing Then
            logger.WriteLog("[TEST] PLC Bit Rising Edge 테스트 버튼 클릭 -> ULD GLS Count +1")
        End If
    End Sub



    ''' <summary>
    ''' ULD GLS Count를 0으로 초기화하고 화면 표시값도 0으로 갱신합니다.
    ''' 
    ''' 추후 ULD CST 신호가 OFF 되는 조건을 구현할 때,
    ''' 해당 조건문 내부에서 이 함수를 호출하면 됩니다.
    ''' 
    ''' 현재 요청 범위에서는 ULD CST OFF 판정 로직은 작성하지 않고,
    ''' 외부에서 호출 가능한 리셋 함수만 준비합니다.
    ''' </summary>
    ''' 
    Private Sub btnTestULDRST_Click(sender As Object, e As EventArgs) Handles btnTestULDRST.Click
        SetULDGLSCount(0)
        If logger IsNot Nothing Then
            logger.WriteLog("[TEST] PLC Bit ULD CST OFF 테스트 버튼 클릭 -> ULD CST OFF")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        RegisterOutputPortStart(1)
        TestCompletedOutputPortNo = 1
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RegisterOutputPortStart(2)
        TestCompletedOutputPortNo = 2
    End Sub

End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RcpMonitorForm
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblRoom1LotRcp = New System.Windows.Forms.Label()
        Me.lblRoom2LotRcp = New System.Windows.Forms.Label()
        Me.lblRoom3LotRcp = New System.Windows.Forms.Label()
        Me.lblRoom4LotRcp = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp1 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp2 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp3 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp4 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp5 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp6 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp7 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp8 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp9 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp10 = New System.Windows.Forms.Label()
        Me.lblRoom1SlotRcp11 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp11 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp10 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp9 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp8 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp7 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp6 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp5 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp4 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp3 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp2 = New System.Windows.Forms.Label()
        Me.lblRoom2SlotRcp1 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp11 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp10 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp9 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp8 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp7 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp6 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp5 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp4 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp3 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp2 = New System.Windows.Forms.Label()
        Me.lblRoom3SlotRcp1 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp11 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp10 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp9 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp8 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp7 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp6 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp5 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp4 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp3 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp2 = New System.Windows.Forms.Label()
        Me.lblRoom4SlotRcp1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblRoom1LotRcp
        '
        Me.lblRoom1LotRcp.AutoSize = True
        Me.lblRoom1LotRcp.Location = New System.Drawing.Point(178, 70)
        Me.lblRoom1LotRcp.Name = "lblRoom1LotRcp"
        Me.lblRoom1LotRcp.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1LotRcp.TabIndex = 0
        Me.lblRoom1LotRcp.Text = "Label1"
        '
        'lblRoom2LotRcp
        '
        Me.lblRoom2LotRcp.AutoSize = True
        Me.lblRoom2LotRcp.Location = New System.Drawing.Point(298, 70)
        Me.lblRoom2LotRcp.Name = "lblRoom2LotRcp"
        Me.lblRoom2LotRcp.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2LotRcp.TabIndex = 1
        Me.lblRoom2LotRcp.Text = "Label1"
        '
        'lblRoom3LotRcp
        '
        Me.lblRoom3LotRcp.AutoSize = True
        Me.lblRoom3LotRcp.Location = New System.Drawing.Point(446, 70)
        Me.lblRoom3LotRcp.Name = "lblRoom3LotRcp"
        Me.lblRoom3LotRcp.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3LotRcp.TabIndex = 2
        Me.lblRoom3LotRcp.Text = "Label1"
        '
        'lblRoom4LotRcp
        '
        Me.lblRoom4LotRcp.AutoSize = True
        Me.lblRoom4LotRcp.Location = New System.Drawing.Point(579, 70)
        Me.lblRoom4LotRcp.Name = "lblRoom4LotRcp"
        Me.lblRoom4LotRcp.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4LotRcp.TabIndex = 3
        Me.lblRoom4LotRcp.Text = "Label1"
        '
        'lblRoom1SlotRcp1
        '
        Me.lblRoom1SlotRcp1.AutoSize = True
        Me.lblRoom1SlotRcp1.Location = New System.Drawing.Point(178, 107)
        Me.lblRoom1SlotRcp1.Name = "lblRoom1SlotRcp1"
        Me.lblRoom1SlotRcp1.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp1.TabIndex = 4
        Me.lblRoom1SlotRcp1.Text = "Label1"
        '
        'lblRoom1SlotRcp2
        '
        Me.lblRoom1SlotRcp2.AutoSize = True
        Me.lblRoom1SlotRcp2.Location = New System.Drawing.Point(178, 130)
        Me.lblRoom1SlotRcp2.Name = "lblRoom1SlotRcp2"
        Me.lblRoom1SlotRcp2.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp2.TabIndex = 5
        Me.lblRoom1SlotRcp2.Text = "Label1"
        '
        'lblRoom1SlotRcp3
        '
        Me.lblRoom1SlotRcp3.AutoSize = True
        Me.lblRoom1SlotRcp3.Location = New System.Drawing.Point(178, 153)
        Me.lblRoom1SlotRcp3.Name = "lblRoom1SlotRcp3"
        Me.lblRoom1SlotRcp3.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp3.TabIndex = 6
        Me.lblRoom1SlotRcp3.Text = "Label1"
        '
        'lblRoom1SlotRcp4
        '
        Me.lblRoom1SlotRcp4.AutoSize = True
        Me.lblRoom1SlotRcp4.Location = New System.Drawing.Point(178, 176)
        Me.lblRoom1SlotRcp4.Name = "lblRoom1SlotRcp4"
        Me.lblRoom1SlotRcp4.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp4.TabIndex = 7
        Me.lblRoom1SlotRcp4.Text = "Label1"
        '
        'lblRoom1SlotRcp5
        '
        Me.lblRoom1SlotRcp5.AutoSize = True
        Me.lblRoom1SlotRcp5.Location = New System.Drawing.Point(178, 199)
        Me.lblRoom1SlotRcp5.Name = "lblRoom1SlotRcp5"
        Me.lblRoom1SlotRcp5.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp5.TabIndex = 8
        Me.lblRoom1SlotRcp5.Text = "Label1"
        '
        'lblRoom1SlotRcp6
        '
        Me.lblRoom1SlotRcp6.AutoSize = True
        Me.lblRoom1SlotRcp6.Location = New System.Drawing.Point(178, 222)
        Me.lblRoom1SlotRcp6.Name = "lblRoom1SlotRcp6"
        Me.lblRoom1SlotRcp6.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp6.TabIndex = 9
        Me.lblRoom1SlotRcp6.Text = "Label1"
        '
        'lblRoom1SlotRcp7
        '
        Me.lblRoom1SlotRcp7.AutoSize = True
        Me.lblRoom1SlotRcp7.Location = New System.Drawing.Point(178, 245)
        Me.lblRoom1SlotRcp7.Name = "lblRoom1SlotRcp7"
        Me.lblRoom1SlotRcp7.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp7.TabIndex = 10
        Me.lblRoom1SlotRcp7.Text = "Label1"
        '
        'lblRoom1SlotRcp8
        '
        Me.lblRoom1SlotRcp8.AutoSize = True
        Me.lblRoom1SlotRcp8.Location = New System.Drawing.Point(178, 268)
        Me.lblRoom1SlotRcp8.Name = "lblRoom1SlotRcp8"
        Me.lblRoom1SlotRcp8.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp8.TabIndex = 11
        Me.lblRoom1SlotRcp8.Text = "Label1"
        '
        'lblRoom1SlotRcp9
        '
        Me.lblRoom1SlotRcp9.AutoSize = True
        Me.lblRoom1SlotRcp9.Location = New System.Drawing.Point(178, 291)
        Me.lblRoom1SlotRcp9.Name = "lblRoom1SlotRcp9"
        Me.lblRoom1SlotRcp9.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp9.TabIndex = 12
        Me.lblRoom1SlotRcp9.Text = "Label1"
        '
        'lblRoom1SlotRcp10
        '
        Me.lblRoom1SlotRcp10.AutoSize = True
        Me.lblRoom1SlotRcp10.Location = New System.Drawing.Point(178, 314)
        Me.lblRoom1SlotRcp10.Name = "lblRoom1SlotRcp10"
        Me.lblRoom1SlotRcp10.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp10.TabIndex = 13
        Me.lblRoom1SlotRcp10.Text = "Label1"
        '
        'lblRoom1SlotRcp11
        '
        Me.lblRoom1SlotRcp11.AutoSize = True
        Me.lblRoom1SlotRcp11.Location = New System.Drawing.Point(178, 337)
        Me.lblRoom1SlotRcp11.Name = "lblRoom1SlotRcp11"
        Me.lblRoom1SlotRcp11.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom1SlotRcp11.TabIndex = 14
        Me.lblRoom1SlotRcp11.Text = "Label1"
        '
        'lblRoom2SlotRcp11
        '
        Me.lblRoom2SlotRcp11.AutoSize = True
        Me.lblRoom2SlotRcp11.Location = New System.Drawing.Point(298, 337)
        Me.lblRoom2SlotRcp11.Name = "lblRoom2SlotRcp11"
        Me.lblRoom2SlotRcp11.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp11.TabIndex = 25
        Me.lblRoom2SlotRcp11.Text = "Label1"
        '
        'lblRoom2SlotRcp10
        '
        Me.lblRoom2SlotRcp10.AutoSize = True
        Me.lblRoom2SlotRcp10.Location = New System.Drawing.Point(298, 314)
        Me.lblRoom2SlotRcp10.Name = "lblRoom2SlotRcp10"
        Me.lblRoom2SlotRcp10.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp10.TabIndex = 24
        Me.lblRoom2SlotRcp10.Text = "Label1"
        '
        'lblRoom2SlotRcp9
        '
        Me.lblRoom2SlotRcp9.AutoSize = True
        Me.lblRoom2SlotRcp9.Location = New System.Drawing.Point(298, 291)
        Me.lblRoom2SlotRcp9.Name = "lblRoom2SlotRcp9"
        Me.lblRoom2SlotRcp9.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp9.TabIndex = 23
        Me.lblRoom2SlotRcp9.Text = "Label1"
        '
        'lblRoom2SlotRcp8
        '
        Me.lblRoom2SlotRcp8.AutoSize = True
        Me.lblRoom2SlotRcp8.Location = New System.Drawing.Point(298, 268)
        Me.lblRoom2SlotRcp8.Name = "lblRoom2SlotRcp8"
        Me.lblRoom2SlotRcp8.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp8.TabIndex = 22
        Me.lblRoom2SlotRcp8.Text = "Label1"
        '
        'lblRoom2SlotRcp7
        '
        Me.lblRoom2SlotRcp7.AutoSize = True
        Me.lblRoom2SlotRcp7.Location = New System.Drawing.Point(298, 245)
        Me.lblRoom2SlotRcp7.Name = "lblRoom2SlotRcp7"
        Me.lblRoom2SlotRcp7.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp7.TabIndex = 21
        Me.lblRoom2SlotRcp7.Text = "Label1"
        '
        'lblRoom2SlotRcp6
        '
        Me.lblRoom2SlotRcp6.AutoSize = True
        Me.lblRoom2SlotRcp6.Location = New System.Drawing.Point(298, 222)
        Me.lblRoom2SlotRcp6.Name = "lblRoom2SlotRcp6"
        Me.lblRoom2SlotRcp6.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp6.TabIndex = 20
        Me.lblRoom2SlotRcp6.Text = "Label1"
        '
        'lblRoom2SlotRcp5
        '
        Me.lblRoom2SlotRcp5.AutoSize = True
        Me.lblRoom2SlotRcp5.Location = New System.Drawing.Point(298, 199)
        Me.lblRoom2SlotRcp5.Name = "lblRoom2SlotRcp5"
        Me.lblRoom2SlotRcp5.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp5.TabIndex = 19
        Me.lblRoom2SlotRcp5.Text = "Label1"
        '
        'lblRoom2SlotRcp4
        '
        Me.lblRoom2SlotRcp4.AutoSize = True
        Me.lblRoom2SlotRcp4.Location = New System.Drawing.Point(298, 176)
        Me.lblRoom2SlotRcp4.Name = "lblRoom2SlotRcp4"
        Me.lblRoom2SlotRcp4.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp4.TabIndex = 18
        Me.lblRoom2SlotRcp4.Text = "Label1"
        '
        'lblRoom2SlotRcp3
        '
        Me.lblRoom2SlotRcp3.AutoSize = True
        Me.lblRoom2SlotRcp3.Location = New System.Drawing.Point(298, 153)
        Me.lblRoom2SlotRcp3.Name = "lblRoom2SlotRcp3"
        Me.lblRoom2SlotRcp3.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp3.TabIndex = 17
        Me.lblRoom2SlotRcp3.Text = "Label1"
        '
        'lblRoom2SlotRcp2
        '
        Me.lblRoom2SlotRcp2.AutoSize = True
        Me.lblRoom2SlotRcp2.Location = New System.Drawing.Point(298, 130)
        Me.lblRoom2SlotRcp2.Name = "lblRoom2SlotRcp2"
        Me.lblRoom2SlotRcp2.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom2SlotRcp2.TabIndex = 16
        Me.lblRoom2SlotRcp2.Text = "Label1"
        '
        'lblRoom2SlotRcp1
        '
        Me.lblRoom2SlotRcp1.AutoSize = True
        Me.lblRoom2SlotRcp1.Location = New System.Drawing.Point(298, 107)
        Me.lblRoom2SlotRcp1.Name = "lblRoom2SlotRcp1"
        Me.lblRoom2SlotRcp1.Size = New System.Drawing.Size(48, 12)
        Me.lblRoom2SlotRcp1.TabIndex = 15
        Me.lblRoom2SlotRcp1.Text = "Label22"
        '
        'lblRoom3SlotRcp11
        '
        Me.lblRoom3SlotRcp11.AutoSize = True
        Me.lblRoom3SlotRcp11.Location = New System.Drawing.Point(446, 337)
        Me.lblRoom3SlotRcp11.Name = "lblRoom3SlotRcp11"
        Me.lblRoom3SlotRcp11.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp11.TabIndex = 36
        Me.lblRoom3SlotRcp11.Text = "Label1"
        '
        'lblRoom3SlotRcp10
        '
        Me.lblRoom3SlotRcp10.AutoSize = True
        Me.lblRoom3SlotRcp10.Location = New System.Drawing.Point(446, 314)
        Me.lblRoom3SlotRcp10.Name = "lblRoom3SlotRcp10"
        Me.lblRoom3SlotRcp10.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp10.TabIndex = 35
        Me.lblRoom3SlotRcp10.Text = "Label1"
        '
        'lblRoom3SlotRcp9
        '
        Me.lblRoom3SlotRcp9.AutoSize = True
        Me.lblRoom3SlotRcp9.Location = New System.Drawing.Point(446, 291)
        Me.lblRoom3SlotRcp9.Name = "lblRoom3SlotRcp9"
        Me.lblRoom3SlotRcp9.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp9.TabIndex = 34
        Me.lblRoom3SlotRcp9.Text = "Label1"
        '
        'lblRoom3SlotRcp8
        '
        Me.lblRoom3SlotRcp8.AutoSize = True
        Me.lblRoom3SlotRcp8.Location = New System.Drawing.Point(446, 268)
        Me.lblRoom3SlotRcp8.Name = "lblRoom3SlotRcp8"
        Me.lblRoom3SlotRcp8.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp8.TabIndex = 33
        Me.lblRoom3SlotRcp8.Text = "Label1"
        '
        'lblRoom3SlotRcp7
        '
        Me.lblRoom3SlotRcp7.AutoSize = True
        Me.lblRoom3SlotRcp7.Location = New System.Drawing.Point(446, 245)
        Me.lblRoom3SlotRcp7.Name = "lblRoom3SlotRcp7"
        Me.lblRoom3SlotRcp7.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp7.TabIndex = 32
        Me.lblRoom3SlotRcp7.Text = "Label1"
        '
        'lblRoom3SlotRcp6
        '
        Me.lblRoom3SlotRcp6.AutoSize = True
        Me.lblRoom3SlotRcp6.Location = New System.Drawing.Point(446, 222)
        Me.lblRoom3SlotRcp6.Name = "lblRoom3SlotRcp6"
        Me.lblRoom3SlotRcp6.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp6.TabIndex = 31
        Me.lblRoom3SlotRcp6.Text = "Label1"
        '
        'lblRoom3SlotRcp5
        '
        Me.lblRoom3SlotRcp5.AutoSize = True
        Me.lblRoom3SlotRcp5.Location = New System.Drawing.Point(446, 199)
        Me.lblRoom3SlotRcp5.Name = "lblRoom3SlotRcp5"
        Me.lblRoom3SlotRcp5.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp5.TabIndex = 30
        Me.lblRoom3SlotRcp5.Text = "Label1"
        '
        'lblRoom3SlotRcp4
        '
        Me.lblRoom3SlotRcp4.AutoSize = True
        Me.lblRoom3SlotRcp4.Location = New System.Drawing.Point(446, 176)
        Me.lblRoom3SlotRcp4.Name = "lblRoom3SlotRcp4"
        Me.lblRoom3SlotRcp4.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp4.TabIndex = 29
        Me.lblRoom3SlotRcp4.Text = "Label1"
        '
        'lblRoom3SlotRcp3
        '
        Me.lblRoom3SlotRcp3.AutoSize = True
        Me.lblRoom3SlotRcp3.Location = New System.Drawing.Point(446, 153)
        Me.lblRoom3SlotRcp3.Name = "lblRoom3SlotRcp3"
        Me.lblRoom3SlotRcp3.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp3.TabIndex = 28
        Me.lblRoom3SlotRcp3.Text = "Label1"
        '
        'lblRoom3SlotRcp2
        '
        Me.lblRoom3SlotRcp2.AutoSize = True
        Me.lblRoom3SlotRcp2.Location = New System.Drawing.Point(446, 130)
        Me.lblRoom3SlotRcp2.Name = "lblRoom3SlotRcp2"
        Me.lblRoom3SlotRcp2.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom3SlotRcp2.TabIndex = 27
        Me.lblRoom3SlotRcp2.Text = "Label1"
        '
        'lblRoom3SlotRcp1
        '
        Me.lblRoom3SlotRcp1.AutoSize = True
        Me.lblRoom3SlotRcp1.Location = New System.Drawing.Point(446, 107)
        Me.lblRoom3SlotRcp1.Name = "lblRoom3SlotRcp1"
        Me.lblRoom3SlotRcp1.Size = New System.Drawing.Size(48, 12)
        Me.lblRoom3SlotRcp1.TabIndex = 26
        Me.lblRoom3SlotRcp1.Text = "Label33"
        '
        'lblRoom4SlotRcp11
        '
        Me.lblRoom4SlotRcp11.AutoSize = True
        Me.lblRoom4SlotRcp11.Location = New System.Drawing.Point(579, 337)
        Me.lblRoom4SlotRcp11.Name = "lblRoom4SlotRcp11"
        Me.lblRoom4SlotRcp11.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp11.TabIndex = 47
        Me.lblRoom4SlotRcp11.Text = "Label1"
        '
        'lblRoom4SlotRcp10
        '
        Me.lblRoom4SlotRcp10.AutoSize = True
        Me.lblRoom4SlotRcp10.Location = New System.Drawing.Point(579, 314)
        Me.lblRoom4SlotRcp10.Name = "lblRoom4SlotRcp10"
        Me.lblRoom4SlotRcp10.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp10.TabIndex = 46
        Me.lblRoom4SlotRcp10.Text = "Label1"
        '
        'lblRoom4SlotRcp9
        '
        Me.lblRoom4SlotRcp9.AutoSize = True
        Me.lblRoom4SlotRcp9.Location = New System.Drawing.Point(579, 291)
        Me.lblRoom4SlotRcp9.Name = "lblRoom4SlotRcp9"
        Me.lblRoom4SlotRcp9.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp9.TabIndex = 45
        Me.lblRoom4SlotRcp9.Text = "Label1"
        '
        'lblRoom4SlotRcp8
        '
        Me.lblRoom4SlotRcp8.AutoSize = True
        Me.lblRoom4SlotRcp8.Location = New System.Drawing.Point(579, 268)
        Me.lblRoom4SlotRcp8.Name = "lblRoom4SlotRcp8"
        Me.lblRoom4SlotRcp8.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp8.TabIndex = 44
        Me.lblRoom4SlotRcp8.Text = "Label1"
        '
        'lblRoom4SlotRcp7
        '
        Me.lblRoom4SlotRcp7.AutoSize = True
        Me.lblRoom4SlotRcp7.Location = New System.Drawing.Point(579, 245)
        Me.lblRoom4SlotRcp7.Name = "lblRoom4SlotRcp7"
        Me.lblRoom4SlotRcp7.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp7.TabIndex = 43
        Me.lblRoom4SlotRcp7.Text = "Label1"
        '
        'lblRoom4SlotRcp6
        '
        Me.lblRoom4SlotRcp6.AutoSize = True
        Me.lblRoom4SlotRcp6.Location = New System.Drawing.Point(579, 222)
        Me.lblRoom4SlotRcp6.Name = "lblRoom4SlotRcp6"
        Me.lblRoom4SlotRcp6.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp6.TabIndex = 42
        Me.lblRoom4SlotRcp6.Text = "Label1"
        '
        'lblRoom4SlotRcp5
        '
        Me.lblRoom4SlotRcp5.AutoSize = True
        Me.lblRoom4SlotRcp5.Location = New System.Drawing.Point(579, 199)
        Me.lblRoom4SlotRcp5.Name = "lblRoom4SlotRcp5"
        Me.lblRoom4SlotRcp5.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp5.TabIndex = 41
        Me.lblRoom4SlotRcp5.Text = "Label1"
        '
        'lblRoom4SlotRcp4
        '
        Me.lblRoom4SlotRcp4.AutoSize = True
        Me.lblRoom4SlotRcp4.Location = New System.Drawing.Point(579, 176)
        Me.lblRoom4SlotRcp4.Name = "lblRoom4SlotRcp4"
        Me.lblRoom4SlotRcp4.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp4.TabIndex = 40
        Me.lblRoom4SlotRcp4.Text = "Label1"
        '
        'lblRoom4SlotRcp3
        '
        Me.lblRoom4SlotRcp3.AutoSize = True
        Me.lblRoom4SlotRcp3.Location = New System.Drawing.Point(579, 153)
        Me.lblRoom4SlotRcp3.Name = "lblRoom4SlotRcp3"
        Me.lblRoom4SlotRcp3.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp3.TabIndex = 39
        Me.lblRoom4SlotRcp3.Text = "Label1"
        '
        'lblRoom4SlotRcp2
        '
        Me.lblRoom4SlotRcp2.AutoSize = True
        Me.lblRoom4SlotRcp2.Location = New System.Drawing.Point(579, 130)
        Me.lblRoom4SlotRcp2.Name = "lblRoom4SlotRcp2"
        Me.lblRoom4SlotRcp2.Size = New System.Drawing.Size(42, 12)
        Me.lblRoom4SlotRcp2.TabIndex = 38
        Me.lblRoom4SlotRcp2.Text = "Label1"
        '
        'lblRoom4SlotRcp1
        '
        Me.lblRoom4SlotRcp1.AutoSize = True
        Me.lblRoom4SlotRcp1.Location = New System.Drawing.Point(579, 107)
        Me.lblRoom4SlotRcp1.Name = "lblRoom4SlotRcp1"
        Me.lblRoom4SlotRcp1.Size = New System.Drawing.Size(48, 12)
        Me.lblRoom4SlotRcp1.TabIndex = 37
        Me.lblRoom4SlotRcp1.Text = "Label44"
        '
        'RcpMonitorForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblRoom4SlotRcp11)
        Me.Controls.Add(Me.lblRoom4SlotRcp10)
        Me.Controls.Add(Me.lblRoom4SlotRcp9)
        Me.Controls.Add(Me.lblRoom4SlotRcp8)
        Me.Controls.Add(Me.lblRoom4SlotRcp7)
        Me.Controls.Add(Me.lblRoom4SlotRcp6)
        Me.Controls.Add(Me.lblRoom4SlotRcp5)
        Me.Controls.Add(Me.lblRoom4SlotRcp4)
        Me.Controls.Add(Me.lblRoom4SlotRcp3)
        Me.Controls.Add(Me.lblRoom4SlotRcp2)
        Me.Controls.Add(Me.lblRoom4SlotRcp1)
        Me.Controls.Add(Me.lblRoom3SlotRcp11)
        Me.Controls.Add(Me.lblRoom3SlotRcp10)
        Me.Controls.Add(Me.lblRoom3SlotRcp9)
        Me.Controls.Add(Me.lblRoom3SlotRcp8)
        Me.Controls.Add(Me.lblRoom3SlotRcp7)
        Me.Controls.Add(Me.lblRoom3SlotRcp6)
        Me.Controls.Add(Me.lblRoom3SlotRcp5)
        Me.Controls.Add(Me.lblRoom3SlotRcp4)
        Me.Controls.Add(Me.lblRoom3SlotRcp3)
        Me.Controls.Add(Me.lblRoom3SlotRcp2)
        Me.Controls.Add(Me.lblRoom3SlotRcp1)
        Me.Controls.Add(Me.lblRoom2SlotRcp11)
        Me.Controls.Add(Me.lblRoom2SlotRcp10)
        Me.Controls.Add(Me.lblRoom2SlotRcp9)
        Me.Controls.Add(Me.lblRoom2SlotRcp8)
        Me.Controls.Add(Me.lblRoom2SlotRcp7)
        Me.Controls.Add(Me.lblRoom2SlotRcp6)
        Me.Controls.Add(Me.lblRoom2SlotRcp5)
        Me.Controls.Add(Me.lblRoom2SlotRcp4)
        Me.Controls.Add(Me.lblRoom2SlotRcp3)
        Me.Controls.Add(Me.lblRoom2SlotRcp2)
        Me.Controls.Add(Me.lblRoom2SlotRcp1)
        Me.Controls.Add(Me.lblRoom1SlotRcp11)
        Me.Controls.Add(Me.lblRoom1SlotRcp10)
        Me.Controls.Add(Me.lblRoom1SlotRcp9)
        Me.Controls.Add(Me.lblRoom1SlotRcp8)
        Me.Controls.Add(Me.lblRoom1SlotRcp7)
        Me.Controls.Add(Me.lblRoom1SlotRcp6)
        Me.Controls.Add(Me.lblRoom1SlotRcp5)
        Me.Controls.Add(Me.lblRoom1SlotRcp4)
        Me.Controls.Add(Me.lblRoom1SlotRcp3)
        Me.Controls.Add(Me.lblRoom1SlotRcp2)
        Me.Controls.Add(Me.lblRoom1SlotRcp1)
        Me.Controls.Add(Me.lblRoom4LotRcp)
        Me.Controls.Add(Me.lblRoom3LotRcp)
        Me.Controls.Add(Me.lblRoom2LotRcp)
        Me.Controls.Add(Me.lblRoom1LotRcp)
        Me.Name = "RcpMonitorForm"
        Me.Text = "RcpMonitorForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblRoom1LotRcp As Label
    Friend WithEvents lblRoom2LotRcp As Label
    Friend WithEvents lblRoom3LotRcp As Label
    Friend WithEvents lblRoom4LotRcp As Label
    Friend WithEvents lblRoom1SlotRcp1 As Label
    Friend WithEvents lblRoom1SlotRcp2 As Label
    Friend WithEvents lblRoom1SlotRcp3 As Label
    Friend WithEvents lblRoom1SlotRcp4 As Label
    Friend WithEvents lblRoom1SlotRcp5 As Label
    Friend WithEvents lblRoom1SlotRcp6 As Label
    Friend WithEvents lblRoom1SlotRcp7 As Label
    Friend WithEvents lblRoom1SlotRcp8 As Label
    Friend WithEvents lblRoom1SlotRcp9 As Label
    Friend WithEvents lblRoom1SlotRcp10 As Label
    Friend WithEvents lblRoom1SlotRcp11 As Label
    Friend WithEvents lblRoom2SlotRcp11 As Label
    Friend WithEvents lblRoom2SlotRcp10 As Label
    Friend WithEvents lblRoom2SlotRcp9 As Label
    Friend WithEvents lblRoom2SlotRcp8 As Label
    Friend WithEvents lblRoom2SlotRcp7 As Label
    Friend WithEvents lblRoom2SlotRcp6 As Label
    Friend WithEvents lblRoom2SlotRcp5 As Label
    Friend WithEvents lblRoom2SlotRcp4 As Label
    Friend WithEvents lblRoom2SlotRcp3 As Label
    Friend WithEvents lblRoom2SlotRcp2 As Label
    Friend WithEvents lblRoom2SlotRcp1 As Label
    Friend WithEvents lblRoom3SlotRcp11 As Label
    Friend WithEvents lblRoom3SlotRcp10 As Label
    Friend WithEvents lblRoom3SlotRcp9 As Label
    Friend WithEvents lblRoom3SlotRcp8 As Label
    Friend WithEvents lblRoom3SlotRcp7 As Label
    Friend WithEvents lblRoom3SlotRcp6 As Label
    Friend WithEvents lblRoom3SlotRcp5 As Label
    Friend WithEvents lblRoom3SlotRcp4 As Label
    Friend WithEvents lblRoom3SlotRcp3 As Label
    Friend WithEvents lblRoom3SlotRcp2 As Label
    Friend WithEvents lblRoom3SlotRcp1 As Label
    Friend WithEvents lblRoom4SlotRcp11 As Label
    Friend WithEvents lblRoom4SlotRcp10 As Label
    Friend WithEvents lblRoom4SlotRcp9 As Label
    Friend WithEvents lblRoom4SlotRcp8 As Label
    Friend WithEvents lblRoom4SlotRcp7 As Label
    Friend WithEvents lblRoom4SlotRcp6 As Label
    Friend WithEvents lblRoom4SlotRcp5 As Label
    Friend WithEvents lblRoom4SlotRcp4 As Label
    Friend WithEvents lblRoom4SlotRcp3 As Label
    Friend WithEvents lblRoom4SlotRcp2 As Label
    Friend WithEvents lblRoom4SlotRcp1 As Label
End Class

﻿Partial Public Class Form1

    ' ============================================================================
    ' [신규] PLC Bit 상태 변화 감지용 변수
    ' ============================================================================
    ' LD CST OFF Bit의 이전 상태를 저장합니다.
    ' PLC Bit가 계속 1로 유지되는 동안 ResetLDGLSCount()가 반복 호출되는 것을 방지하기 위해 사용합니다.
    ' False = 직전 읽기에서 LD CST OFF 조건이 아니었음
    ' True  = 직전 읽기에서 LD CST OFF 조건이었음
    Private previousLDCstOffSignal As Boolean = False


    ''' <summary>
    ''' LD GLS Count를 0으로 초기화하고 화면 표시값도 0으로 갱신합니다.
    ''' 
    ''' 추후 LD CST 신호가 OFF 되는 조건을 구현할 때,
    ''' 해당 조건문 내부에서 이 함수를 호출하면 됩니다.
    ''' 
    ''' 현재 요청 범위에서는 LD CST OFF 판정 로직은 작성하지 않고,
    ''' 외부에서 호출 가능한 리셋 함수만 준비합니다.
    ''' </summary>
    Private Sub ResetLDGLSCount()
        SetLDGLSCount(0)
    End Sub

    ''' <summary>
    ''' ULD GLS Count를 1 증가시키고 화면 표시값을 갱신합니다.
    ''' 
    ''' 추후 PLC Bit 신호가 1회 발생할 때마다 이 함수를 한 번 호출하면 됩니다.
    ''' 예: PLC Bit Rising Edge 감지 시 IncreaseULDGLSCount()
    ''' 
    ''' 실제 PLC Bit 판정 로직은 이 함수에 넣지 않습니다.
    ''' 이 함수는 "이미 신호가 발생했다고 판단된 후" 호출되는 카운트 증가 전용 함수입니다.
    ''' </summary>
    Private Sub IncreaseULDGLSCount()
        SetULDGLSCount(uldGlsCount + 1)
    End Sub


    ''' <summary>
    ''' LD CST OFF 조건이 실제로 발생했을 때 실행할 공통 처리 함수입니다.
    ''' 
    ''' 이 함수는 테스트 버튼에서도 호출하고,
    ''' 추후 PLC Bit 조건이 성립했을 때도 동일하게 호출합니다.
    ''' 
    ''' sourceText:
    '''   이 처리가 어디서 발생했는지 로그에 남기기 위한 문자열입니다.
    '''   예: "TEST BUTTON", "PLC M1"
    ''' </summary>
    Private Sub HandleLDCstOffDetected(sourceText As String)
        ResetLDGLSCount()
        If logger IsNot Nothing Then
            logger.WriteLog($"[{sourceText}] LD CST OFF 감지 -> LD GLS Count Reset")
        End If
    End Sub


    ''' <summary>
    ''' PLC에서 읽어온 LD CST OFF Bit 상태를 처리합니다.
    ''' 
    ''' currentLDCstOffSignal:
    '''   PLC에서 현재 읽은 LD CST OFF 조건 상태입니다.
    '''   True  = LD CST OFF 조건 성립
    '''   False = LD CST OFF 조건 미성립
    ''' 
    ''' 중요:
    '''   PLC Bit가 1인 동안 계속 Reset이 반복되지 않도록,
    '''   False -> True로 바뀌는 순간에만 HandleLDCstOffDetected()를 호출합니다.
    ''' </summary>
    Private Sub ProcessLDCstOffSignal(currentLDCstOffSignal As Boolean)
        If previousLDCstOffSignal = False AndAlso currentLDCstOffSignal = True Then
            HandleLDCstOffDetected("PLC 접점")
        End If
        previousLDCstOffSignal = currentLDCstOffSignal
    End Sub

End Class
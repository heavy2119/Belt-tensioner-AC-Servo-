﻿Partial Public Class Form1

    ' ============================================================================
    ' S7F83 4방 + 출력포트 착공 순서 관리
    ' ============================================================================
    Private Enum S7F83RoomState
        Empty = 0
        WaitingOutputPort = 1
        AssignedToOutputPort = 2
    End Enum

    Private Enum OutputPortState
        Empty = 0
        WaitingS7F83 = 1
        AssignedS7F83 = 2
    End Enum

    Private Class S7F83Room
        Public RoomNo As Integer
        Public State As S7F83RoomState = S7F83RoomState.Empty
        Public AssignedOutputPortNo As Integer = 0

        Public LotData As LotInfoData
        Public GlassList As New List(Of GlassInfoData)

        Public SavedOrder As Integer = 0
        Public SavedAt As DateTime

        Public Sub Clear()
            State = S7F83RoomState.Empty
            AssignedOutputPortNo = 0
            LotData = New LotInfoData()
            GlassList = New List(Of GlassInfoData)()
            SavedOrder = 0
            SavedAt = DateTime.MinValue
        End Sub
    End Class

    Private Class OutputPortWork
        Public PortNo As Integer
        Public State As OutputPortState = OutputPortState.Empty
        Public WaitingOrder As Integer = 0
        Public AssignedRoomNo As Integer = 0

        Public Sub Clear()
            State = OutputPortState.Empty
            WaitingOrder = 0
            AssignedRoomNo = 0
        End Sub
    End Class

    Private S7F83Rooms As New List(Of S7F83Room) From {
    New S7F83Room With {.RoomNo = 1},
    New S7F83Room With {.RoomNo = 2},
    New S7F83Room With {.RoomNo = 3},
    New S7F83Room With {.RoomNo = 4}
}

    Private OutputPorts As New List(Of OutputPortWork) From {
    New OutputPortWork With {.PortNo = 1},
    New OutputPortWork With {.PortNo = 2}
}

    Private S7F83SaveOrder As Integer = 0
    Private OutputPortWaitingOrder As Integer = 0
    Private S7F83RoomLock As New Object()


    ' =========================================================================
    ' UI 버튼 액션 및 고유 송신 패킷 빌드 메커니즘 구역
    ' =========================================================================

    Private Function SaveS7F83ToEmptyRoom(lotData As LotInfoData, glassList As List(Of GlassInfoData)) As Boolean
        SyncLock S7F83RoomLock
            Dim emptyRoom = S7F83Rooms.FirstOrDefault(Function(r) r.State = S7F83RoomState.Empty)

            If emptyRoom Is Nothing Then
                logger.WriteLog("[WARNING] S7F83 저장 실패 - 4개 방이 모두 사용 중입니다. 신규 데이터는 저장하지 않습니다.")
                Return False
            End If

            S7F83SaveOrder += 1

            emptyRoom.LotData = lotData
            emptyRoom.GlassList = New List(Of GlassInfoData)(glassList)
            emptyRoom.SavedOrder = S7F83SaveOrder
            emptyRoom.SavedAt = DateTime.Now
            emptyRoom.State = S7F83RoomState.WaitingOutputPort
            emptyRoom.AssignedOutputPortNo = 0

            logger.WriteLog($"[SYSTEM] S7F83 저장 완료 - 방{emptyRoom.RoomNo}, 순번:{emptyRoom.SavedOrder}, LotID:{lotData.LotID}, Glass:{glassList.Count}")

            UpdateS7F83RoomDisplay()

            MatchWaitingS7F83AndOutputPorts()

            Return True
        End SyncLock
    End Function

    Private Function RegisterOutputPortStart(outputPortNo As Integer) As Boolean
        SyncLock S7F83RoomLock
            Dim targetPort = OutputPorts.FirstOrDefault(Function(p) p.PortNo = outputPortNo)

            If targetPort Is Nothing Then
                logger.WriteLog($"[ERROR] 출력포트 번호 오류: {outputPortNo}")
                Return False
            End If

            If targetPort.State <> OutputPortState.Empty Then
                logger.WriteLog($"[WARNING] 출력포트{outputPortNo} 착공 등록 실패 - 이미 진행 중인 데이터가 있습니다.")
                Return False
            End If

            OutputPortWaitingOrder += 1

            targetPort.State = OutputPortState.WaitingS7F83
            targetPort.WaitingOrder = OutputPortWaitingOrder
            targetPort.AssignedRoomNo = 0

            logger.WriteLog($"[SYSTEM] 출력포트{outputPortNo} 착공 등록 완료 - 착공순번:{targetPort.WaitingOrder}")

            MatchWaitingS7F83AndOutputPorts()

            Return True
        End SyncLock
    End Function

    Private Sub MatchWaitingS7F83AndOutputPorts()
        Dim waitingRoom = S7F83Rooms.
        Where(Function(r) r.State = S7F83RoomState.WaitingOutputPort).
        OrderBy(Function(r) r.SavedOrder).
        FirstOrDefault()

        Dim waitingPort = OutputPorts.
        Where(Function(p) p.State = OutputPortState.WaitingS7F83).
        OrderBy(Function(p) p.WaitingOrder).
        FirstOrDefault()

        While waitingRoom IsNot Nothing AndAlso waitingPort IsNot Nothing
            waitingRoom.State = S7F83RoomState.AssignedToOutputPort
            waitingRoom.AssignedOutputPortNo = waitingPort.PortNo

            waitingPort.State = OutputPortState.AssignedS7F83
            waitingPort.AssignedRoomNo = waitingRoom.RoomNo

            logger.WriteLog($"[SYSTEM] 매칭 완료 - 방{waitingRoom.RoomNo} -> 출력포트{waitingPort.PortNo}, LotID:{waitingRoom.LotData.LotID}")

            waitingRoom = S7F83Rooms.
            Where(Function(r) r.State = S7F83RoomState.WaitingOutputPort).
            OrderBy(Function(r) r.SavedOrder).
            FirstOrDefault()

            waitingPort = OutputPorts.
            Where(Function(p) p.State = OutputPortState.WaitingS7F83).
            OrderBy(Function(p) p.WaitingOrder).
            FirstOrDefault()
        End While

        UpdateS7F83RoomDisplay()

    End Sub

    Private Function GetAssignedRoomForOutputPort(outputPortNo As Integer) As S7F83Room
        SyncLock S7F83RoomLock
            Dim targetPort = OutputPorts.FirstOrDefault(Function(p) p.PortNo = outputPortNo)

            If targetPort Is Nothing Then Return Nothing
            If targetPort.State <> OutputPortState.AssignedS7F83 Then Return Nothing

            Return S7F83Rooms.FirstOrDefault(Function(r) r.RoomNo = targetPort.AssignedRoomNo)
        End SyncLock
    End Function

    Private Sub ClearAfterS6F77(outputPortNo As Integer)
        SyncLock S7F83RoomLock
            Dim targetPort = OutputPorts.FirstOrDefault(Function(p) p.PortNo = outputPortNo)

            If targetPort Is Nothing Then Exit Sub

            Dim roomNo As Integer = targetPort.AssignedRoomNo
            Dim targetRoom = S7F83Rooms.FirstOrDefault(Function(r) r.RoomNo = roomNo)

            If targetRoom IsNot Nothing Then
                logger.WriteLog($"[SYSTEM] S6F77 송신 후 방{targetRoom.RoomNo} 클리어 - 출력포트{outputPortNo}")
                targetRoom.Clear()
            End If

            targetPort.Clear()

            targetPort.Clear()
            UpdateS7F83RoomDisplay()

        End SyncLock
    End Sub


    Private Sub DeleteS7F83Room(roomNo As Integer)
        SyncLock S7F83RoomLock
            Dim targetRoom = S7F83Rooms.FirstOrDefault(Function(r) r.RoomNo = roomNo)
            If targetRoom Is Nothing OrElse targetRoom.State = S7F83RoomState.Empty Then
                logger.WriteLog($"[WARNING] 착공{roomNo} 삭제 실패 - 저장된 데이터가 없습니다.")
                Exit Sub
            End If
            Dim assignedPort = OutputPorts.FirstOrDefault(Function(p) p.AssignedRoomNo = roomNo)
            If assignedPort IsNot Nothing Then
                assignedPort.Clear()
            End If
            logger.WriteLog($"[SYSTEM] 착공{roomNo} 저장 데이터 삭제 - LotID:{targetRoom.LotData.LotID}")
            targetRoom.Clear()
            UpdateS7F83RoomDisplay()

            UpdateRoomLotDisplay()
        End SyncLock
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        DeleteS7F83Room(1)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        DeleteS7F83Room(2)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        DeleteS7F83Room(3)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        DeleteS7F83Room(4)
    End Sub



End Class

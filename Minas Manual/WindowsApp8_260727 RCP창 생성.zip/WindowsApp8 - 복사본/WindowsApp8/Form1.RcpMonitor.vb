﻿Partial Public Class Form1

    Private rcpMonitorForm As RcpMonitorForm

    Private Sub ShowRcpMonitorForm()
        If rcpMonitorForm Is Nothing OrElse rcpMonitorForm.IsDisposed Then
            rcpMonitorForm = New RcpMonitorForm()
        End If

        rcpMonitorForm.Show()
        rcpMonitorForm.BringToFront()

        UpdateRcpMonitorForm()
    End Sub

    Private Sub UpdateRcpMonitorForm()
        If rcpMonitorForm Is Nothing OrElse rcpMonitorForm.IsDisposed Then Exit Sub

        Dim lotRcps(4) As String
        Dim slotRcps(4, 11) As String

        SyncLock S7F83RoomLock
            For Each room As S7F83Room In S7F83Rooms
                lotRcps(room.RoomNo) = room.LotData.RcpID

                For Each glass As GlassInfoData In room.GlassList
                    Dim slotNo As Integer

                    If Integer.TryParse(glass.SlotID, slotNo) Then
                        If slotNo >= 1 AndAlso slotNo <= 11 Then
                            slotRcps(room.RoomNo, slotNo) = glass.SlotRcp
                        End If
                    End If
                Next
            Next
        End SyncLock

        rcpMonitorForm.UpdateRcpLabels(lotRcps, slotRcps)
    End Sub

End Class
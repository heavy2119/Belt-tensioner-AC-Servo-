﻿Imports System.Text

Public Module SecsEncoding
    Public Function EncodeAscii(txt As String, len As Integer) As Byte()
        ' [★ 런타임 에러 완전 방어] 인자로 넘어온 데이터 문자열이 Nothing(Null)일 경우에도 
        ' .PadRight 함수 호출에서 시스템이 다운되지 않도록 공백 문자로 자동 안전 우회 변환
        If txt Is Nothing Then txt = ""

        ' 지정된 전체 고정 길이에 도달할 때까지 우측에 빈 공백 패딩 주입
        Dim raw() As Byte = Encoding.ASCII.GetBytes(txt.PadRight(len))

        ' SECS 데이터 포맷 식별자 [0x41 = ASCII 타입]와 길이값을 헤드로 삽입하여 결합 반환
        Dim res As New List(Of Byte) From {&H41, CByte(len And &HFF)}
        res.AddRange(raw)
        Return res.ToArray()
    End Function

    ''' <summary>
    ''' 순수 바이트 배열을 SECS 표준 구조 바이너리 형태[0x21] 바이트 배열로 인코딩합니다.
    ''' </summary>
    Public Function EncodeBinary(data As Byte()) As Byte()
        ' SECS 데이터 포맷 식별자 [0x21 = BINARY 타입]
        Dim res As New List(Of Byte) From {&H21, CByte(data.Length And &HFF)}
        res.AddRange(data)
        Return res.ToArray()
    End Function

    ''' <summary>
    ''' 로우 바이트 배열 데이터를 우측 아스키 창을 제외한 순수 16진수 바둑판 헥사(Hex) 뷰 꼴로 깔끔하게 문자열 변환합니다.
    ''' </summary>
    Public Function FormatBytesToHexView(bytes As Byte()) As String
        If bytes Is Nothing OrElse bytes.Length = 0 Then Return "No Data"

        Dim sb As New System.Text.StringBuilder()
        Dim lineLength As Integer = 16 ' 가로 가독성 한계선인 16바이트 정렬

        For i As Integer = 0 To bytes.Length - 1 Step lineLength
            ' 1. 좌측 오프셋 인덱스 번호 마킹 (예: 00000020:)
            sb.Append(i.ToString("X8") & ": ")

            ' 2. 16바이트 가로 배열 나열 실행
            For j As Integer = 0 To lineLength - 1
                If (i + j) < bytes.Length Then
                    sb.Append(bytes(i + j).ToString("X2") & " ")
                Else
                    sb.Append("   ") ' 데이터가 마감되어 채워지지 못한 빈 슬롯 공간 정렬용 공백 확보
                End If
            Next

            sb.AppendLine()
        Next

        Return sb.ToString()
    End Function


End Module

﻿Partial Public Class Form1


    ' =========================================================================
    ' 하부 로우레벨 제어/송신 패킷 빌더 래핑 유틸리티
    ' =========================================================================

    ''' <summary>
    ''' 장비 제어 권한 모드 전환 이벤트를 호스트에 던집니다. (S6F95 송신)
    ''' </summary>
    Private Sub Send_S6F95(rcsMode As String)
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 5})
        body.AddRange(EncodeAscii(rcsMode, 1))
        body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
        body.AddRange(EncodeAscii("LCWLCW0101", 16)) ''장비 Sub EQP
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(New Byte() {&H1, 1})
        body.AddRange(New Byte() {&H1, 3})
        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeAscii("E", 1))
        body.AddRange(EncodeBinary(New Byte() {&H1}))

        ' 헤더를 W-Bit 가 활성화된 0x86 (Stream6, W-Bit On) 형식으로 정상 보정 송신
        SendPacket(CreateHeader(&H86, 95, 0), body.ToArray())
        logger.WriteLog($"[SEND] S6F95 RCS Msg Sent (W-Bit On: 86 5F, Mode: {rcsMode})")
    End Sub

    ''' <summary>
    ''' 카세트 투입 인식 이벤트를 연동 송신합니다. (S6F81 송신)
    ''' </summary>
    Private Sub Send_S6F81(cstId As String)
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 12})
        body.AddRange(EncodeAscii("H", 1))
        body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
        body.AddRange(EncodeAscii("LCWLCW0101", 16)) ''장비 Sub EQP
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(EncodeAscii("N", 1))
        body.AddRange(EncodeAscii(cstId, 14))

        ' [보정 완료] 기존 하드코딩 구역을 수신 보관 중이던 실데이터 레시피 아이디와 안전하게 바인딩 처리 완료
        body.AddRange(EncodeAscii(SharedLotData.RcpID, 24))

        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeBinary(New Byte() {&H0}))
        body.AddRange(EncodeAscii(SharedLotData.LotID, 16))
        body.AddRange(EncodeAscii("P", 1))
        body.AddRange(EncodeAscii("", 2))

        ' Stream 6번 + W-Bit On (&H86) 조합 전송
        SendPacket(CreateHeader(&H86, 81, 0), body.ToArray())
        logger.WriteLog($"[SEND] S6F81 Msg Sent (W-Bit On: 86 51)")
    End Sub

    Private Sub btnSendHead_Click(sender As Object, e As EventArgs) Handles btnSendHead.Click
        Try
            logger.WriteLog("[SEND] S2F17 Date and Time Request 송신 시작...")

            ' S2F17은 보통 바디가 비어있거나(<L, 0>) 명세에 따라 다름. 여기서는 빈 바디로 세팅
            Dim body As New List(Of Byte)()

            ' Stream 2, Function 17 (W-Bit On: &H82) 헤더 장착 후 전송
            SendPacket(CreateHeader(&H82, 17, 0), body.ToArray())
            logger.WriteLog("[SEND] S2F17 Date and Time Request 전송 완료 (W-Bit On)")
        Catch ex As Exception
            logger.WriteLog($"[ERROR] btnSendHead_Click 예외 발생: {ex.Message}")
        End Try
    End Sub


    ' [구조체전송] 버튼 클릭 시 - S1F73 송신
    ' HandleSecsMessage에 회신받을 S1F74을 추가해야함
    Private Sub btnSendStructure_Click(sender As Object, e As EventArgs) Handles btnSendStructure.Click
        Try
            logger.WriteLog("[SEND] S1F73 Structure Data 전송 시작...")

            Dim body As New List(Of Byte)()

            ' 최상위 <L, 3>
            body.AddRange(New Byte() {&H1, 3})

            ' 1. <A[1], "H"> [RCS]
            body.AddRange(EncodeAscii("H", 1))

            ' 2. <A[16], "LCWLCW01"> [EQP]
            body.AddRange(EncodeAscii("LCWLCW01", 16))

            ' 3. <L, 1> [Port 개수, 여기서는 n=1로 고정 예시]
            body.AddRange(New Byte() {&H1, 1})

            ' 하부 포트 구조체 <L, 3>
            body.AddRange(New Byte() {&H1, 3})

            ' 3-1. <A[16], "LCWLCW0101"> [MACHINE]
            body.AddRange(EncodeAscii("LCWLCW0101", 16))

            ' 3-2. <A[16], ""> [UNITID] 공백 패딩
            body.AddRange(EncodeAscii("", 16))

            ' 3-3. <L, 0> 하부 공백 노드
            body.AddRange(New Byte() {&H1, 0})

            ' Stream 1, Function 73 (W-Bit On: &H81) 헤더 장착 후 전송
            SendPacket(CreateHeader(&H81, 73, 0), body.ToArray())
            logger.WriteLog("[SEND] S1F73 Structure 패킷 전송 완료 (W-Bit On)")
        Catch ex As Exception
            logger.WriteLog($"[ERROR] btnSendStructure_Click 예외 발생: {ex.Message}")
        End Try
    End Sub


    Private Sub btnOnline_Click(sender As Object, e As EventArgs) Handles btnOnline.Click
        ' 응답을 요구하므로 Stream 번호 최상위 비트(W-Bit)를 On 처리하여 &H81(S1, W-Bit On)로 생성
        Dim header() As Byte = CreateHeader(&H81, 1, 0)
        SendPacket(header, New Byte() {})
        logger.WriteLog("[SEND] S1F1 Online Request (W-Bit On: 81 01)")
    End Sub

    ''' <summary>
    ''' Lot 시작 이벤트 유저 동작 유도 버튼입니다. (S7F87 송신 및 S6F81 자동 전송)
    ''' </summary>
    Private Sub btnLotStart_Click(sender As Object, e As EventArgs) Handles btnLotStart.Click
        ' [보안 방어] UI 컨트롤 박스 자체가 누락되었거나 공백일 경우의 시스템 다운 완벽 보호
        Dim cstId As String = "CSTCST000100" ' 안전한 기본 디폴트 텍스트 할당

        If txtCstID IsNot Nothing AndAlso Not String.IsNullOrEmpty(txtCstID.Text) Then
            cstId = txtCstID.Text
        End If

        ' SECS 표준 바이너리 인코딩 구조 직접 빌딩 시작
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 7}) ' <L, 7> 리스트 선언
        body.AddRange(EncodeAscii("LCWLCW01", 16))
        body.AddRange(EncodeAscii("LCWLCW0101", 16))
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(EncodeAscii("H", 1))
        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeAscii(cstId, 14))
        body.AddRange(EncodeAscii("A", 1))

        ' Stream 7번 + W-Bit On (&H87) 헤더 조합 후 물리 소켓 전송
        SendPacket(CreateHeader(&H87, 87, 0), body.ToArray())
        logger.WriteLog($"[SEND] S7F87 LotStart Request (W-Bit On: 87 57, CSTID: {cstId.Trim()})")

        ' 현장 시나리오 상의 요구조건에 의거하여 300ms 인터벌을 준 뒤 S6F81 연속 자동 연동 전송 진행
        'Threading.Thread.Sleep(300)
        'end_S6F81(cstId)
    End Sub

    Private TestCompletedOutputPortNo As Integer = 1
    ''' <summary>
    ''' [핵심 3] 수신 적재해 두었던 S7F83 실데이터를 믹싱하여 정답 규격의 S6F77 LotEnd 패킷을 조립 송신합니다.
    ''' </summary>
    Private Sub btnLotEnd_Click(sender As Object, e As EventArgs) Handles btnLotEnd.Click
        Try

            ' TODO: 사용자가 만든 출력포트 완공 신호에 맞게 넣습니다.
            ' 출력포트1 완공이면 1, 출력포트2 완공이면 2
            Dim completedOutputPortNo As Integer = TestCompletedOutputPortNo

            Dim assignedRoom As S7F83Room = GetAssignedRoomForOutputPort(completedOutputPortNo)

            If assignedRoom Is Nothing Then
                logger.WriteLog($"[WARNING] S6F77 송신 실패 - 출력포트{completedOutputPortNo}에 배정된 S7F83 방이 없습니다.")
                Exit Sub
            End If

            SharedLotData = assignedRoom.LotData
            SharedGlassList = New List(Of GlassInfoData)(assignedRoom.GlassList)

            Dim body As New List(Of Byte)()

            ' 1. 최상위 레이어 구조체 리스트 배치 빌딩 <L, 1> 하부 <L, 15>
            body.AddRange(New Byte() {&H1, 15})

            ' 상위 고정 명세 데이터 규격 바인딩 및 정밀 자릿수 패딩 채우기
            body.AddRange(EncodeAscii("H", 1))
            body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
            body.AddRange(EncodeAscii("LCWLCW0101", 16)) '장비 Sub EQP
            body.AddRange(EncodeAscii("", 16))
            body.AddRange(EncodeAscii("N", 1))

            ' [실데이터 믹싱] S7F83 수신 시 메모리에 보관해 둔 필드를 연동 (비어있을 시 디코더 오류 예방 디폴트 매핑)
            ' 변수에 먼저 담아두어 하단 루프 내 유효 슬롯 매핑 시 동일한 값을 사용하도록 합니다.
            Dim lotId As String = If(String.IsNullOrEmpty(SharedLotData.LotID), "LOTIDLOTID00", SharedLotData.LotID)
            body.AddRange(EncodeAscii(lotId, 16))

            'body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.CstID), "CSTCST000100", SharedLotData.CstID), 14))
            body.AddRange(EncodeAscii(ULDtxtCSTID.Text, 14))
            body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.RcpID), "RCPRCP11", SharedLotData.RcpID), 24))
            body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.PrcID), "44444", SharedLotData.PrcID), 8))

            body.AddRange(EncodeAscii("E", 1))
            'body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.PortID), "1", SharedLotData.PortID), 16))
            body.AddRange(EncodeAscii("2", 16)) 'PortID
            body.AddRange(EncodeAscii("", 2))
            body.AddRange(EncodeAscii("N", 1))
            body.AddRange(New Byte() {&H1, 0}) ' 하부 공백 노드 세트 배치 <L, 0>

            ' 2. Glass 목록 컨테이너 빌딩 구역 (★현장 요구 규격: 무조건 11개 슬롯 세트 형태 고정 유지)
            body.AddRange(New Byte() {&H1, 1})  ' <L, 1>
            body.AddRange(New Byte() {&H1, 11}) ' 총 11개의 루프를 돌며 바디 구조 조립

            ' S7F83 L9의 GLSID 수신 순서를 역순으로 슬롯에 배치 (1번째 -> 11번, 2번째 -> 10번, ...)
            ' ★ 안전 보정: SharedGlassList 내부 데이터 개수가 11개보다 적거나 많을 때의 예외를 방어합니다.
            Dim reversedSlotMap As New Dictionary(Of Integer, GlassInfoData)()
            For i As Integer = 0 To SharedGlassList.Count - 1
                Dim targetSlot As Integer = 11 - i

                ' 만약 데이터가 11개 이상 들어와서 계산된 targetSlot이 1보다 작아지면 바인딩을 스킵하여 방어합니다.
                If targetSlot >= 1 AndAlso targetSlot <= 11 Then
                    Dim mappedGlass As GlassInfoData = SharedGlassList(i)
                    mappedGlass.SlotID = targetSlot.ToString()
                    reversedSlotMap(targetSlot) = mappedGlass
                End If
            Next

            For slotNum As Integer = 1 To 11
                Dim targetGlass As GlassInfoData = Nothing
                Dim hasData As Boolean = False

                If reversedSlotMap.ContainsKey(slotNum) Then
                    targetGlass = reversedSlotMap(slotNum)
                    hasData = True
                End If

                ' 개별 항목 규격 선언 : 진짜 로그 구조 매칭 <L, 12> 구조체 생성
                body.AddRange(New Byte() {&H1, 12})

                If hasData Then
                    ' [Case A] 메모리에 매핑에 성공했던 실제 유효 슬롯 데이터 부위 결합 기입 (5~11번 등)
                    body.AddRange(EncodeAscii(targetGlass.SlotID, 3))     ' <A[3]> 슬롯번호
                    body.AddRange(EncodeAscii(targetGlass.GlsID, 16))     ' <A[16]> GlassID
                    body.AddRange(EncodeBinary(targetGlass.SCode))        ' <B[1]> 바이너리 상태 코드
                    body.AddRange(EncodeAscii(targetGlass.GlsJudge, 2))   ' <A[2]> 판정 문자열
                    body.AddRange(EncodeAscii(targetGlass.PnlIf, 96))     ' <A[96]> Panel 정보
                    body.AddRange(EncodeAscii(targetGlass.SubMdlIf, 96))  ' <A[96]> SubMdl 정보
                    body.AddRange(EncodeAscii(targetGlass.SlotRcp, 24))   ' <A[24]> 레시피 명칭
                Else
                    ' [Case B] 빈 슬롯 공백 부위 (1~4번 등) - 정답 로그 매세 규격 원본 준수
                    body.AddRange(EncodeAscii(slotNum.ToString(), 3))     ' <A[3]> 슬롯 번호 강제 대입
                    body.AddRange(EncodeAscii("", 16))                    ' <A[16]> 공백 문자열
                    body.AddRange(EncodeBinary(New Byte() {&H0}))         ' <B[1]> 0x00 바이너리
                    body.AddRange(EncodeAscii("", 2))                     ' <A[2]> 공백
                    body.AddRange(EncodeAscii("", 96))                    ' <A[96]> 공백
                    body.AddRange(EncodeAscii("", 96))                    ' <A[96]> 공백
                    body.AddRange(EncodeAscii("", 24))                    ' <A[24]> 공백
                End If

                ' 개별 슬롯 구조 하단부 트리 고정 규격 양식 강제 생성부 복사 조립
                body.AddRange(EncodeAscii("0", 1))
                body.AddRange(EncodeAscii("2", 1))

                ' =====================================================================
                ' ★ 핵심 수정 포인트 반영 구역
                ' 매핑에 성공한 실제 유효 슬롯(hasData = True)에만 S7F83에서 받아온 LotID를 기입합니다.
                ' =====================================================================
                If hasData Then
                    body.AddRange(EncodeAscii(lotId, 16)) ' 상단에서 가져온 유효 LotID 주입
                Else
                    body.AddRange(EncodeAscii("0", 16))   ' 데이터가 없는 빈 슬롯은 기존 원본과 동일하게 "0" 처리
                End If
                ' =====================================================================

                body.AddRange(New Byte() {&H1, 0})  ' <L, 0>
                'body.AddRange(New Byte() {&H1, 1})  ' <L, 1>
                body.AddRange(New Byte() {&H1, 0})  ' <L, 0>
            Next

            ' 조립 완성된 최종 대형 로우 바이너리 팩을 전송 (S6F77 헤더 장착)
            SendPacket(CreateHeader(&H86, 77, 0), body.ToArray())
            logger.WriteLog($"[SEND] S6F77 LotEnd 정답 규격 패킷 전송 성공 (출력포트:{completedOutputPortNo}, 방:{assignedRoom.RoomNo}, LotID:{lotId})")

            ClearAfterS6F77(completedOutputPortNo)

        Catch ex As Exception
            logger.WriteLog($"[ERROR] btnLotEnd_Click 런타임 예외 발생: {ex.Message}")
        End Try
    End Sub

End Class
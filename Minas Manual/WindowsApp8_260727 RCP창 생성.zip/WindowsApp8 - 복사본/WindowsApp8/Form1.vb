﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

' ============================================================================
' [나중에 혼자 보수할 때 봐야 할 5대 핵심 가이드]
' 
' 1. 장비 통신 포트나 대기 모드를 변경해야 할 때:
'    -> 'StartHsmsServer' 함수 내부의 'SET_PORT' 모듈 상수를 확인하세요.
'    -> 현재 IPAddress.Any를 통해 모든 대역의 연결을 수락하는 Passive(서버) 모드입니다.
' 
' 2. 데이터가 쪼개져서 오거나 밀려서 올 때 (패킷 꼬임, 잘림 현상):
'    -> 'ReceiveCallback' 내부의 'streamBuffer'와 'While streamBuffer.Count >= 4' 루프가
'       TCP 특유의 패킷 잘림/뭉침을 규격대로 칼같이 잘라주는 '스트림 커팅 엔진'입니다.
' 
' 3. 현장 로그 명세서나 슬롯 개수가 변경되었을 때:
'    -> 'btnLotEnd_Click'의 'For slotNum As Integer = 1 To 11' 루프를 고치세요.
'    -> 현재 액티브(Active) 장비 정답 로그 규격에 맞춰 빈 슬롯(1~4번)도 공백 자릿수를 
'       정밀 매핑(EncodeAscii)하여 튕기지 않게 방어해 둔 핵심 구역입니다.
' 
' 4. 특정 SECS 메시지(예: S1F1, S2F21 등) 수신 처리를 추가하고 싶을 때:
'    -> 'HandleSecsMessage' 함수 내부의 'Select Case stream' 구문에 Case를 추가하세요.
'    -> 파싱된 데이터는 'SharedGlassList'와 'SharedLotData' 전역 저장소에 안전하게 백업됩니다.
' 
' 5. 프로그램이 종료될 때 소켓이 먹통이 되거나 포트가 묶이는 현상 방지:
'    -> 'DisconnectClient'와 'Form1_FormClosing'에서 소켓을 Shutdown 후 Close하고
'       완벽하게 'Nothing'으로 초기화하여 운영체제 자원을 즉시 반환하도록 처리되어 있습니다.
' ============================================================================

''' <summary>
''' [메인 폼] HSMS Passive 통신 서버 가동, 비동기 소켓 스트림 처리, 
''' 제어 메시지 핸들링 및 유저 시나리오(온라인/LotStart/LotEnd)를 총괄하는 메인 컨트롤러입니다.
''' </summary>
Public Class Form1
    ' --- 의존성 클래스 및 인스턴스 변수 ---
    Private logger As HsmsLogger              ' UI 및 파일 로그 기록용 분리형 로거 객체



    ' --- 전역 공용 백업 저장소 (SecsDataTypes 구조체 연동) ---
    Private SharedLotData As LotInfoData
    Private SharedGlassList As New List(Of GlassInfoData)()






    ' ============================================================================
    ' [신규] 화면 상태 표시 및 GLS Count 관리 변수
    ' ============================================================================
    ' LD GLS Count 화면 표시용 내부 카운터입니다.
    ' S7F83 등 SECS/GEM 수신 데이터에서 계산된 LD 투입 Glass 수량을 보관합니다.
    ' 화면 표시값과 내부 값을 일치시키기 위해 SetLDGLSCount 함수에서만 변경하는 것을 권장합니다.
    Private ldGlsCount As Integer = 0

    ' ULD GLS Count 화면 표시용 내부 카운터입니다.
    ' 추후 PLC Bit 신호가 들어올 때마다 IncreaseULDGLSCount 함수에서 1씩 증가시킬 예정입니다.
    ' 화면 표시값과 내부 값을 일치시키기 위해 직접 값을 바꾸지 말고 전용 함수를 통해 변경하는 것을 권장합니다.
    Private uldGlsCount As Integer = 0



    ''' <summary>
    ''' 폼이 메모리에 로드될 때 발생하는 초기화 이벤트입니다.
    ''' </summary>
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' [방어] 크로스 스레드 예외를 강제 비활성화하여 통신 스레드가 UI를 건드려도 다운되지 않도록 처리
        CheckForIllegalCrossThreadCalls = False

        ' 로거 엔진 초기화 (메인 UI의 rtbLog RichTextBox 컨트롤과 바인딩)
        logger = New HsmsLogger(rtbLog)


        ' [신규] Form 시작 시 Lamp#1을 초기 상태로 표시합니다.
        ' 아직 Host와 Socket 연결이 완료되지 않았으므로 문구는 비워두고 색상은 White로 둡니다.
        UpdateLampStatus("DISCONNECTED", Color.White)


        ' [신규] Form 시작 시 LD GLS Count를 0으로 초기화합니다.
        ' 이후 S7F83 수신 또는 LD CST OFF 조건에 따라 값이 갱신됩니다.
        SetLDGLSCount(0)

        ' [신규] Form 시작 시 ULD GLS Count를 0으로 초기화합니다.
        ' 이후 PLC Bit 신호 또는 ULD CST OFF 조건에 따라 값이 갱신됩니다.
        SetULDGLSCount(0)

        ' [추가] S7F83 방1~방4 LOT 표시창 생성
        CreateS7F83RoomLotLabels()
        CreateNextEndTargetLabels()
        UpdateS7F83RoomDisplay()


        ' T7 타이머 제한 시간을 HsmsConfig에 정의된 표준 값(밀리초)으로 셋팅
        tmrT7.Interval = T7_Timeout

        ' [핵심 1] TCP 서버 가동 (Passive Mode 시작)
        StartHsmsServer()

        Timer1.Enabled = True

        lblNextEndTarget(1) = lblNextEndTarget1
        lblNextEndTarget(2) = lblNextEndTarget2
        lblNextEndTarget(3) = lblNextEndTarget3
        lblNextEndTarget(4) = lblNextEndTarget4
    End Sub







    ''' <summary>
    ''' 연결 수립 후 일정 시간(T7) 동안 무반응 방치 시 클라이언트를 강제 강등 탈퇴시키는 타이머 틱 이벤트입니다.
    ''' </summary>
    Private Sub tmrT7_Tick(sender As Object, e As EventArgs) Handles tmrT7.Tick
        logger.WriteLog("[TIMEOUT] T7 Timeout! No Select.req.")
        DisconnectClient()
    End Sub


    ''' <summary>
    ''' 윈도우 폼 창이 완전히 닫히기 직전 실행되는 파괴자 성격의 이벤트 함수입니다.
    ''' </summary>
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' 실행 중이던 하부 통신 채널 자원 및 활성화된 파일 스트림을 순차적으로 완전 격리 소멸 처리 진행
        DisconnectClient()
        If serverSocket IsNot Nothing Then serverSocket.Stop()
        If logger IsNot Nothing Then logger.CloseFile()
    End Sub




    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        UpdateRoomLotDisplay()
    End Sub

    Private Sub btnOpenRcpMonitor_Click(sender As Object, e As EventArgs) Handles btnOpenRcpMonitor.Click
        ShowRcpMonitorForm()
    End Sub
End Class
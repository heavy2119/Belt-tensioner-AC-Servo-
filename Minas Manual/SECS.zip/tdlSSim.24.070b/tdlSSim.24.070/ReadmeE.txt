====================================================================================================
== Introduction (tdlSSimE) =========================================================================

[] Introductions of "Trust Design Simple SECS Simulator"

  + Simulator of SECS message communication by SECS-1 (RS232C connection), HSMS-SS, HSMS-GS (TCP/IP
    connection).

  + Supports host side, device side, master side, slave side, passive side and active side.
  + It has message sending function, receiving function, and reply function to received message.
  + The reply can be made by automatically selecting appropriate reply message that matches the
    received message and replying automatically, or user can select and reply from multiple messages
    to be replied to.
  + It is possible to automatically operate continuous SECS message communication using script files
    written in own simple language.
  + SECS Communication trace can be saved in specified number and capacity of specified file.

  + Send and receive specified messages using message definition files in SML format.
  + It is possible to change and set data value of send message item according to send situation.
    In addition, it is possible to obtain a data value from file contents by preparing a file
    storing a large amount of data values and specifying file name as the data value of send message
    item.
  + You can use variable-length fields and items.

  + It is possible to define multi-level, multi-number indefinite number list.
    It is possible to fix number of lists at runtime and set each item value in the list.

  + It conforms to following SEMI standards.
    - E4    : SECS-I ..... Message transfer (RS232C connection)
    - E5    : SECS-II .... SECS Message contents
    - E37   : HSMS ....... High-Speed SECS message service (HSMS) generic service (TCP/IP)
    - E37.1 : HSMS-SS .... High-speed SECS message service single session mode (HSMS-SS)
    - E37.2 : HSMS-GS .... High-speed SECS message service general session (HSMS-GS)
  + The "E5-0600" compliant message definition defined by the SEMI standard is attached as a sample.

  + The program can automatically operate continuous SECS message communication using its own simple
    language. This simple language has following mechanism.
    - Multiple scenario (execution sequence) definition
    - Variable (string, integer, real number)
    - Variable operation (four arithmetic operations etc.)
    - Condition judgment by IF statement
    - Processing branch by block IF statement, GOTO statement
    - Iteration by WHILE statement
    - Function call by CALL statement
    - Invoke external program by EXEC statement
    - SECS message sending and receiving
    - Change data item values that make up send message when sending
    - Extract data item value from received message and set as variable
    - Other ...
  + This simple language can be used as a simulation operation for normal SECS communication, but it
    is unfortunately not good enough in terms of scripting method, operation speed, etc.

  + In this program, there are parts that have been removed regarding error processing, processing
    speed, help function, simple language specifications, operation instructions, etc., but ...
    please forgive me.
  + Also, it is assumed that well-meaning users who use them with correct settings and correct usage
    are intended for use. There is a part that does not correspond to some useless ways, etc., but
    please forgive.


  + For development of communication system by SECS/HSMS, our SECS/HSMS communication package (Trust
    Design Simple SECS Communication Library) is available.
    For more information, please visit our home page.

  + You can use SECS/HSMS protocol converter program (Trust Design Simple SECS/HSMS Protocol
    converter) is released.
    For more information, please visit our home page.

  + For monitoring communications by SECS (HSMS), our network communications monitor (Trust Design
    Simple) Network Communication Monitor) is available.
    For more information, please visit our home page.

  + For monitoring communications by SECS-1 protocol using RS232C Serial Port, our serial
    communication monitor (Trust Design Simple Serial Port Communication Monitor) is available.
    For more information, please visit our home page.



[] How to install

  + Extract the archive file of this package (tdlSSim.zip or tdlSSim.YY.MMN.zip (YY.MMN is
    version number) etc.) to any folder.

  + This package does not use registry.



[] How to uninstall

  + Please delete the folder where you installed this package.



[] How to use "Trust Design Simple SECS Simulator"

  + For details on operation of this program, refer to included instruction manual (tdlSSimE.pdf).

  + The .exe under Win32/ is a 32bit Application.
  + The .exe under Win64/ is a 64bit Application.

  + tdlSSim.exe  is a Japanese version.
    tdlSSimE.exe is a English  version.
    This program uses "MS Gothic" as font used. Please execute in the environment where the same
    font can be used.

  + First, create a configuration file (.ini file) that describes operating conditions of this
    program, and a message definition file (.sml) that describes SECS message structure.
    Also, for automatic execution, create a script description file (.ssl).

  + For each file, refer to and copy Sample.ini, Sample.sml, and Sample.ssl that exist in attached
    Sample0/.

  + For details on .ini files and .sml files, refer to Programmer's Manual (TDSE.pdf) included in
    our "Trust Design Simple SECS Communication Library (TDS)".
    Download the product (TDS) from our website (http://www.trust-design.co.jp/).

  + Please refer to tdlSSimE.pdf for the description of .ssl file.


  + Start "tdlSSimE.exe" that exists under Win32/ or Win64/ from the directory where this program
    is installed on Windows.

  + Please refer to tdlSSimE.pdf for operation after startup.

  + The following two SECS message definition files are attached as a sample to this program.

    - SampleE.sml      : A very simple definition sample, similar to the one used by sample program
                         included with our product SECS/HSMS Communication Package (Trust Design
                         Simple SECS Communication Library). It can be used when trying to check
                         operation of this program using communication test using sample program.

    - SemiStandard.sml : This message definition conforms to "E5-0600" defined by the SEMI standard.


   (Note 1) For more information on our SECS/HSMS communication package (Trust Design Simple SECS
      Communication Library), please refer to our home page.

   (Note 2) ---------------------------------------------------------------------------------------+
    | This program uses following ports of UDP/IP for license management.                          |
    | Also use following class D address as UDP/Multicast address. Please set not to block these   |
    | by firewall etc. of your computer.                                                           |
    |  - 36275/udp                                                                                 |
    |  - 239.254.200.75                                                                            |
    | However, including Internet connection environment, it can be used even when network         |
    | connection can not be made and NIC does not exist, there are no functional restrictions on   |
    | usage as compared with internet connection environment.                                      |
    +----------------------------------------------------------------------------------------------+

   (Note 3) The display language used in dialogs such as "File selection dialog" depends on your
      Windows environment. For example, when tdlSSimE.exe is started in Japanese environment
      Windows, display language of "File selection dialog" will be Japanese.



[] Contact information

   Company name : Trust Design Limited Liability Company
   e-Mail       : info@trust-design.co.jp
   URL          : http://www.trust-design.co.jp/



====================================================================================================
== Matters to keep in mind =========================================================================

[] Notes on using this program

  + Please read and agree to "License Conditions, etc." at bottom of this document before using this
    program.

  + If you wish to obtain a license key code for this package, please contact us at
    "info@trust-design.co.jp" by e-mail, specifying following contents.
    Issuing a license key code is free.

    - The title should be "Trust Design Simple SECS Simulator license request".
    - Please describe following contents in text.
      * English name of organization name (company name and department name)
      * Person in charge name
      * Contact information (address, phone number, e-mail address)
      * Number of licenses required
        The number of licenses to be issued per request is limited to 10 at maximum.
        If you need more licenses, please contact us.
        Note that a different license is required for each PC you are using.

  + When using this program for trial, add following license key descriptions on our website to 
    configuration file (.ini).

    LICENSENAME    = "Default Co.,Ltd."
    LICENSECODE    = "Default"
    LICENSEDATE    = "20111001"
    LICENSESER     = "1"
    LICENSEKEY     = "O2LII-L7BJF-SBMHR-J4PF4-VCBN7-D3YVY"

   (Note 1) The values of LICENSEDATE and LICENSEKEY of the license key for trial use change
      regularly. Please check our HP "http://www.trust-design.co.jp" for latest license key for
      trial use.

  + Please refer to "tdlSSimE.pdf" for details on how to use this program.


  + [Important 1]
    This program needs to set various connection conditions, trace output conditions, SECS message
    conditions, etc. in configuration file (tdlSSimE.ini) using a text editor such as notepad.exe.
    The contents of configuration file vary widely, so it is necessary to fully understand contents.
    Please use "SampleE.ini" included in the package after changing it according to your usage
    conditions, paying special attention to following parameters.

    For details, refer to programmers manual (TDSE.pdf) included in "Trust Design Simple SECS
    Communication Library (TDS)" which is our related product.
    Download the product (TDS) from our website (http://www.trust-design.co.jp/).

     SECSMODE           // SECS communication paramesters
     DEVMODE            // Device control mode
     DEVID              // Connected device ID
     XMSGSIZE           // Maximum SECS message byte length
     INTER0             // Communication control unit processing interval
     INTER2             // Serial communication receiving interval
     SDEVICE            // SECS-1 Serial connection device name
     HOST               // HSMS TCP/IP Destination host name or IP address
     PORT               // HSMS TCP/IP Connection port number
     TRCTTYPE           // Communication message output format to communication trace
     TRCTLEVEL          // Communication trace output level
     LINKINT            // Link Test interval
     MDMSSG             // Message definition file path in SML format
     MDMXITEM           // Maximum number of total data items used in each message
     MDMXMSSG           // Maximum number of messages to define
     MDMXMITEM          // Maximum number of total items used in each message
     MDMXPOOL           // Message definition Setting data storage area size


  + [Important 2]
    This program needs to set in advance SECS message structure, initial data value, etc. with which
    this program communicates using SECS message definition file (.sml).
    The message definition file can be used by copying attached "SampleE.sml", but please define
    required SECS message structure according to your usage conditions.
    For more details, please refer to TDSE.pdf described in [Important 1].


  + The latest version of this program is released by our website.
    Please check our website "http://www.trust-design.co.jp/" one after another.



====================================================================================================
== License conditions, etc. ========================================================================

[] Copyright etc

  The copyright for "Trust Design Simple SECS Simulator" (hereinafter referred to as "tdlSSim") is
  owned by "Trust Design Limited Liability Company" (hereinafter referred to as "TDL").

  + The customer can not distribute the software itself (a package that provides the functions of
    tdlSSim itself, etc.) to a third party without our consent, regardless of whether it is for a
    fee or for free.
  + When distributing applications etc. using tdlSSim created by customer, clearly indicate that
    following software is used.
    - Name of this software             : "Trust Design Simple SECS Simulator"
    - Copyright holder of this software : "Trust Design Limited Liability Company"



[] Usage restriction

  tdlSSim can be used free of charge by anyone.

  If it is used continuously for more than a certain period of time, it is necessary to contact us
  by e-mail in prescribed format (described above) and receive a license key code.

  + Issuing a license key code is free.
  + A license key code is required for each computer you use.
  + If you run tdlSSim with a regular license key code issued for each customer, there is no limit
    on the execution time. In addition, there is no expiration date limit for the regular license
    key code.

  In addition, registration of customer information is necessary to issue license key code. The
  customer information registered upon issuance of the license key code will be used to manage the
  installation status of tdlSSim.



[] Disclaimer

  If any failure or damage is caused by use of tdlSSim, we not assume any responsibility
  regardless of the size of failure or damage, even if it is caused by a defect contained in
  tdlSSim. We do not guarantee that tdlSSim will always operate correctly in the environment where
  you use tdlSSim.



[] Support

  Support for this software is provided by e-mail only.
  We will respond to your inquiry via e-mail as much as possible, but we can not make any warranty,
  including presence or absence of a reply, and the time until response.
  In addition, we may provide support for tdlSSim for a fee upon agreement with you.
  If a defect related to tdlSSim is found, we may clarify the cause, respond to the cause, or
  release a new version. We can not make a promise.

  tdlSSim may be revised or updated without prior notice for the purpose of improving its
  performance. For latest version, please refer to our website (http://www.trust-design.co.jp/).


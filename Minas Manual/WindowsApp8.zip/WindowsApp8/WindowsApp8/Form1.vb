﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

' ============================================================================
' [나중에 혼자 보수할 때 봐야 할 5대 핵심 가이드]
' 
' 1. 장비 통신 포트나 대기 모드를 변경해야 할 때:
'    -> 'StartHsmsServer' 함수 내부의 'SET_PORT' 모듈 상수를 확인하세요.
'    -> 현재 IPAddress.Any를 통해 모든 대역의 연결을 수락하는 Passive(서버) 모드입니다.
' 
' 2. 데이터가 쪼개져서 오거나 밀려서 올 때 (패킷 꼬임, 잘림 현상):
'    -> 'ReceiveCallback' 내부의 'streamBuffer'와 'While streamBuffer.Count >= 4' 루프가
'       TCP 특유의 패킷 잘림/뭉침을 규격대로 칼같이 잘라주는 '스트림 커팅 엔진'입니다.
' 
' 3. 현장 로그 명세서나 슬롯 개수가 변경되었을 때:
'    -> 'btnLotEnd_Click'의 'For slotNum As Integer = 1 To 11' 루프를 고치세요.
'    -> 현재 액티브(Active) 장비 정답 로그 규격에 맞춰 빈 슬롯(1~4번)도 공백 자릿수를 
'       정밀 매핑(EncodeAscii)하여 튕기지 않게 방어해 둔 핵심 구역입니다.
' 
' 4. 특정 SECS 메시지(예: S1F1, S2F21 등) 수신 처리를 추가하고 싶을 때:
'    -> 'HandleSecsMessage' 함수 내부의 'Select Case stream' 구문에 Case를 추가하세요.
'    -> 파싱된 데이터는 'SharedGlassList'와 'SharedLotData' 전역 저장소에 안전하게 백업됩니다.
' 
' 5. 프로그램이 종료될 때 소켓이 먹통이 되거나 포트가 묶이는 현상 방지:
'    -> 'DisconnectClient'와 'Form1_FormClosing'에서 소켓을 Shutdown 후 Close하고
'       완벽하게 'Nothing'으로 초기화하여 운영체제 자원을 즉시 반환하도록 처리되어 있습니다.
' ============================================================================

''' <summary>
''' [메인 폼] HSMS Passive 통신 서버 가동, 비동기 소켓 스트림 처리, 
''' 제어 메시지 핸들링 및 유저 시나리오(온라인/LotStart/LotEnd)를 총괄하는 메인 컨트롤러입니다.
''' </summary>
Public Class Form1
    ' --- 의존성 클래스 및 인스턴스 변수 ---
    Private logger As HsmsLogger              ' UI 및 파일 로그 기록용 분리형 로거 객체

    ' --- 네트워크 소켓 엔진 변수 ---
    Private serverSocket As TcpListener       ' 상대방(Active)의 접속을 기다리는 서버 리스너 소켓
    Private clientSocket As Socket            ' 실제 연결이 수립된 클라이언트 세션 소켓
    Private isConnected As Boolean = False     ' 현재 통신 연결 성공 여부 플래그
    Private SystemBytesCounter As UInteger = 1 ' SECS 메시지 동기화용 고유 일련번호 (4바이트 카운터)

    ' --- 타이머 제어 변수 ---
    Private WithEvents tmrT7 As New Timer()   ' T7 타임아웃(연결 후 Select.req 수신 대기 제한 시간) 관리 타이머

    ' --- 전역 공용 백업 저장소 (SecsDataTypes 구조체 연동) ---
    Private SharedLotData As LotInfoData
    Private SharedGlassList As New List(Of GlassInfoData)()

    ''' <summary>
    ''' 폼이 메모리에 로드될 때 발생하는 초기화 이벤트입니다.
    ''' </summary>
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' [방어] 크로스 스레드 예외를 강제 비활성화하여 통신 스레드가 UI를 건드려도 다운되지 않도록 처리
        CheckForIllegalCrossThreadCalls = False

        ' 로거 엔진 초기화 (메인 UI의 rtbLog RichTextBox 컨트롤과 바인딩)
        logger = New HsmsLogger(rtbLog)

        ' T7 타이머 제한 시간을 HsmsConfig에 정의된 표준 값(밀리초)으로 셋팅
        tmrT7.Interval = T7_Timeout

        ' [핵심 1] TCP 서버 가동 (Passive Mode 시작)
        StartHsmsServer()
    End Sub

    ''' <summary>
    ''' 서버 소켓을 열고 클라이언트의 비동기 접속 대기 상태를 시작합니다.
    ''' </summary>
    Private Sub StartHsmsServer()
        Try
            ' 내부 모든 네트워크 카드(Any)와 설정된 포트(7000)를 바인딩하여 대기
            serverSocket = New TcpListener(IPAddress.Any, SET_PORT)
            serverSocket.Start()
            logger.WriteLog($"[SYSTEM] HSMS Server Open (Port: {SET_PORT}, Passive Mode)")

            ' 비동기 접속 수락 시작 (대기 상태 중에도 메인 UI가 멈추지 않음)
            serverSocket.BeginAcceptSocket(AddressOf AcceptCallback, Nothing)
        Catch ex As Exception
            logger.WriteLog($"[ERROR] Server Start Fail: {ex.Message}")
        End Try
    End Sub

    ''' <summary>
    ''' 클라이언트가 실제로 접속했을 때 호출되는 비동기 콜백 함수입니다.
    ''' </summary>
    Private Sub AcceptCallback(ar As IAsyncResult)
        Try
            ' 접속한 클라이언트 소켓 세션을 인스턴스에 할당
            clientSocket = serverSocket.EndAcceptSocket(ar)
            isConnected = True
            logger.WriteLog($"[SYSTEM] Client Connected: {clientSocket.RemoteEndPoint.ToString()}")

            ' [HSMS 표준 규격] 연결은 맺어졌으므로, T7 타이머를 가동하여 정해진 시간 내에 Select.req가 오는지 감시 시작
            tmrT7.Start()

            ' 데이터 수신용 버퍼(64KB)를 개설하고 비동기 데이터 수신(Receive) 대기 전송
            Dim buffer(65535) As Byte
            clientSocket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, AddressOf ReceiveCallback, buffer)

            ' 다음 대형 후속 클라이언트 접속을 위해 서버 소켓 접속 수락 대기를 재호출 (멀티 세션 예방 가드)
            serverSocket.BeginAcceptSocket(AddressOf AcceptCallback, Nothing)
        Catch ex As Exception
            logger.WriteLog($"[ERROR] Accept Error: {ex.Message}")
        End Try
    End Sub

    ' TCP 스트림 파편화/뭉침 현상을 완벽 방어하기 위한 바이트 누적 버퍼
    Private streamBuffer As New List(Of Byte)()

    ''' <summary>
    ''' [핵심 2] 소켓을 통해 로우 데이터(바이트)가 들어올 때마다 호출되는 정밀 패킷 정형화 엔진입니다.
    ''' </summary>
    Private Sub ReceiveCallback(ar As IAsyncResult)
        Dim buffer As Byte() = CType(ar.AsyncState, Byte())
        If clientSocket Is Nothing Then Exit Sub

        Try
            ' 소켓으로부터 실제 읽어온 바이트 크기를 반환받음
            Dim bytesRead As Integer = clientSocket.EndReceive(ar)

            ' 상대방이 정상적으로 소켓 연결을 종료(Shutdown)한 경우 0 바이트가 들어옵니다.
            If bytesRead = 0 Then
                logger.WriteLog("[INFO] Active가 연결을 먼저 종료했습니다. (bytesRead = 0)")
                DisconnectClient()
                Exit Sub
            End If

            ' 멀티스레드 환경에서 누적 스트림 버퍼가 꼬이지 않도록 동기화 락(SyncLock)을 겁니다.
            SyncLock streamBuffer
                ' 1. 이번에 새로 들어온 바이트 덩어리를 임시 배열에 복사 후 누적 스트림 버퍼 뒤에 병합
                Dim tempBytes(bytesRead - 1) As Byte
                Array.Copy(buffer, 0, tempBytes, 0, bytesRead)
                streamBuffer.AddRange(tempBytes)

                ' 2. 누적 버퍼 내에서 완전한 패킷 단위(헤더4바이트 크기 기반)로 정밀 컷팅 반복 실행
                While streamBuffer.Count >= 4
                    ' 앞의 4바이트를 복사하여 전체 메시지 길이(MsgLength) 파악 진행
                    Dim msgLenBytes(3) As Byte
                    streamBuffer.CopyTo(0, msgLenBytes, 0, 4)

                    ' 네트워크 표준(Big Endian)에서 C#/.NET 표준(Little Endian) 환경으로 바이트 역전 처리
                    If BitConverter.IsLittleEndian Then Array.Reverse(msgLenBytes)
                    Dim msgLength As UInteger = BitConverter.ToUInt32(msgLenBytes, 0)

                    ' [보안 방어막] 비정상적인 유령 크기(5MB 초과)가 오면 소켓 버퍼 오염으로 간주하고 즉시 초기화하여 좀비 상태 방지
                    If msgLength > 5000000 Then
                        logger.WriteLog($"[SOCKET WARNING] 유령 패킷 크기 감지({msgLength} 바이트). 스트림 리셋을 실시합니다.")
                        streamBuffer.Clear()
                        Exit While
                    End If

                    ' 전체 패킷 실제 크기 = 길이 헤더 공간(4바이트) + 알맹이 데이터 길이(msgLength)
                    Dim totalPacketSize As Integer = CInt(msgLength) + 4

                    ' [완전성 검사] 버퍼에 쌓인 데이터가 계산된 전체 패킷 크기보다 작다면 데이터가 아직 덜 온 것입니다.
                    ' 다음 비동기 데이터가 뒤에 더 붙을 때까지 가공하지 않고 루프를 즉시 탈출합니다. (TCP 파편화 방어 핵심)
                    If streamBuffer.Count < totalPacketSize Then
                        Exit While
                    End If

                    ' 완벽한 패킷 하나가 통째로 다 수집되었으므로 가공 시작
                    Dim packetBytes(totalPacketSize - 1) As Byte
                    streamBuffer.CopyTo(0, packetBytes, 0, totalPacketSize)

                    ' 처리할 분량만큼 누적 버퍼의 앞부분을 완전히 도려내어 인덱스 꼬임을 차단합니다.
                    streamBuffer.RemoveRange(0, totalPacketSize)

                    ' 실제 헤더 10바이트 추출 (앞의 4바이트 길이 정보 스킵한 위치부터 시작)
                    Dim header(9) As Byte
                    Array.Copy(packetBytes, 4, header, 0, 10)

                    Dim sType As Byte = header(5)               ' HSMS 제어 메시지 타입 (0이면 일반 SECS, 1:Select, 5:Linktest 등)
                    Dim stream As Byte = header(2) And &H7F     ' Stream 번호 추출 (W-Bit 최상위 비트 마스킹 제거)
                    Dim func As Byte = header(3)                 ' Function 번호 추출
                    Dim sysBytes(3) As Byte
                    Array.Copy(header, 6, sysBytes, 0, 4)        ' 동기화용 고유 System Bytes 4바이트 추출

                    logger.WriteLog($"[SOCKET STREAM] 패킷 조립 성공 -> S{stream}F{func}, Type: {sType}, 순수Body: {msgLength - 10} bytes")

                    ' 3. 제어 패킷과 데이터 패킷 분기 처리 핸들러 호출
                    If sType <> 0 Then
                        ' HSMS 자체 제어 메시지 처리 구역 (Select, Linktest, Separate)
                        HandleHsmsControl(sType, sysBytes)
                    Else
                        ' 순수 SECS-II 데이터 메시지 처리 구역
                        Dim bodySize As Integer = CInt(msgLength) - 10
                        Dim body() As Byte = New Byte() {}

                        ' 헤더 10바이트를 제외한 데이터 알맹이(Body)가 존재할 경우 바디 배열 적재
                        If bodySize > 0 Then
                            ReDim body(bodySize - 1)
                            Array.Copy(packetBytes, 14, body, 0, bodySize)
                        End If

                        HandleSecsMessage(stream, func, body)
                    End If
                End While
            End SyncLock

            ' 4. 다음 비동기 소켓 데이터 수신 상태로 대기 전환
            If clientSocket IsNot Nothing AndAlso clientSocket.Connected Then
                Dim nextBuffer(65535) As Byte
                clientSocket.BeginReceive(nextBuffer, 0, nextBuffer.Length, SocketFlags.None, AddressOf ReceiveCallback, nextBuffer)
            End If

        Catch ex As Exception
            logger.WriteLog($"[SOCKET CRITICAL] 스트림 동기화 최종 예외: {ex.Message} -> {ex.StackTrace}")
            DisconnectClient()
        End Try
    End Sub

    ''' <summary>
    ''' HSMS 규격 상의 제어 패킷(연결 수락, 링크 테스트 등)을 자동 응답 처리하는 핸들러입니다.
    ''' </summary>
    Private Sub HandleHsmsControl(sType As Byte, sysBytes As Byte())
        Select Case sType
            Case 1 ' Select.req (상대방이 통신 프로세스 시작을 요청함)
                logger.WriteLog("[RECV] HSMS Select.req")
                tmrT7.Stop() ' 연결이 정상 승인되었으므로 T7 타임아웃 타이머 정지

                ' 승인 응답 발송 (Select.rsp, 성공 코드 0,0,0,0 주입)
                SendControlResponse(2, sysBytes, New Byte() {0, 0, 0, 0})
                logger.WriteLog("[SEND] HSMS Select.rsp")

                ' [요구사항 6] 연결 성립 즉시 비즈니스 규격에 맞게 S6F95 (RCSMode = "F") 자동 전송
                Send_S6F95("F")

            Case 5 ' Linktest.req (상대방이 통신 회선 생존 여부를 체크함)
                logger.WriteLog("[RECV] HSMS Linktest.req")
                ' 즉시 응답 패킷 발송 (Linktest.rsp)
                SendControlResponse(6, sysBytes, New Byte() {})
                logger.WriteLog("[SEND] HSMS Linktest.rsp")

            Case 9 ' Separate.req (상대방이 소켓을 완전히 끊겠다고 정중히 통보함)
                logger.WriteLog("[RECV] HSMS Separate.req")
                DisconnectClient()
        End Select
    End Sub

    ''' <summary>
    ''' [핵심 4] 순수 SECS-II 메시지(S1, S6, S7 등) 스트림/펑션을 분기하여 가공하는 비즈니스 핸들러입니다.
    ''' </summary>
    Private Sub HandleSecsMessage(stream As Byte, func As Byte, body As Byte())
        Try
            logger.WriteLog($"[RECV] S{stream}F{func}")

            ' [방어] 디코더 가시화 함수 내부 오류로 전체 통신 루프가 다운되는 현상 완전 방어
            If body IsNot Nothing AndAlso body.Length > 0 Then
                Try
                    Dim parseIndex As Integer = 0
                    Dim asciiTree As String = SecsDecoder.DumpToAsciiTree(body, parseIndex)
                    logger.WriteLog($"[RECV S{stream}F{func} BODY 아스키 트리]" & Environment.NewLine & asciiTree)
                Catch exDecoder As Exception
                    logger.WriteLog($"[ERROR] 디코더 가시화 실패 (S{stream}F{func} 바디 파싱 에러): {exDecoder.Message}")
                End Try
            End If

            ' 스트림별 기능 상세 분석 분기
            Select Case stream
                Case 1
                    If func = 2 Then ' S1F2 Online Ack 수신 시
                        logger.WriteLog("[RECV] S1F2 Online Ack -> Send S6F95('H')")
                        ' 온라인 승인이 떨어졌으므로 장비 RCS 모드를 "H"로 변경 통보
                        Send_S6F95("H")
                    End If
                Case 7
                    If func = 83 Then ' S7F83 데이터 구조체 수신 시 내부 백업 및 메모리 로드 진행
                        logger.WriteLog("[SYSTEM] S7F83 구조체 데이터 내부 메모리 적재 백업 시작...")

                        ' [가시성] 원시 바이트 배열을 분석하기 좋게 16진수 바둑판 헥사 뷰문자열로 정형화 출력
                        Try
                            Dim cleanHexView As String = FormatBytesToHexView(body)
                            logger.WriteLog($"[DEBUG HEX VIEW] S7F83 Body ({body.Length} bytes):" & Environment.NewLine & cleanHexView)
                        Catch : End Try

                        ' 1. 기존 파싱 엔진 엔진을 기동하여 데이터를 임시 리스트에 복사
                        Dim parsedList As List(Of GlassInfoData) = Nothing
                        Try
                            parsedList = SecsDecoder.Parse_S7F83(body, SharedLotData)
                        Catch exParse As Exception
                            logger.WriteLog($"[CRITICAL] SecsDecoder.Parse_S7F83 내부 런타임 예외 발생: {exParse.Message}")
                        End Try

                        ' 2. [런타임 에러 완전 방어] 파싱 결과가 혹여나 Nothing일 경우 하부 .Count 호출 시 프로그램 튕김 발생 차단
                        If parsedList Is Nothing Then
                            logger.WriteLog("[WARNING] S7F83 파싱 결과가 빈 값(Nothing)입니다. 빈 리스트 인스턴스로 안전 보구합니다.")
                            SharedGlassList = New List(Of GlassInfoData)()
                        Else
                            SharedGlassList = parsedList
                        End If

                        logger.WriteLog($"[SYSTEM] 파싱 적재 완료! 저장된 Glass 개수: {SharedGlassList.Count}개")

                        ' =====================================================================
                        ' ★ 핵심 수정 포인트: S7F83 데이터 적재 완료 후 S6F81 연동 자동 전송
                        ' =====================================================================
                        logger.WriteLog("[SYSTEM] S7F83 데이터 적재 확인 완료 -> 이어서 S6F81 자동 연동 발송을 시작합니다.")

                        ' 파싱 단계에서 SharedLotData에 안착한 CstID를 꺼내어 전달합니다. (만약 비어있다면 UI 텍스트박스나 디폴트값 사용)
                        Dim targetCstId As String = SharedLotData.CstID
                        If String.IsNullOrEmpty(targetCstId) Then targetCstId = txtCstID.Text
                        If String.IsNullOrEmpty(targetCstId) Then targetCstId = "CSTCST000100"

                        ' 호스트(상대방)가 S7F83을 던지자마자 우리 응답을 처리할 시간이 필요하므로 200~300ms 살짝 쉬어준 뒤 보냅니다.
                        Threading.Thread.Sleep(200)
                        Send_S6F81(targetCstId)

                    End If
            End Select

        Catch ex As Exception
            ' 통신 최상위 메인 생존 방어선
            logger.WriteLog($"[FATAL ERROR] HandleSecsMessage 치명적 오류: {ex.Message} -> {ex.StackTrace}")
        End Try
    End Sub

    ' =========================================================================
    ' UI 버튼 액션 및 고유 송신 패킷 빌드 메커니즘 구역
    ' =========================================================================

    ''' <summary>
    ''' 온라인 요청 버튼 클릭 이벤트입니다. (S1F1 송신)
    ''' </summary>
    Private Sub btnOnline_Click(sender As Object, e As EventArgs) Handles btnOnline.Click
        ' 응답을 요구하므로 Stream 번호 최상위 비트(W-Bit)를 On 처리하여 &H81(S1, W-Bit On)로 생성
        Dim header() As Byte = CreateHeader(&H81, 1, 0)
        SendPacket(header, New Byte() {})
        logger.WriteLog("[SEND] S1F1 Online Request (W-Bit On: 81 01)")
    End Sub

    ''' <summary>
    ''' Lot 시작 이벤트 유저 동작 유도 버튼입니다. (S7F87 송신 및 S6F81 자동 전송)
    ''' </summary>
    Private Sub btnLotStart_Click(sender As Object, e As EventArgs) Handles btnLotStart.Click
        ' [보안 방어] UI 컨트롤 박스 자체가 누락되었거나 공백일 경우의 시스템 다운 완벽 보호
        Dim cstId As String = "CSTCST000100" ' 안전한 기본 디폴트 텍스트 할당

        If txtCstID IsNot Nothing AndAlso Not String.IsNullOrEmpty(txtCstID.Text) Then
            cstId = txtCstID.Text
        End If

        ' SECS 표준 바이너리 인코딩 구조 직접 빌딩 시작
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 7}) ' <L, 7> 리스트 선언
        body.AddRange(EncodeAscii("LCWLCW01", 16))
        body.AddRange(EncodeAscii("LCWLCW0101", 16))
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(EncodeAscii("H", 1))
        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeAscii(cstId, 14))
        body.AddRange(EncodeAscii("A", 1))

        ' Stream 7번 + W-Bit On (&H87) 헤더 조합 후 물리 소켓 전송
        SendPacket(CreateHeader(&H87, 87, 0), body.ToArray())
        logger.WriteLog($"[SEND] S7F87 LotStart Request (W-Bit On: 87 57, CSTID: {cstId.Trim()})")

        ' 현장 시나리오 상의 요구조건에 의거하여 300ms 인터벌을 준 뒤 S6F81 연속 자동 연동 전송 진행
        'Threading.Thread.Sleep(300)
        'end_S6F81(cstId)
    End Sub

    ''' <summary>
    ''' [핵심 3] 수신 적재해 두었던 S7F83 실데이터를 믹싱하여 정답 규격의 S6F77 LotEnd 패킷을 조립 송신합니다.
    ''' </summary>
    Private Sub btnLotEnd_Click(sender As Object, e As EventArgs) Handles btnLotEnd.Click
        Try
            Dim body As New List(Of Byte)()

            ' 1. 최상위 레이어 구조체 리스트 배치 빌딩 <L, 1> 하부 <L, 15>
            body.AddRange(New Byte() {&H1, 15})

            ' 상위 고정 명세 데이터 규격 바인딩 및 정밀 자릿수 패딩 채우기
            body.AddRange(EncodeAscii("H", 1))
            body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
            body.AddRange(EncodeAscii("LCWLCW0101", 16)) '장비 Sub EQP
            body.AddRange(EncodeAscii("", 16))
            body.AddRange(EncodeAscii("N", 1))

            ' [실데이터 믹싱] S7F83 수신 시 메모리에 보관해 둔 필드를 연동 (비어있을 시 디코더 오류 예방 디폴트 매핑)
            ' 변수에 먼저 담아두어 하단 루프 내 유효 슬롯 매핑 시 동일한 값을 사용하도록 합니다.
            Dim lotId As String = If(String.IsNullOrEmpty(SharedLotData.LotID), "LOTIDLOTID00", SharedLotData.LotID)
            body.AddRange(EncodeAscii(lotId, 16))

            'body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.CstID), "CSTCST000100", SharedLotData.CstID), 14))
            body.AddRange(EncodeAscii(ULDtxtCSTID.Text, 14))
            body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.RcpID), "RCPRCP11", SharedLotData.RcpID), 24))
            body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.PrcID), "44444", SharedLotData.PrcID), 8))

            body.AddRange(EncodeAscii("E", 1))
            body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.PortID), "1", SharedLotData.PortID), 16))
            body.AddRange(EncodeAscii("", 2))
            body.AddRange(EncodeAscii("N", 1))
            body.AddRange(New Byte() {&H1, 0}) ' 하부 공백 노드 세트 배치 <L, 0>

            ' 2. Glass 목록 컨테이너 빌딩 구역 (★현장 요구 규격: 무조건 11개 슬롯 세트 형태 고정 유지)
            body.AddRange(New Byte() {&H1, 1})  ' <L, 1>
            body.AddRange(New Byte() {&H1, 11}) ' 총 11개의 루프를 돌며 바디 구조 조립

            For slotNum As Integer = 1 To 11
                Dim targetGlass As GlassInfoData = Nothing
                Dim hasData As Boolean = False

                ' 수신 메모리 풀을 서칭하여 현재 루프 번호(1~11)에 대응하는 실데이터 Glass 가 존재치 체크
                For Each g As GlassInfoData In SharedGlassList
                    Dim savedSlot As Integer = 0
                    If Integer.TryParse(g.SlotID, savedSlot) AndAlso savedSlot = slotNum Then
                        targetGlass = g
                        hasData = True
                        Exit For
                    End If
                Next

                ' 개별 항목 규격 선언 : 진짜 로그 구조 매칭 <L, 12> 구조체 생성
                body.AddRange(New Byte() {&H1, 12})

                If hasData Then
                    ' [Case A] 메모리에 매핑에 성공했던 실제 유효 슬롯 데이터 부위 결합 기입 (5~11번 등)
                    body.AddRange(EncodeAscii(targetGlass.SlotID, 3))     ' <A[3]> 슬롯번호
                    body.AddRange(EncodeAscii(targetGlass.GlsID, 16))     ' <A[16]> GlassID
                    body.AddRange(EncodeBinary(targetGlass.SCode))        ' <B[1]> 바이너리 상태 코드
                    body.AddRange(EncodeAscii(targetGlass.GlsJudge, 2))   ' <A[2]> 판정 문자열
                    body.AddRange(EncodeAscii(targetGlass.PnlIf, 96))     ' <A[96]> Panel 정보
                    body.AddRange(EncodeAscii(targetGlass.SubMdlIf, 96))  ' <A[96]> SubMdl 정보
                    body.AddRange(EncodeAscii(targetGlass.SlotRcp, 24))   ' <A[24]> 레시피 명칭
                Else
                    ' [Case B] 빈 슬롯 공백 부위 (1~4번 등) - 정답 로그 매세 규격 원본 준수
                    body.AddRange(EncodeAscii(slotNum.ToString(), 3))     ' <A[3]> 슬롯 번호 강제 대입
                    body.AddRange(EncodeAscii("", 16))                    ' <A[16]> 공백 문자열
                    body.AddRange(EncodeBinary(New Byte() {&H0}))         ' <B[1]> 0x00 바이너리
                    body.AddRange(EncodeAscii("", 2))                     ' <A[2]> 공백
                    body.AddRange(EncodeAscii("", 96))                    ' <A[96]> 공백
                    body.AddRange(EncodeAscii("", 96))                    ' <A[96]> 공백
                    body.AddRange(EncodeAscii("", 24))                    ' <A[24]> 공백
                End If

                ' 개별 슬롯 구조 하단부 트리 고정 규격 양식 강제 생성부 복사 조립
                body.AddRange(EncodeAscii("0", 1))
                body.AddRange(EncodeAscii("2", 1))

                ' =====================================================================
                ' ★ 핵심 수정 포인트 반영 구역
                ' 매핑에 성공한 실제 유효 슬롯(hasData = True)에만 S7F83에서 받아온 LotID를 기입합니다.
                ' =====================================================================
                If hasData Then
                    body.AddRange(EncodeAscii(lotId, 16)) ' 상단에서 가져온 유효 LotID 주입
                Else
                    body.AddRange(EncodeAscii("0", 16))   ' 데이터가 없는 빈 슬롯은 기존 원본과 동일하게 "0" 처리
                End If
                ' =====================================================================

                body.AddRange(New Byte() {&H1, 0})  ' <L, 0>
                body.AddRange(New Byte() {&H1, 1})  ' <L, 1>
                body.AddRange(New Byte() {&H1, 0})  ' <L, 0>
            Next

            ' 조립 완성된 최종 대형 로우 바이너리 팩을 전송 (S6F77 헤더 장착)
            SendPacket(CreateHeader(&H86, 77, 0), body.ToArray())
            logger.WriteLog($"[SEND] S6F77 LotEnd 정답 규격 패킷 전송 성공 (적재 데이터 매핑 완료, LotID: {lotId})")

        Catch ex As Exception
            logger.WriteLog($"[ERROR] btnLotEnd_Click 런타임 예외 발생: {ex.Message}")
        End Try
    End Sub

    ' =========================================================================
    ' 하부 로우레벨 제어/송신 패킷 빌더 래핑 유틸리티
    ' =========================================================================

    ''' <summary>
    ''' 장비 제어 권한 모드 전환 이벤트를 호스트에 던집니다. (S6F95 송신)
    ''' </summary>
    Private Sub Send_S6F95(rcsMode As String)
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 5})
        body.AddRange(EncodeAscii(rcsMode, 1))
        body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
        body.AddRange(EncodeAscii("LCWLCW0101", 16)) ''장비 Sub EQP
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(New Byte() {&H1, 1})
        body.AddRange(New Byte() {&H1, 3})
        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeAscii("E", 1))
        body.AddRange(EncodeBinary(New Byte() {&H1}))

        ' 헤더를 W-Bit 가 활성화된 0x86 (Stream6, W-Bit On) 형식으로 정상 보정 송신
        SendPacket(CreateHeader(&H86, 95, 0), body.ToArray())
        logger.WriteLog($"[SEND] S6F95 RCS Msg Sent (W-Bit On: 86 5F, Mode: {rcsMode})")
    End Sub

    ''' <summary>
    ''' 카세트 투입 인식 이벤트를 연동 송신합니다. (S6F81 송신)
    ''' </summary>
    Private Sub Send_S6F81(cstId As String)
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 12})
        body.AddRange(EncodeAscii("H", 1))
        body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
        body.AddRange(EncodeAscii("LCWLCW0101", 16)) ''장비 Sub EQP
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(EncodeAscii("N", 1))
        body.AddRange(EncodeAscii(cstId, 14))

        ' [보정 완료] 기존 하드코딩 구역을 수신 보관 중이던 실데이터 레시피 아이디와 안전하게 바인딩 처리 완료
        body.AddRange(EncodeAscii(SharedLotData.RcpID, 24))

        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeBinary(New Byte() {&H0}))
        body.AddRange(EncodeAscii(SharedLotData.LotID, 16))
        body.AddRange(EncodeAscii("P", 1))
        body.AddRange(EncodeAscii("", 2))

        ' Stream 6번 + W-Bit On (&H86) 조합 전송
        SendPacket(CreateHeader(&H86, 81, 0), body.ToArray())
        logger.WriteLog($"[SEND] S6F81 Msg Sent (W-Bit On: 86 51)")
    End Sub

    ''' <summary>
    ''' HSMS 표준 규격에 부합하는 10바이트 고유 메시지 헤더 구조를 정밀 조합 반환합니다.
    ''' </summary>
    Private Function CreateHeader(stream As Byte, func As Byte, sType As Byte) As Byte()
        Dim header(9) As Byte

        ' 1. Device ID 인코딩 (2바이트 공간 - 상위/하위 나누어 Big Endian 주입)
        header(0) = CByte((SET_DEVICE_ID >> 8) And &HFF)
        header(1) = CByte(SET_DEVICE_ID And &HFF)

        ' 2. 통신 스트림 번호, 펑션 번호, 메시지 유형 주입
        header(2) = stream
        header(3) = func
        header(4) = 0 ' PType 규격은 표준상 무조건 0 고정
        header(5) = sType

        ' 3. 고유 System Bytes 4바이트 처리 (네트워크 표준 순서 배정)
        ' 매 송신 메시지마다 카운터 일련번호를 1씩 고유 누적 가산합니다.
        SystemBytesCounter += 1

        header(6) = CByte((SystemBytesCounter >> 24) And &HFF)
        header(7) = CByte((SystemBytesCounter >> 16) And &HFF)
        header(8) = CByte((SystemBytesCounter >> 8) And &HFF)
        header(9) = CByte(SystemBytesCounter And &HFF)

        Return header
    End Function

    ''' <summary>
    ''' 완성된 헤더와 바디 정보를 최종 결합하여 4바이트 길이 필드를 동반한 로우 패킷을 소켓에 직접 밀어 넣습니다.
    ''' </summary>
    Private Sub SendPacket(header As Byte(), body As Byte())
        Try
            ' 소켓 정상 생존 유무 가드 코드
            If clientSocket Is Nothing OrElse Not clientSocket.Connected Then Exit Sub

            ' 총 패킷 바디 길이 계산 = 헤더 공간(10바이트) + 바디 내용 크기
            Dim totalLen As UInteger = 10 + CUInt(body.Length)
            Dim lenBytes() As Byte = BitConverter.GetBytes(totalLen)

            ' 엔디안 포맷 바이트 정렬 변환
            If BitConverter.IsLittleEndian Then Array.Reverse(lenBytes)

            ' 전체 최종 송신 바이트 팩 어레이 선언 및 복사 진행
            Dim packet(4 + 10 + body.Length - 1) As Byte
            Array.Copy(lenBytes, 0, packet, 0, 4)
            Array.Copy(header, 0, packet, 4, 10)
            If body.Length > 0 Then Array.Copy(body, 0, packet, 14, body.Length)

            ' 동기 실데이터 소켓 전송
            clientSocket.Send(packet)

            ' [추가] 내가 송신 처리한 패킷의 바이너리 알맹이도 분석 편의를 위해 아스키 트리 형태로 가시화 로그 적재
            If body IsNot Nothing AndAlso body.Length > 0 Then
                Dim stream As Byte = header(2) And &H7F
                Dim func As Byte = header(3)
                Dim parseIndex As Integer = 0
                Dim asciiTree As String = SecsDecoder.DumpToAsciiTree(body, parseIndex)
                logger.WriteLog($"[SEND S{stream}F{func} BODY 아스키 트리]" & Environment.NewLine & asciiTree)
            End If

        Catch ex As Exception
            logger.WriteLog($"[ERROR] Send Fail: {ex.Message}")
        End Try
    End Sub

    ''' <summary>
    ''' 제어 메시지에 대응하는 승인 응답용 패킷 전송용 유틸 단축 함수입니다.
    ''' </summary>
    Private Sub SendControlResponse(sType As Byte, sysBytes As Byte(), body As Byte())
        Try
            Dim header(9) As Byte
            header(0) = &HFF : header(1) = &HFF ' 제어 응답의 Device ID 필드는 상위 표준 규격상 0xFFFF 고정
            header(5) = sType
            Array.Copy(sysBytes, 0, header, 6, 4) ' 상대방이 보냈던 일련번호 그대로 반사 매핑(동기화 핵심)
            SendPacket(header, body)
        Catch
        End Try
    End Sub

    ''' <summary>
    ''' 일반 문자열(String) 데이터를 SECS 표준 구조 아스키 형태[0x41] 바이트 배열로 자동 인코딩합니다.
    ''' </summary>
    Private Function EncodeAscii(txt As String, len As Integer) As Byte()
        ' [★ 런타임 에러 완전 방어] 인자로 넘어온 데이터 문자열이 Nothing(Null)일 경우에도 
        ' .PadRight 함수 호출에서 시스템이 다운되지 않도록 공백 문자로 자동 안전 우회 변환
        If txt Is Nothing Then txt = ""

        ' 지정된 전체 고정 길이에 도달할 때까지 우측에 빈 공백 패딩 주입
        Dim raw() As Byte = Encoding.ASCII.GetBytes(txt.PadRight(len))

        ' SECS 데이터 포맷 식별자 [0x41 = ASCII 타입]와 길이값을 헤드로 삽입하여 결합 반환
        Dim res As New List(Of Byte) From {&H41, CByte(len And &HFF)}
        res.AddRange(raw)
        Return res.ToArray()
    End Function

    ''' <summary>
    ''' 순수 바이트 배열을 SECS 표준 구조 바이너리 형태[0x21] 바이트 배열로 인코딩합니다.
    ''' </summary>
    Private Function EncodeBinary(data As Byte()) As Byte()
        ' SECS 데이터 포맷 식별자 [0x21 = BINARY 타입]
        Dim res As New List(Of Byte) From {&H21, CByte(data.Length And &HFF)}
        res.AddRange(data)
        Return res.ToArray()
    End Function

    ''' <summary>
    ''' 연결 수립 후 일정 시간(T7) 동안 무반응 방치 시 클라이언트를 강제 강등 탈퇴시키는 타이머 틱 이벤트입니다.
    ''' </summary>
    Private Sub tmrT7_Tick(sender As Object, e As EventArgs) Handles tmrT7.Tick
        logger.WriteLog("[TIMEOUT] T7 Timeout! No Select.req.")
        DisconnectClient()
    End Sub

    ''' <summary>
    ''' [핵심 5] 작동중인 클라이언트 소켓 세션을 안전하고 확실하게 닫고 사용하던 시스템 자원을 운영체제에 즉시 반납합니다.
    ''' </summary>
    Private Sub DisconnectClient()
        Try
            If clientSocket IsNot Nothing Then
                logger.WriteLog("[SYSTEM] 클라이언트 소켓 자원 해제 진행...")

                ' 연결이 살아있다면 양방향 송수신 통로를 먼저 안전하게 소프트 차단
                If clientSocket.Connected Then
                    clientSocket.Shutdown(SocketShutdown.Both)
                End If

                ' 소켓 커넥션 클로즈
                clientSocket.Close()
                clientSocket = Nothing ' 완전히 비워주어야 'ReceiveCallback' 내부 가드 구문이 정상 반응을 인지함
                logger.WriteLog("[SYSTEM] 소켓 연결이 안전하게 완전히 해제되었습니다.")
            End If
        Catch ex As Exception
            logger.WriteLog($"[ERROR] DisconnectClient 오류: {ex.Message}")
        Finally
            clientSocket = Nothing
            isConnected = False
        End Try
    End Sub

    ''' <summary>
    ''' 윈도우 폼 창이 완전히 닫히기 직전 실행되는 파괴자 성격의 이벤트 함수입니다.
    ''' </summary>
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' 실행 중이던 하부 통신 채널 자원 및 활성화된 파일 스트림을 순차적으로 완전 격리 소멸 처리 진행
        DisconnectClient()
        If serverSocket IsNot Nothing Then serverSocket.Stop()
        If logger IsNot Nothing Then logger.CloseFile()
    End Sub

    ''' <summary>
    ''' 로우 바이트 배열 데이터를 우측 아스키 창을 제외한 순수 16진수 바둑판 헥사(Hex) 뷰 꼴로 깔끔하게 문자열 변환합니다.
    ''' </summary>
    Private Shared Function FormatBytesToHexView(bytes As Byte()) As String
        If bytes Is Nothing OrElse bytes.Length = 0 Then Return "No Data"

        Dim sb As New System.Text.StringBuilder()
        Dim lineLength As Integer = 16 ' 가로 가독성 한계선인 16바이트 정렬

        For i As Integer = 0 To bytes.Length - 1 Step lineLength
            ' 1. 좌측 오프셋 인덱스 번호 마킹 (예: 00000020:)
            sb.Append(i.ToString("X8") & ": ")

            ' 2. 16바이트 가로 배열 나열 실행
            For j As Integer = 0 To lineLength - 1
                If (i + j) < bytes.Length Then
                    sb.Append(bytes(i + j).ToString("X2") & " ")
                Else
                    sb.Append("   ") ' 데이터가 마감되어 채워지지 못한 빈 슬롯 공간 정렬용 공백 확보
                End If
            Next

            sb.AppendLine()
        Next

        Return sb.ToString()
    End Function
End Class
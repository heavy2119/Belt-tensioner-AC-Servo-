﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rtbLog = New System.Windows.Forms.RichTextBox()
        Me.btnOnline = New System.Windows.Forms.Button()
        Me.btnLotStart = New System.Windows.Forms.Button()
        Me.btnLotEnd = New System.Windows.Forms.Button()
        Me.txtCstID = New System.Windows.Forms.TextBox()
        Me.ULDtxtCSTID = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'rtbLog
        '
        Me.rtbLog.Location = New System.Drawing.Point(12, 89)
        Me.rtbLog.Name = "rtbLog"
        Me.rtbLog.Size = New System.Drawing.Size(1159, 479)
        Me.rtbLog.TabIndex = 0
        Me.rtbLog.Text = ""
        '
        'btnOnline
        '
        Me.btnOnline.Location = New System.Drawing.Point(12, 12)
        Me.btnOnline.Name = "btnOnline"
        Me.btnOnline.Size = New System.Drawing.Size(75, 23)
        Me.btnOnline.TabIndex = 1
        Me.btnOnline.Text = "btnOnline"
        Me.btnOnline.UseVisualStyleBackColor = True
        '
        'btnLotStart
        '
        Me.btnLotStart.Location = New System.Drawing.Point(105, 12)
        Me.btnLotStart.Name = "btnLotStart"
        Me.btnLotStart.Size = New System.Drawing.Size(75, 23)
        Me.btnLotStart.TabIndex = 2
        Me.btnLotStart.Text = "btnLotStart"
        Me.btnLotStart.UseVisualStyleBackColor = True
        '
        'btnLotEnd
        '
        Me.btnLotEnd.Location = New System.Drawing.Point(206, 12)
        Me.btnLotEnd.Name = "btnLotEnd"
        Me.btnLotEnd.Size = New System.Drawing.Size(75, 23)
        Me.btnLotEnd.TabIndex = 3
        Me.btnLotEnd.Text = "btnLotEnd"
        Me.btnLotEnd.UseVisualStyleBackColor = True
        '
        'txtCstID
        '
        Me.txtCstID.Location = New System.Drawing.Point(315, 12)
        Me.txtCstID.Name = "txtCstID"
        Me.txtCstID.Size = New System.Drawing.Size(205, 21)
        Me.txtCstID.TabIndex = 4
        Me.txtCstID.Text = "LDCSTID"
        '
        'ULDtxtCSTID
        '
        Me.ULDtxtCSTID.Location = New System.Drawing.Point(547, 14)
        Me.ULDtxtCSTID.Name = "ULDtxtCSTID"
        Me.ULDtxtCSTID.Size = New System.Drawing.Size(205, 21)
        Me.ULDtxtCSTID.TabIndex = 5
        Me.ULDtxtCSTID.Text = "ULDCSTID"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1183, 580)
        Me.Controls.Add(Me.ULDtxtCSTID)
        Me.Controls.Add(Me.txtCstID)
        Me.Controls.Add(Me.btnLotEnd)
        Me.Controls.Add(Me.btnLotStart)
        Me.Controls.Add(Me.btnOnline)
        Me.Controls.Add(Me.rtbLog)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rtbLog As RichTextBox
    Friend WithEvents btnOnline As Button
    Friend WithEvents btnLotStart As Button
    Friend WithEvents btnLotEnd As Button
    Friend WithEvents txtCstID As TextBox
    Friend WithEvents ULDtxtCSTID As TextBox
End Class

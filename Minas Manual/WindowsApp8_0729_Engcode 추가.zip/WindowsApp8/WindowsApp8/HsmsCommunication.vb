﻿
Imports System.Net
Imports System.Net.Sockets
Imports System.Collections.Generic
Imports System.Text
Partial Public Class Form1

    ' --- 네트워크 소켓 엔진 변수 ---
    Private serverSocket As TcpListener       ' 상대방(Active)의 접속을 기다리는 서버 리스너 소켓
    Private clientSocket As Socket            ' 실제 연결이 수립된 클라이언트 세션 소켓
    Private isConnected As Boolean = False     ' 현재 통신 연결 성공 여부 플래그
    Private SystemBytesCounter As UInteger = 1 ' SECS 메시지 동기화용 고유 일련번호 (4바이트 카운터)

    ' --- 타이머 제어 변수 ---
    Private WithEvents tmrT7 As New Timer()   ' T7 타임아웃(연결 후 Select.req 수신 대기 제한 시간) 관리 타이머

    ''' <summary>
    ''' 서버 소켓을 열고 클라이언트의 비동기 접속 대기 상태를 시작합니다.
    ''' </summary>
    Private Sub StartHsmsServer()
        Try
            ' 내부 모든 네트워크 카드(Any)와 설정된 포트(7000)를 바인딩하여 대기
            serverSocket = New TcpListener(IPAddress.Any, SET_PORT)
            serverSocket.Start()
            logger.WriteLog($"[SYSTEM] HSMS Server Open (Port: {SET_PORT}, Passive Mode)")

            ' 비동기 접속 수락 시작 (대기 상태 중에도 메인 UI가 멈추지 않음)
            serverSocket.BeginAcceptSocket(AddressOf AcceptCallback, Nothing)
        Catch ex As Exception
            logger.WriteLog($"[ERROR] Server Start Fail: {ex.Message}")
        End Try
    End Sub

    ''' <summary>
    ''' 클라이언트가 실제로 접속했을 때 호출되는 비동기 콜백 함수입니다.
    ''' </summary>
    Private Sub AcceptCallback(ar As IAsyncResult)
        Try
            ' 접속한 클라이언트 소켓 세션을 인스턴스에 할당
            clientSocket = serverSocket.EndAcceptSocket(ar)
            isConnected = True
            logger.WriteLog($"[SYSTEM] Client Connected: {clientSocket.RemoteEndPoint.ToString()}")

            ' [신규] Socket 연결은 완료되었지만 아직 Online 승인 상태는 아니므로 OFFLINE으로 표시합니다.
            ' 연결 완료 상태를 작업자에게 명확히 보여주기 위해 Lamp#1을 Red로 표시합니다.
            UpdateLampStatus("OFFLINE", Color.Red)

            ' [HSMS 표준 규격] 연결은 맺어졌으므로, T7 타이머를 가동하여 정해진 시간 내에 Select.req가 오는지 감시 시작
            tmrT7.Start()

            ' 데이터 수신용 버퍼(64KB)를 개설하고 비동기 데이터 수신(Receive) 대기 전송
            Dim buffer(65535) As Byte
            clientSocket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, AddressOf ReceiveCallback, buffer)

            ' 다음 대형 후속 클라이언트 접속을 위해 서버 소켓 접속 수락 대기를 재호출 (멀티 세션 예방 가드)
            serverSocket.BeginAcceptSocket(AddressOf AcceptCallback, Nothing)
        Catch ex As Exception
            logger.WriteLog($"[ERROR] Accept Error: {ex.Message}")
        End Try
    End Sub

    ' TCP 스트림 파편화/뭉침 현상을 완벽 방어하기 위한 바이트 누적 버퍼
    Private streamBuffer As New List(Of Byte)()

    ''' <summary>
    ''' [핵심 2] 소켓을 통해 로우 데이터(바이트)가 들어올 때마다 호출되는 정밀 패킷 정형화 엔진입니다.
    ''' </summary>
    Private Sub ReceiveCallback(ar As IAsyncResult)
        Dim buffer As Byte() = CType(ar.AsyncState, Byte())
        If clientSocket Is Nothing Then Exit Sub

        Try
            ' 소켓으로부터 실제 읽어온 바이트 크기를 반환받음
            Dim bytesRead As Integer = clientSocket.EndReceive(ar)

            ' 상대방이 정상적으로 소켓 연결을 종료(Shutdown)한 경우 0 바이트가 들어옵니다.
            If bytesRead = 0 Then
                logger.WriteLog("[INFO] Active가 연결을 먼저 종료했습니다. (bytesRead = 0)")
                DisconnectClient()
                Exit Sub
            End If

            ' 멀티스레드 환경에서 누적 스트림 버퍼가 꼬이지 않도록 동기화 락(SyncLock)을 겁니다.
            SyncLock streamBuffer
                ' 1. 이번에 새로 들어온 바이트 덩어리를 임시 배열에 복사 후 누적 스트림 버퍼 뒤에 병합
                Dim tempBytes(bytesRead - 1) As Byte
                Array.Copy(buffer, 0, tempBytes, 0, bytesRead)
                streamBuffer.AddRange(tempBytes)

                ' 2. 누적 버퍼 내에서 완전한 패킷 단위(헤더4바이트 크기 기반)로 정밀 컷팅 반복 실행
                While streamBuffer.Count >= 4
                    ' 앞의 4바이트를 복사하여 전체 메시지 길이(MsgLength) 파악 진행
                    Dim msgLenBytes(3) As Byte
                    streamBuffer.CopyTo(0, msgLenBytes, 0, 4)

                    ' 네트워크 표준(Big Endian)에서 C#/.NET 표준(Little Endian) 환경으로 바이트 역전 처리
                    If BitConverter.IsLittleEndian Then Array.Reverse(msgLenBytes)
                    Dim msgLength As UInteger = BitConverter.ToUInt32(msgLenBytes, 0)

                    ' [보안 방어막] 비정상적인 유령 크기(5MB 초과)가 오면 소켓 버퍼 오염으로 간주하고 즉시 초기화하여 좀비 상태 방지
                    If msgLength > 5000000 Then
                        logger.WriteLog($"[SOCKET WARNING] 유령 패킷 크기 감지({msgLength} 바이트). 스트림 리셋을 실시합니다.")
                        streamBuffer.Clear()
                        Exit While
                    End If

                    ' 전체 패킷 실제 크기 = 길이 헤더 공간(4바이트) + 알맹이 데이터 길이(msgLength)
                    Dim totalPacketSize As Integer = CInt(msgLength) + 4

                    ' [완전성 검사] 버퍼에 쌓인 데이터가 계산된 전체 패킷 크기보다 작다면 데이터가 아직 덜 온 것입니다.
                    ' 다음 비동기 데이터가 뒤에 더 붙을 때까지 가공하지 않고 루프를 즉시 탈출합니다. (TCP 파편화 방어 핵심)
                    If streamBuffer.Count < totalPacketSize Then
                        Exit While
                    End If

                    ' 완벽한 패킷 하나가 통째로 다 수집되었으므로 가공 시작
                    Dim packetBytes(totalPacketSize - 1) As Byte
                    streamBuffer.CopyTo(0, packetBytes, 0, totalPacketSize)

                    ' 처리할 분량만큼 누적 버퍼의 앞부분을 완전히 도려내어 인덱스 꼬임을 차단합니다.
                    streamBuffer.RemoveRange(0, totalPacketSize)

                    ' 실제 헤더 10바이트 추출 (앞의 4바이트 길이 정보 스킵한 위치부터 시작)
                    Dim header(9) As Byte
                    Array.Copy(packetBytes, 4, header, 0, 10)

                    Dim sType As Byte = header(5)               ' HSMS 제어 메시지 타입 (0이면 일반 SECS, 1:Select, 5:Linktest 등)
                    Dim stream As Byte = header(2) And &H7F     ' Stream 번호 추출 (W-Bit 최상위 비트 마스킹 제거)
                    Dim func As Byte = header(3)                 ' Function 번호 추출
                    Dim sysBytes(3) As Byte
                    Array.Copy(header, 6, sysBytes, 0, 4)        ' 동기화용 고유 System Bytes 4바이트 추출

                    logger.WriteLog($"[SOCKET STREAM] 패킷 조립 성공 -> S{stream}F{func}, Type: {sType}, 순수Body: {msgLength - 10} bytes")

                    ' 3. 제어 패킷과 데이터 패킷 분기 처리 핸들러 호출
                    If sType <> 0 Then
                        ' HSMS 자체 제어 메시지 처리 구역 (Select, Linktest, Separate)
                        HandleHsmsControl(sType, sysBytes)
                    Else
                        ' 순수 SECS-II 데이터 메시지 처리 구역
                        Dim bodySize As Integer = CInt(msgLength) - 10
                        Dim body() As Byte = New Byte() {}

                        ' 헤더 10바이트를 제외한 데이터 알맹이(Body)가 존재할 경우 바디 배열 적재
                        If bodySize > 0 Then
                            ReDim body(bodySize - 1)
                            Array.Copy(packetBytes, 14, body, 0, bodySize)
                        End If

                        HandleSecsMessage(stream, func, body)
                    End If
                End While
            End SyncLock

            ' 4. 다음 비동기 소켓 데이터 수신 상태로 대기 전환
            If clientSocket IsNot Nothing AndAlso clientSocket.Connected Then
                Dim nextBuffer(65535) As Byte
                clientSocket.BeginReceive(nextBuffer, 0, nextBuffer.Length, SocketFlags.None, AddressOf ReceiveCallback, nextBuffer)
            End If

        Catch ex As Exception
            logger.WriteLog($"[SOCKET CRITICAL] 스트림 동기화 최종 예외: {ex.Message} -> {ex.StackTrace}")
            DisconnectClient()
        End Try
    End Sub

    ''' <summary>
    ''' HSMS 규격 상의 제어 패킷(연결 수락, 링크 테스트 등)을 자동 응답 처리하는 핸들러입니다.
    ''' </summary>
    Private Sub HandleHsmsControl(sType As Byte, sysBytes As Byte())
        Select Case sType
            Case 1 ' Select.req (상대방이 통신 프로세스 시작을 요청함)
                logger.WriteLog("[RECV] HSMS Select.req")
                tmrT7.Stop() ' 연결이 정상 승인되었으므로 T7 타임아웃 타이머 정지

                ' 승인 응답 발송 (Select.rsp, 성공 코드 0,0,0,0 주입)
                SendControlResponse(2, sysBytes, New Byte() {0, 0, 0, 0})
                logger.WriteLog("[SEND] HSMS Select.rsp")

                ' [요구사항 6] 연결 성립 즉시 비즈니스 규격에 맞게 S6F95 (RCSMode = "F") 자동 전송
                Send_S6F95("F")

            Case 5 ' Linktest.req (상대방이 통신 회선 생존 여부를 체크함)
                logger.WriteLog("[RECV] HSMS Linktest.req")
                ' 즉시 응답 패킷 발송 (Linktest.rsp)
                SendControlResponse(6, sysBytes, New Byte() {})
                logger.WriteLog("[SEND] HSMS Linktest.rsp")

            Case 9 ' Separate.req (상대방이 소켓을 완전히 끊겠다고 정중히 통보함)
                logger.WriteLog("[RECV] HSMS Separate.req")
                DisconnectClient()
        End Select
    End Sub

    ''' <summary>
    ''' [핵심 4] 순수 SECS-II 메시지(S1, S6, S7 등) 스트림/펑션을 분기하여 가공하는 비즈니스 핸들러입니다.
    ''' </summary>
    Private Sub HandleSecsMessage(stream As Byte, func As Byte, body As Byte())
        Try
            logger.WriteLog($"[RECV] S{stream}F{func}")

            ' [방어] 디코더 가시화 함수 내부 오류로 전체 통신 루프가 다운되는 현상 완전 방어
            If body IsNot Nothing AndAlso body.Length > 0 Then
                Try
                    Dim parseIndex As Integer = 0
                    Dim asciiTree As String = SecsDecoder.DumpToAsciiTree(body, parseIndex)
                    logger.WriteLog($"[RECV S{stream}F{func} BODY 아스키 트리]" & Environment.NewLine & asciiTree)
                Catch exDecoder As Exception
                    logger.WriteLog($"[ERROR] 디코더 가시화 실패 (S{stream}F{func} 바디 파싱 에러): {exDecoder.Message}")
                End Try
            End If

            Dim lastA120Message As String = ""
            Dim hasLastA120Message As Boolean = False

            If body IsNot Nothing AndAlso body.Length > 0 Then
                Try
                    hasLastA120Message = SecsDecoder.TryReadLastAsciiItem(body, 120, lastA120Message)

                    If hasLastA120Message Then
                        logger.WriteLog($"[A120 MESSAGE] S{stream}F{func} 마지막 ASCII 메시지 수신: {lastA120Message}")
                        ShowErrorPopup($"[장비 회신 오류 메시지 수신]{vbCrLf}S{stream}F{func}{vbCrLf}{vbCrLf}{lastA120Message}")
                    End If
                Catch exA120 As Exception
                    logger.WriteLog($"[ERROR] A120 메시지 감지 실패 (S{stream}F{func}): {exA120.Message}")
                End Try
            End If

            ' 스트림별 기능 상세 분석 분기
            Select Case stream
                Case 1
                    If func = 2 Then ' S1F2 Online Ack 수신 시
                        logger.WriteLog("[RECV] S1F2 Online Ack -> Send S6F95('H')")
                        ' 온라인 승인이 떨어졌으므로 장비 RCS 모드를 "H"로 변경 통보

                        ' [신규] S1F2 응답을 정상 수신했으므로 장비 Online 상태로 판단합니다.
                        ' 작업자 화면의 Lamp#1을 ONLINE / Green 상태로 갱신합니다.
                        UpdateLampStatus("ONLINE", Color.Green)

                        Send_S6F95("H")

                        ' ★ 추가 포인트: S1F74 수신 처리
                    ElseIf func = 74 Then
                        logger.WriteLog("[RECV] S1F74 Structure Data Acknowledge 수신 완료")
                        ' 필요 시 여기에 바디 파싱 로직 연동 (예: SecsDecoder.Parse_S1F74(body))
                    End If

                Case 2
                    ' ★ 추가 포인트: S2F18 수신 처리
                    If func = 18 Then
                        logger.WriteLog("[RECV] S2F18 Date and Time Data (시간 회신) 수신 완료")
                        ' 보통 시간 데이터 <A[12]> 이거나 <A[16]> 구조체 형태로 옴
                    End If

                Case 7
                    If func = 83 Then ' S7F83 데이터 구조체 수신 시 내부 백업 및 메모리 로드 진행
                        logger.WriteLog("[SYSTEM] S7F83 구조체 데이터 내부 메모리 적재 백업 시작...")

                        ' [가시성] 원시 바이트 배열을 분석하기 좋게 16진수 바둑판 헥사 뷰문자열로 정형화 출력
                        Try
                            Dim cleanHexView As String = FormatBytesToHexView(body)
                            logger.WriteLog($"[DEBUG HEX VIEW] S7F83 Body ({body.Length} bytes):" & Environment.NewLine & cleanHexView)
                        Catch : End Try

                        ' 1. 기존 파싱 엔진 엔진을 기동하여 데이터를 임시 리스트에 복사
                        Dim parsedLotData As New LotInfoData()
                        Dim parsedList As List(Of GlassInfoData) = Nothing
                        Try
                            parsedList = SecsDecoder.Parse_S7F83(body, parsedLotData)
                            If Not String.IsNullOrWhiteSpace(parsedLotData.RcpID) Then
                                SetRcpIdText(parsedLotData.RcpID)
                            End If


                        Catch exParse As Exception
                            logger.WriteLog($"[CRITICAL] SecsDecoder.Parse_S7F83 내부 런타임 예외 발생: {exParse.Message}")
                        End Try
                        If parsedList Is Nothing Then
                            logger.WriteLog("[WARNING] S7F83 파싱 결과가 빈 값(Nothing)입니다. 빈 리스트로 처리합니다.")
                            parsedList = New List(Of GlassInfoData)()
                        End If
                        logger.WriteLog($"[SYSTEM] S7F83 파싱 완료! Glass 개수: {parsedList.Count}개")
                        SetLDGLSCount(parsedList.Count)

                        ' ============================================================
                        ' [RCP_CONFIRM_TEST_BLOCK_START]
                        ' S7F83 ENGCODE=1일 때 Operator RCP 확인/변경 창 처리
                        '
                        ' 위치:
                        '   Parse_S7F83 완료 후
                        '   SharedLotData / SaveS7F83ToEmptyRoom 실행 전
                        '
                        ' 동작:
                        '   ENGCODE=0 -> 기존 흐름 그대로 진행
                        '   ENGCODE=1 -> RcpConfirmForm 표시
                        '       OK     -> parsedLotData / parsedList를 변경값으로 교체 후 진행
                        '       Cancel -> S7F83 저장 및 S6F81 진행 중단
                        '
                        ' 실전 프로그램 이식 시:
                        '   이 블록을 S7F83 파싱 완료 직후, LOT 저장 전 위치로 이동
                        ' ============================================================

                        Dim engCode As String = ""

                        If Not TryReadS7F83EngCode(body, engCode) Then
                            engCode = "0"
                            logger.WriteLog("[WARNING] S7F83 ENGCODE 읽기 실패 - 기본값 0으로 처리합니다.")
                        End If

                        logger.WriteLog($"[SYSTEM] S7F83 ENGCODE 확인: {engCode}")

                        If engCode.Trim() = "1" Then
                            Dim confirmResult As DialogResult = DialogResult.Cancel
                            Dim confirmedLotData As LotInfoData = parsedLotData
                            Dim confirmedGlassList As List(Of GlassInfoData) = parsedList

                            Dim showConfirmAction As MethodInvoker =
        Sub()
            Using confirmForm As New RcpConfirmForm()
                confirmForm.SetLotData(parsedLotData, parsedList, engCode)

                confirmResult = confirmForm.ShowDialog(Me)

                If confirmResult = DialogResult.OK Then
                    confirmedLotData = confirmForm.EditedLotData
                    confirmedGlassList = confirmForm.EditedGlassList
                End If
            End Using
        End Sub

                            If Me.InvokeRequired Then
                                Me.Invoke(showConfirmAction)
                            Else
                                showConfirmAction.Invoke()
                            End If

                            If confirmResult <> DialogResult.OK Then
                                logger.WriteLog("[SYSTEM] Operator RCP 확인 취소 - S7F83 LOT 저장 및 S6F81 진행 중단")
                                Exit Sub
                            End If

                            parsedLotData = confirmedLotData
                            parsedList = confirmedGlassList

                            If Not String.IsNullOrWhiteSpace(parsedLotData.RcpID) Then
                                SetRcpIdText(parsedLotData.RcpID)
                            End If

                            logger.WriteLog($"[SYSTEM] Operator RCP 확인 완료 - 변경 Main RCP: {parsedLotData.RcpID}")
                        End If

                        ' ============================================================
                        ' [RCP_CONFIRM_TEST_BLOCK_END]
                        ' ============================================================

                        SharedLotData = parsedLotData
                        SharedGlassList = parsedList

                        Dim savedOk As Boolean = SaveS7F83ToEmptyRoom(parsedLotData, parsedList)

                        ' =====================================================================
                        ' ★ 핵심 수정 포인트: S7F83 데이터 적재 완료 후 S6F81 연동 자동 전송
                        ' =====================================================================
                        If savedOk Then
                            logger.WriteLog("[SYSTEM] S7F83 데이터 저장 완료 -> 이어서 S6F81 자동 연동 발송을 시작합니다.")

                            Dim targetCstId As String = parsedLotData.CstID
                            If String.IsNullOrEmpty(targetCstId) Then targetCstId = txtCstID.Text
                            If String.IsNullOrEmpty(targetCstId) Then targetCstId = "CSTCST000100"

                            Threading.Thread.Sleep(200)
                            Send_S6F81(targetCstId)
                        Else
                            logger.WriteLog("[WARNING] S7F83 저장 실패로 인해 S6F81 자동 송신은 수행하지 않습니다.")
                        End If

                    End If

                Case 10
                    If func = 3 Then
                        logger.WriteLog("[RECV] S10F3 Terminal Display Single 메시지 수신")

                        Try
                            ' S10F3 표준 구조는 대개 <L, 2> 구조 내부에 [TID(B1)], [TEXT(An)] 가 들어있거나,
                            ' 단순하게 단일 노드로 <A[n], "메시지내용">만 들어오는 경우가 많습니다.
                            ' 안전하게 처리하기 위해 SECS 구조를 파싱하여 마지막 ASCII 문자열만 추출합니다.

                            Dim terminalMsg As String = ""

                            If hasLastA120Message Then
                                terminalMsg = lastA120Message
                            ElseIf body IsNot Nothing AndAlso body.Length > 0 Then
                                SecsDecoder.TryReadLastAsciiItem(body, 0, terminalMsg)
                            End If

                            ' 메시지가 비어있지 않다면 호스트 터미널 팝업 실행
                            If Not String.IsNullOrEmpty(terminalMsg) AndAlso Not hasLastA120Message Then
                                logger.WriteLog($"[HOST MESSAGE] {terminalMsg}")

                                ' 이전에 만들어 둔 UI 안전 호출 함수로 호스트 터미널 메시지 팝업 트리거
                                ShowErrorPopup($"[호스트 터미널 메시지 수신]{vbCrLf}{vbCrLf}{terminalMsg}")
                            End If

                            ' S10F3은 수신 후 장비가 정상적으로 메시지를 표시했다면, 
                            ' 호스트에게 S10F4 (Terminal Display ACK, 대개 단일 바이너리 B[1] = 0)로 회신을 주는 것이 표준 명세입니다.
                            ' 필요 시 아래와 같이 S10F4 응답 패킷을 자동 송신하도록 구성할 수 있습니다.
                            Dim ackBody As New List(Of Byte)()
                            ackBody.AddRange(EncodeBinary(New Byte() {&H0})) ' ACK = 0 (성공)
                            SendPacket(CreateHeader(10, 4, 0), ackBody.ToArray())
                            logger.WriteLog("[SEND] S10F4 Terminal Display Acknowledge 회신 완료 (ACK=0)")

                        Catch ex As Exception
                            logger.WriteLog($"[ERROR] S10F3 호스트 메시지 처리 중 오류: {ex.Message}")
                        End Try
                    End If
            End Select

        Catch ex As Exception
            ' 통신 최상위 메인 생존 방어선
            logger.WriteLog($"[FATAL ERROR] HandleSecsMessage 치명적 오류: {ex.Message} -> {ex.StackTrace}")
        End Try
    End Sub

    ''' <summary>
    ''' HSMS 표준 규격에 부합하는 10바이트 고유 메시지 헤더 구조를 정밀 조합 반환합니다.
    ''' </summary>
    Private Function CreateHeader(stream As Byte, func As Byte, sType As Byte) As Byte()
        Dim header(9) As Byte

        ' 1. Device ID 인코딩 (2바이트 공간 - 상위/하위 나누어 Big Endian 주입)
        header(0) = CByte((SET_DEVICE_ID >> 8) And &HFF)
        header(1) = CByte(SET_DEVICE_ID And &HFF)

        ' 2. 통신 스트림 번호, 펑션 번호, 메시지 유형 주입
        header(2) = stream
        header(3) = func
        header(4) = 0 ' PType 규격은 표준상 무조건 0 고정
        header(5) = sType

        ' 3. 고유 System Bytes 4바이트 처리 (네트워크 표준 순서 배정)
        ' 매 송신 메시지마다 카운터 일련번호를 1씩 고유 누적 가산합니다.
        SystemBytesCounter += 1

        header(6) = CByte((SystemBytesCounter >> 24) And &HFF)
        header(7) = CByte((SystemBytesCounter >> 16) And &HFF)
        header(8) = CByte((SystemBytesCounter >> 8) And &HFF)
        header(9) = CByte(SystemBytesCounter And &HFF)

        Return header
    End Function

    ''' <summary>
    ''' 완성된 헤더와 바디 정보를 최종 결합하여 4바이트 길이 필드를 동반한 로우 패킷을 소켓에 직접 밀어 넣습니다.
    ''' </summary>
    Private Sub SendPacket(header As Byte(), body As Byte())
        Try
            ' 소켓 정상 생존 유무 가드 코드
            If clientSocket Is Nothing OrElse Not clientSocket.Connected Then Exit Sub

            ' 총 패킷 바디 길이 계산 = 헤더 공간(10바이트) + 바디 내용 크기
            Dim totalLen As UInteger = 10 + CUInt(body.Length)
            Dim lenBytes() As Byte = BitConverter.GetBytes(totalLen)

            ' 엔디안 포맷 바이트 정렬 변환
            If BitConverter.IsLittleEndian Then Array.Reverse(lenBytes)

            ' 전체 최종 송신 바이트 팩 어레이 선언 및 복사 진행
            Dim packet(4 + 10 + body.Length - 1) As Byte
            Array.Copy(lenBytes, 0, packet, 0, 4)
            Array.Copy(header, 0, packet, 4, 10)
            If body.Length > 0 Then Array.Copy(body, 0, packet, 14, body.Length)

            ' 동기 실데이터 소켓 전송
            clientSocket.Send(packet)

            ' [추가] 내가 송신 처리한 패킷의 바이너리 알맹이도 분석 편의를 위해 아스키 트리 형태로 가시화 로그 적재
            If body IsNot Nothing AndAlso body.Length > 0 Then
                Dim stream As Byte = header(2) And &H7F
                Dim func As Byte = header(3)
                Dim parseIndex As Integer = 0
                Dim asciiTree As String = SecsDecoder.DumpToAsciiTree(body, parseIndex)
                logger.WriteLog($"[SEND S{stream}F{func} BODY 아스키 트리]" & Environment.NewLine & asciiTree)
            End If

        Catch ex As Exception
            logger.WriteLog($"[ERROR] Send Fail: {ex.Message}")
        End Try
    End Sub

    ''' <summary>
    ''' 제어 메시지에 대응하는 승인 응답용 패킷 전송용 유틸 단축 함수입니다.
    ''' </summary>
    Private Sub SendControlResponse(sType As Byte, sysBytes As Byte(), body As Byte())
        Try
            Dim header(9) As Byte
            header(0) = &HFF : header(1) = &HFF ' 제어 응답의 Device ID 필드는 상위 표준 규격상 0xFFFF 고정
            header(5) = sType
            Array.Copy(sysBytes, 0, header, 6, 4) ' 상대방이 보냈던 일련번호 그대로 반사 매핑(동기화 핵심)
            SendPacket(header, body)
        Catch
        End Try
    End Sub

    ''' <summary>
    ''' [핵심 5] 작동중인 클라이언트 소켓 세션을 안전하고 확실하게 닫고 사용하던 시스템 자원을 운영체제에 즉시 반납합니다.
    ''' </summary>
    Private Sub DisconnectClient()
        Try
            If clientSocket IsNot Nothing Then
                logger.WriteLog("[SYSTEM] 클라이언트 소켓 자원 해제 진행...")

                ' 연결이 살아있다면 양방향 송수신 통로를 먼저 안전하게 소프트 차단
                If clientSocket.Connected Then
                    clientSocket.Shutdown(SocketShutdown.Both)
                End If

                ' 소켓 커넥션 클로즈
                clientSocket.Close()
                clientSocket = Nothing ' 완전히 비워주어야 'ReceiveCallback' 내부 가드 구문이 정상 반응을 인지함
                logger.WriteLog("[SYSTEM] 소켓 연결이 안전하게 완전히 해제되었습니다.")
            End If
        Catch ex As Exception
            logger.WriteLog($"[ERROR] DisconnectClient 오류: {ex.Message}")
        Finally
            clientSocket = Nothing
            isConnected = False

            ' [신규] 연결 해제 최종 상태를 화면에 반영합니다.
            ' 정상 종료, 예외 종료, T7 Timeout 등 어떤 경로로 DisconnectClient가 호출되어도 동일하게 표시됩니다.
            UpdateLampStatus("DISCONNECTED", Color.White)
        End Try
    End Sub

    ' ============================================================
    ' [RCP_CONFIRM_ENGCODE_HELPER_START]
    ' S7F83 수신 Body에서 ENGCODE만 별도로 읽기 위한 Helper
    ' 기존 SecsDecoder.Parse_S7F83 로직은 건드리지 않기 위해 분리함
    '
    ' 현재 기준:
    '   LOT 상위 정보 블록 내 7번째 ASCII 항목을 ENGCODE로 판단
    '
    ' 실전 프로그램 이식 시:
    '   S7F83 사양서에서 ENGCODE 위치가 다르면
    '   TryReadS7F83EngCode 내부의 Skip 개수만 조정
    ' ============================================================
    Private Function TryReadS7F83EngCode(body As Byte(), ByRef engCode As String) As Boolean
        engCode = ""

        If body Is Nothing OrElse body.Length = 0 Then Return False

        Dim idx As Integer = 0

        Try
            ' 최상위 <L, n> 헤더 skip
            If idx + 1 < body.Length AndAlso ((body(idx) And &HFC) >> 2) = &H0 Then
                idx += 2
            End If

            ' LOT 정보 <L, 12> 헤더 skip
            If idx + 1 < body.Length AndAlso ((body(idx) And &HFC) >> 2) = &H0 Then
                idx += 2
            End If

            ' 1~6번째 LOT 항목 skip
            ' 1: LotID
            ' 2: CstID
            ' 3: RcpID
            ' 4: PrcID
            ' 5: PortID
            ' 6: 예약/기타 항목
            For itemNo As Integer = 1 To 6
                SkipS7F83SimpleItem(body, idx)
            Next

            ' 7번째 항목을 ENGCODE로 읽음
            engCode = ReadS7F83SimpleAscii(body, idx).Trim()

            Return Not String.IsNullOrWhiteSpace(engCode)

        Catch
            engCode = ""
            Return False
        End Try
    End Function

    Private Sub SkipS7F83SimpleItem(body As Byte(), ByRef idx As Integer)
        If body Is Nothing Then Exit Sub
        If idx + 1 >= body.Length Then
            idx = body.Length
            Exit Sub
        End If

        Dim itemLength As Integer = body(idx + 1)
        idx += 2 + itemLength

        If idx > body.Length Then idx = body.Length
    End Sub

    Private Function ReadS7F83SimpleAscii(body As Byte(), ByRef idx As Integer) As String
        If body Is Nothing Then Return ""
        If idx + 1 >= body.Length Then Return ""

        Dim itemType As Byte = CByte((body(idx) And &HFC) >> 2)
        Dim itemLength As Integer = body(idx + 1)

        idx += 2

        If itemType <> &H10 Then Return ""
        If itemLength <= 0 Then Return ""
        If idx + itemLength > body.Length Then Return ""

        Dim value As String = Encoding.ASCII.GetString(body, idx, itemLength)
        idx += itemLength

        Return value
    End Function
    ' ============================================================
    ' [RCP_CONFIRM_ENGCODE_HELPER_END]
    ' ============================================================

End Class

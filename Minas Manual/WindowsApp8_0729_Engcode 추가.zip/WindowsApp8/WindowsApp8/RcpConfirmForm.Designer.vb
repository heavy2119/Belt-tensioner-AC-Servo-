﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RcpConfirmForm
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpLotInfo = New System.Windows.Forms.GroupBox()
        Me.lblGlassCountValue = New System.Windows.Forms.Label()
        Me.lblEngCodeValue = New System.Windows.Forms.Label()
        Me.lblPrcIdValue = New System.Windows.Forms.Label()
        Me.lblPortIdValue = New System.Windows.Forms.Label()
        Me.lblCstIdValue = New System.Windows.Forms.Label()
        Me.lblLotIdValue = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.grpMainRcp = New System.Windows.Forms.GroupBox()
        Me.cboMainRcp = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpGlassRcp = New System.Windows.Forms.GroupBox()
        Me.dgvGlassRcp = New System.Windows.Forms.DataGridView()
        Me.colSlotId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGlsId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colJudge = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSlotRcp = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.grpLotInfo.SuspendLayout()
        Me.grpMainRcp.SuspendLayout()
        Me.grpGlassRcp.SuspendLayout()
        CType(Me.dgvGlassRcp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpLotInfo
        '
        Me.grpLotInfo.Controls.Add(Me.lblGlassCountValue)
        Me.grpLotInfo.Controls.Add(Me.lblEngCodeValue)
        Me.grpLotInfo.Controls.Add(Me.lblPrcIdValue)
        Me.grpLotInfo.Controls.Add(Me.lblPortIdValue)
        Me.grpLotInfo.Controls.Add(Me.lblCstIdValue)
        Me.grpLotInfo.Controls.Add(Me.lblLotIdValue)
        Me.grpLotInfo.Controls.Add(Me.Label7)
        Me.grpLotInfo.Controls.Add(Me.Label6)
        Me.grpLotInfo.Controls.Add(Me.Label5)
        Me.grpLotInfo.Controls.Add(Me.Label4)
        Me.grpLotInfo.Controls.Add(Me.Label3)
        Me.grpLotInfo.Controls.Add(Me.Label2)
        Me.grpLotInfo.Location = New System.Drawing.Point(45, 97)
        Me.grpLotInfo.Name = "grpLotInfo"
        Me.grpLotInfo.Size = New System.Drawing.Size(613, 156)
        Me.grpLotInfo.TabIndex = 0
        Me.grpLotInfo.TabStop = False
        Me.grpLotInfo.Text = "LOT 정보"
        '
        'lblGlassCountValue
        '
        Me.lblGlassCountValue.AutoSize = True
        Me.lblGlassCountValue.Location = New System.Drawing.Point(107, 127)
        Me.lblGlassCountValue.Name = "lblGlassCountValue"
        Me.lblGlassCountValue.Size = New System.Drawing.Size(11, 12)
        Me.lblGlassCountValue.TabIndex = 11
        Me.lblGlassCountValue.Text = "-"
        '
        'lblEngCodeValue
        '
        Me.lblEngCodeValue.AutoSize = True
        Me.lblEngCodeValue.Location = New System.Drawing.Point(107, 106)
        Me.lblEngCodeValue.Name = "lblEngCodeValue"
        Me.lblEngCodeValue.Size = New System.Drawing.Size(11, 12)
        Me.lblEngCodeValue.TabIndex = 10
        Me.lblEngCodeValue.Text = "-"
        '
        'lblPrcIdValue
        '
        Me.lblPrcIdValue.AutoSize = True
        Me.lblPrcIdValue.Location = New System.Drawing.Point(107, 85)
        Me.lblPrcIdValue.Name = "lblPrcIdValue"
        Me.lblPrcIdValue.Size = New System.Drawing.Size(11, 12)
        Me.lblPrcIdValue.TabIndex = 9
        Me.lblPrcIdValue.Text = "-"
        '
        'lblPortIdValue
        '
        Me.lblPortIdValue.AutoSize = True
        Me.lblPortIdValue.Location = New System.Drawing.Point(107, 64)
        Me.lblPortIdValue.Name = "lblPortIdValue"
        Me.lblPortIdValue.Size = New System.Drawing.Size(11, 12)
        Me.lblPortIdValue.TabIndex = 8
        Me.lblPortIdValue.Text = "-"
        '
        'lblCstIdValue
        '
        Me.lblCstIdValue.AutoSize = True
        Me.lblCstIdValue.Location = New System.Drawing.Point(107, 43)
        Me.lblCstIdValue.Name = "lblCstIdValue"
        Me.lblCstIdValue.Size = New System.Drawing.Size(11, 12)
        Me.lblCstIdValue.TabIndex = 7
        Me.lblCstIdValue.Text = "-"
        '
        'lblLotIdValue
        '
        Me.lblLotIdValue.AutoSize = True
        Me.lblLotIdValue.Location = New System.Drawing.Point(107, 22)
        Me.lblLotIdValue.Name = "lblLotIdValue"
        Me.lblLotIdValue.Size = New System.Drawing.Size(11, 12)
        Me.lblLotIdValue.TabIndex = 6
        Me.lblLotIdValue.Text = "-"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(26, 127)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 12)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "GLS 수 :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(26, 106)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(73, 12)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "ENGCODE :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(26, 85)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "PRC ID :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 12)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "PORT :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(26, 43)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 12)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "CST ID :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 12)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "LOT ID :"
        '
        'grpMainRcp
        '
        Me.grpMainRcp.Controls.Add(Me.cboMainRcp)
        Me.grpMainRcp.Controls.Add(Me.Label9)
        Me.grpMainRcp.Location = New System.Drawing.Point(45, 259)
        Me.grpMainRcp.Name = "grpMainRcp"
        Me.grpMainRcp.Size = New System.Drawing.Size(613, 53)
        Me.grpMainRcp.TabIndex = 1
        Me.grpMainRcp.TabStop = False
        Me.grpMainRcp.Text = "Main RCP"
        '
        'cboMainRcp
        '
        Me.cboMainRcp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMainRcp.FormattingEnabled = True
        Me.cboMainRcp.Location = New System.Drawing.Point(102, 14)
        Me.cboMainRcp.Name = "cboMainRcp"
        Me.cboMainRcp.Size = New System.Drawing.Size(92, 20)
        Me.cboMainRcp.TabIndex = 14
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(26, 17)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 12)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Main RCP :"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(589, 593)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(69, 36)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(486, 593)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(69, 36)
        Me.btnOk.TabIndex = 4
        Me.btnOk.Text = "OK"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Location = New System.Drawing.Point(45, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(613, 52)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Check RCP Please!!!"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grpGlassRcp
        '
        Me.grpGlassRcp.Controls.Add(Me.dgvGlassRcp)
        Me.grpGlassRcp.Location = New System.Drawing.Point(45, 318)
        Me.grpGlassRcp.Name = "grpGlassRcp"
        Me.grpGlassRcp.Size = New System.Drawing.Size(613, 269)
        Me.grpGlassRcp.TabIndex = 6
        Me.grpGlassRcp.TabStop = False
        Me.grpGlassRcp.Text = "GLS별 RCP"
        '
        'dgvGlassRcp
        '
        Me.dgvGlassRcp.AllowUserToAddRows = False
        Me.dgvGlassRcp.AllowUserToDeleteRows = False
        Me.dgvGlassRcp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvGlassRcp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvGlassRcp.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colSlotId, Me.colGlsId, Me.colJudge, Me.colSlotRcp})
        Me.dgvGlassRcp.Location = New System.Drawing.Point(28, 31)
        Me.dgvGlassRcp.Name = "dgvGlassRcp"
        Me.dgvGlassRcp.RowHeadersVisible = False
        Me.dgvGlassRcp.RowTemplate.Height = 23
        Me.dgvGlassRcp.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvGlassRcp.Size = New System.Drawing.Size(568, 219)
        Me.dgvGlassRcp.TabIndex = 0
        '
        'colSlotId
        '
        Me.colSlotId.HeaderText = "Slot"
        Me.colSlotId.Name = "colSlotId"
        Me.colSlotId.ReadOnly = True
        '
        'colGlsId
        '
        Me.colGlsId.HeaderText = "GLS ID"
        Me.colGlsId.Name = "colGlsId"
        Me.colGlsId.ReadOnly = True
        '
        'colJudge
        '
        Me.colJudge.HeaderText = "Judge"
        Me.colJudge.Name = "colJudge"
        Me.colJudge.ReadOnly = True
        '
        'colSlotRcp
        '
        Me.colSlotRcp.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.colSlotRcp.HeaderText = "RCP"
        Me.colSlotRcp.Name = "colSlotRcp"
        '
        'RcpConfirmForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(724, 638)
        Me.Controls.Add(Me.grpGlassRcp)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.grpMainRcp)
        Me.Controls.Add(Me.grpLotInfo)
        Me.Name = "RcpConfirmForm"
        Me.Text = "S7F83 RCP 확인 / 변경"
        Me.grpLotInfo.ResumeLayout(False)
        Me.grpLotInfo.PerformLayout()
        Me.grpMainRcp.ResumeLayout(False)
        Me.grpMainRcp.PerformLayout()
        Me.grpGlassRcp.ResumeLayout(False)
        CType(Me.dgvGlassRcp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpLotInfo As GroupBox
    Friend WithEvents grpMainRcp As GroupBox
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnOk As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblGlassCountValue As Label
    Friend WithEvents lblEngCodeValue As Label
    Friend WithEvents lblPrcIdValue As Label
    Friend WithEvents lblPortIdValue As Label
    Friend WithEvents lblCstIdValue As Label
    Friend WithEvents lblLotIdValue As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cboMainRcp As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents grpGlassRcp As GroupBox
    Friend WithEvents dgvGlassRcp As DataGridView
    Friend WithEvents colSlotId As DataGridViewTextBoxColumn
    Friend WithEvents colGlsId As DataGridViewTextBoxColumn
    Friend WithEvents colJudge As DataGridViewTextBoxColumn
    Friend WithEvents colSlotRcp As DataGridViewComboBoxColumn
End Class

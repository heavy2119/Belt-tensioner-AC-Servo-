﻿Imports System.IO
Imports System.Text

Public Class RcpConfirmForm
    Private Class RcpCsvItem
        Public Property HostRcp As String
        Public Property EqpRcp As String

        Public ReadOnly Property DisplayText As String
            Get
                If String.IsNullOrWhiteSpace(EqpRcp) Then Return HostRcp
                Return HostRcp
            End Get
        End Property
    End Class

    Private rcpCsvItems As New List(Of RcpCsvItem)()

    ' ============================================================
    ' [RCP_CONFIRM_FORM_CORE]
    ' S7F83 ENGCODE=1 Operator RCP 확인/변경 전용 Form
    ' CSV 로드, LOT 표시, RCP 변경값 반환 기능은 이 파일에 집중
    ' 실전 프로그램 이식 시 이 Form 파일을 우선 이동
    ' ============================================================

    Private rcpCsvLoaded As Boolean = False

    Private _editedLotData As LotInfoData
    Private _editedGlassList As New List(Of GlassInfoData)()

    Public ReadOnly Property EditedLotData As LotInfoData
        Get
            Return _editedLotData
        End Get
    End Property
    Public ReadOnly Property EditedGlassList As List(Of GlassInfoData)
        Get
            Return New List(Of GlassInfoData)(_editedGlassList)
        End Get
    End Property



    Private Sub RcpConfirmForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        EnsureRcpCsvLoaded()

        ' SetLotData에서 이미 DataSource와 선택값을 설정한 경우,
        ' Load에서 다시 바인딩하면 Main RCP 선택값이 초기화될 수 있으므로 방지합니다.
        If cboMainRcp.DataSource Is Nothing Then
            BindRcpCsvItems()
        End If
    End Sub

    Public Sub SetLotData(lotData As LotInfoData,
                      glassList As List(Of GlassInfoData),
                      engCode As String)



        EnsureRcpCsvLoaded()

        _editedLotData = lotData
        _editedGlassList = New List(Of GlassInfoData)()

        If glassList IsNot Nothing Then
            For Each glass As GlassInfoData In glassList
                _editedGlassList.Add(glass)
            Next
        End If

        lblLotIdValue.Text = If(lotData.LotID, "")
        lblCstIdValue.Text = If(lotData.CstID, "")
        lblPortIdValue.Text = If(lotData.PortID, "")
        lblPrcIdValue.Text = If(lotData.PrcID, "")
        lblEngCodeValue.Text = If(engCode, "")
        lblGlassCountValue.Text = _editedGlassList.Count.ToString()

        EnsureRcpItem(lotData.RcpID)

        For Each glass As GlassInfoData In _editedGlassList
            EnsureRcpItem(glass.SlotRcp)
        Next

        BindRcpCsvItems()

        If Not String.IsNullOrWhiteSpace(lotData.RcpID) Then
            cboMainRcp.SelectedValue = lotData.RcpID
        End If

        dgvGlassRcp.Rows.Clear()

        For Each glass As GlassInfoData In _editedGlassList
            dgvGlassRcp.Rows.Add(
            glass.SlotID,
            glass.GlsID,
            glass.GlsJudge,
            glass.SlotRcp
        )
        Next
    End Sub


    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        ApplySelectedRcpValues()

        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ApplySelectedRcpValues()
        ' Grid에서 ComboBox를 선택한 직후 OK를 누른 경우,
        ' 아직 셀 값이 확정되지 않았을 수 있으므로 먼저 편집을 종료합니다.
        If dgvGlassRcp.IsCurrentCellDirty Then
            dgvGlassRcp.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
        dgvGlassRcp.EndEdit()

        ' Main RCP 반영
        If cboMainRcp.SelectedValue IsNot Nothing Then
            _editedLotData.RcpID = cboMainRcp.SelectedValue.ToString()
        End If

        ' GLS별 RCP 반영
        For Each row As DataGridViewRow In dgvGlassRcp.Rows
            If row.IsNewRow Then Continue For

            Dim slotId As String = Convert.ToString(row.Cells("colSlotId").Value)
            Dim selectedRcp As String = Convert.ToString(row.Cells("colSlotRcp").Value)

            If String.IsNullOrWhiteSpace(slotId) Then Continue For
            If String.IsNullOrWhiteSpace(selectedRcp) Then Continue For

            For i As Integer = 0 To _editedGlassList.Count - 1
                Dim glass As GlassInfoData = _editedGlassList(i)

                If glass.SlotID = slotId Then
                    glass.SlotRcp = selectedRcp

                    ' GlassInfoData는 Structure라서 수정 후 다시 넣어줘야 실제 반영됩니다.
                    _editedGlassList(i) = glass
                    Exit For
                End If
            Next
        Next
    End Sub

    Private Sub dgvGlassRcp_DataError(sender As Object, e As DataGridViewDataErrorEventArgs) Handles dgvGlassRcp.DataError
        ' ComboBox 컬럼 값이 CSV 목록과 일시적으로 맞지 않을 때 폼이 죽지 않도록 방어합니다.
        ' 실제 값 보정은 SetLotData의 EnsureRcpItem에서 처리합니다.
        e.ThrowException = False
    End Sub
    Private Sub EnsureRcpCsvLoaded()
        If rcpCsvLoaded Then Exit Sub

        rcpCsvItems = LoadRcpCsvItems()
        rcpCsvLoaded = True
    End Sub

    Private Sub EnsureRcpItem(rcpValue As String)
        If String.IsNullOrWhiteSpace(rcpValue) Then Exit Sub

        For Each item As RcpCsvItem In rcpCsvItems
            If item.HostRcp.Equals(rcpValue, StringComparison.OrdinalIgnoreCase) Then
                Exit Sub
            End If
        Next

        rcpCsvItems.Add(New RcpCsvItem With {
        .HostRcp = rcpValue,
        .EqpRcp = ""
    })
    End Sub

    Private Function LoadRcpCsvItems() As List(Of RcpCsvItem)
        Dim result As New List(Of RcpCsvItem)()
        Dim csvPath As String = Path.Combine(Application.StartupPath, "RCP.CSV")

        If Not File.Exists(csvPath) Then
            MessageBox.Show($"RCP.CSV 파일을 찾을 수 없습니다.{Environment.NewLine}{csvPath}",
                            "RCP CSV 확인",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Return result
        End If

        Dim seenHostRcps As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
        Dim lines As String() = File.ReadAllLines(csvPath, Encoding.Default)

        For lineNo As Integer = 0 To lines.Length - 1
            Dim line As String = lines(lineNo).Trim()
            If String.IsNullOrWhiteSpace(line) Then Continue For

            Dim parts As String() = line.Split(","c)
            If parts.Length < 2 Then Continue For

            Dim hostRcp As String = CleanCsvValue(parts(0))
            Dim eqpRcp As String = CleanCsvValue(parts(1))

            If lineNo = 0 AndAlso hostRcp.Equals("HOST", StringComparison.OrdinalIgnoreCase) Then
                Continue For
            End If

            If String.IsNullOrWhiteSpace(hostRcp) Then Continue For
            If seenHostRcps.Contains(hostRcp) Then Continue For

            seenHostRcps.Add(hostRcp)
            result.Add(New RcpCsvItem With {
                .HostRcp = hostRcp,
                .EqpRcp = eqpRcp
            })
        Next

        Return result
    End Function

    Private Function CleanCsvValue(value As String) As String
        If value Is Nothing Then Return ""
        Return value.Trim().Trim(""""c)
    End Function

    Private Sub BindRcpCsvItems()
        cboMainRcp.DisplayMember = NameOf(RcpCsvItem.DisplayText)
        cboMainRcp.ValueMember = NameOf(RcpCsvItem.HostRcp)
        cboMainRcp.DataSource = New List(Of RcpCsvItem)(rcpCsvItems)

        Dim rcpColumn As DataGridViewComboBoxColumn = TryCast(dgvGlassRcp.Columns("colSlotRcp"), DataGridViewComboBoxColumn)
        If rcpColumn Is Nothing Then Exit Sub

        rcpColumn.DisplayMember = NameOf(RcpCsvItem.DisplayText)
        rcpColumn.ValueMember = NameOf(RcpCsvItem.HostRcp)
        rcpColumn.DataSource = New List(Of RcpCsvItem)(rcpCsvItems)
    End Sub





End Class
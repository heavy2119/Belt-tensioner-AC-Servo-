﻿Partial Public Class Form1

    ' 방1~방4 LOT 번호 표시용 Label
    Private lblS7F83RoomLot(4) As Label

    Private Sub UpdateRoomLotDisplay()
        SyncLock S7F83RoomLock
            lblRoom1Lot.Text = GetRoomLotDisplayText(1)
            lblRoom2Lot.Text = GetRoomLotDisplayText(2)
            lblRoom3Lot.Text = GetRoomLotDisplayText(3)
            lblRoom4Lot.Text = GetRoomLotDisplayText(4)
        End SyncLock
    End Sub

    Private Function GetRoomLotDisplayText(roomNo As Integer) As String
        Dim targetRoom As S7F83Room = Nothing

        For Each room As S7F83Room In S7F83Rooms
            If room.RoomNo = roomNo Then
                targetRoom = room
                Exit For
            End If
        Next

        If targetRoom Is Nothing Then
            Return $"방{roomNo} : 비어있음"
        End If

        If targetRoom.State = S7F83RoomState.Empty Then
            Return $"방{roomNo} : 비어있음"
        End If

        Dim lotId As String = targetRoom.LotData.LotID
        Dim cstId As String = targetRoom.LotData.CstID
        Dim glsCount As Integer = 0

        If String.IsNullOrWhiteSpace(lotId) Then lotId = "-"
        If String.IsNullOrWhiteSpace(cstId) Then cstId = "-"

        If targetRoom.GlassList IsNot Nothing Then
            glsCount = targetRoom.GlassList.Count
        End If

        Return $"방{roomNo} : LOT={lotId} / CST={cstId} / GLS={glsCount}"
    End Function

    ''' <summary>
    ''' 방1~방4 LOT 번호 표시용 Label을 폼에 자동 생성합니다.
    ''' </summary>
    Private Sub CreateS7F83RoomLotLabels()
        For i As Integer = 1 To 4
            lblS7F83RoomLot(i) = New Label()
            lblS7F83RoomLot(i).Name = $"lblS7F83RoomLot{i}"
            lblS7F83RoomLot(i).Text = $"방{i}: 비어있음"
            lblS7F83RoomLot(i).AutoSize = False
            lblS7F83RoomLot(i).Width = 360
            lblS7F83RoomLot(i).Height = 24
            lblS7F83RoomLot(i).Left = 20
            lblS7F83RoomLot(i).Top = 420 + ((i - 1) * 28)
            lblS7F83RoomLot(i).BorderStyle = BorderStyle.FixedSingle

            Me.Controls.Add(lblS7F83RoomLot(i))
        Next
    End Sub

    ''' <summary>
    ''' 현재 방1~방4 상태를 폼 Label에 표시합니다.
    ''' </summary>
    Private Sub UpdateS7F83RoomDisplay()
        SyncLock S7F83RoomLock
            For i As Integer = 1 To 4
                Dim roomText As String = $"방{i}: 비어있음"

                For Each room As S7F83Room In S7F83Rooms
                    If room.RoomNo = i Then
                        If room.State <> S7F83RoomState.Empty Then
                            roomText = $"방{i}: LOT={room.LotData.LotID} / 상태={room.State.ToString()}"

                            If room.AssignedOutputPortNo > 0 Then
                                roomText &= $" / 출력포트{room.AssignedOutputPortNo}"
                            End If
                        End If

                        Exit For
                    End If
                Next

                If lblS7F83RoomLot(i) IsNot Nothing Then
                    lblS7F83RoomLot(i).Text = roomText
                End If
            Next

            UpdateNextEndTargetDisplay()
        End SyncLock
    End Sub

    Private lblNextEndTarget(4) As Label

    Private Sub CreateNextEndTargetLabels()
        For i As Integer = 1 To 4
            lblNextEndTarget(i) = New Label()
            lblNextEndTarget(i).Text = ""
            lblNextEndTarget(i).AutoSize = False
            lblNextEndTarget(i).Width = 180
            lblNextEndTarget(i).Height = 24
            lblNextEndTarget(i).Left = 390
            lblNextEndTarget(i).Top = 420 + ((i - 1) * 28)
            lblNextEndTarget(i).ForeColor = Color.Red
            lblNextEndTarget(i).Font = New Font(lblNextEndTarget(i).Font, FontStyle.Bold)

            Me.Controls.Add(lblNextEndTarget(i))
        Next
    End Sub


    Private Sub UpdateNextEndTargetDisplay()
        SyncLock S7F83RoomLock
            lblNextEndTarget1.Text = ""
            lblNextEndTarget2.Text = ""
            lblNextEndTarget3.Text = ""
            lblNextEndTarget4.Text = ""

            Dim nextRoom = S7F83Rooms.
                Where(Function(r) r.State <> S7F83RoomState.Empty).
                OrderBy(Function(r) r.SavedOrder).
                FirstOrDefault()

            If nextRoom Is Nothing Then Exit Sub

            If nextRoom.RoomNo = 1 Then
                lblNextEndTarget1.Text = "← 다음 완공 대상"
            ElseIf nextRoom.RoomNo = 2 Then
                lblNextEndTarget2.Text = "← 다음 완공 대상"
            ElseIf nextRoom.RoomNo = 3 Then
                lblNextEndTarget3.Text = "← 다음 완공 대상"
            ElseIf nextRoom.RoomNo = 4 Then
                lblNextEndTarget4.Text = "← 다음 완공 대상"
            End If
        End SyncLock
    End Sub

    ''' <summary>
    ''' Lamp#1의 상태 문구와 배경색을 안전하게 갱신합니다.
    ''' 
    ''' 이 함수는 Socket 수신 콜백, HSMS 제어 메시지 처리, Disconnect 처리 등
    ''' UI 스레드가 아닌 위치에서도 호출될 수 있으므로 InvokeRequired를 사용합니다.
    ''' 
    ''' statusText:
    '''   Lamp에 표시할 상태 문자열입니다.
    '''   예: "", "OFFLINE", "ONLINE", "DISCONNECTED"
    ''' 
    ''' lampColor:
    '''   Lamp에 표시할 배경색입니다.
    '''   예: Color.White, Color.Red, Color.Green
    ''' </summary>
    Private Sub UpdateLampStatus(statusText As String, lampColor As Color)
        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of String, Color)(AddressOf UpdateLampStatus), statusText, lampColor)
        Else
            lblLamp1.Text = statusText
            lblLamp1.BackColor = lampColor
        End If
    End Sub

    ''' <summary>
    ''' 통신 스레드에서 안전하게 에러 팝업창을 띄우기 위한 Invoke 대리자 함수
    ''' </summary>
    Private Sub ShowErrorPopup(message As String)
        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of String)(AddressOf ShowErrorPopup), message)
        Else
            ' 현장 요구사항 반영: 경고 아이콘과 함께 팝업창 생성
            MessageBox.Show(message, "SECS/GEM 통신 오류 알림", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub SetRcpIdText(rcpId As String)
        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of String)(AddressOf SetRcpIdText), rcpId)
        Else
            txtRcpID.Text = If(rcpId, "").Trim()
        End If
    End Sub



    ''' <summary>
    ''' LD GLS Count 값을 지정된 값으로 설정하고 화면 표시값을 갱신합니다.
    ''' 
    ''' 이 함수는 S7F83 파싱 결과, 또는 추후 LD 관련 SECS/GEM 수신 데이터에서
    ''' LD 투입 Glass 수량을 계산한 뒤 호출하는 용도로 사용합니다.
    ''' 
    ''' value:
    '''   화면에 표시할 LD GLS Count 값입니다.
    '''   0보다 작은 값이 들어오면 비정상 값으로 보고 0으로 보정합니다.
    ''' </summary>
    Private Sub SetLDGLSCount(value As Integer)
        If value < 0 Then value = 0

        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of Integer)(AddressOf SetLDGLSCount), value)
        Else
            ldGlsCount = value
            lblLDGLSCount.Text = ldGlsCount.ToString()
        End If
    End Sub



    ''' <summary>
    ''' ULD GLS Count 값을 지정된 값으로 설정하고 화면 표시값을 갱신합니다.
    ''' 
    ''' ULD Count는 주로 PLC Bit 신호 발생 시 IncreaseULDGLSCount 함수로 증가시키지만,
    ''' 초기화 또는 특정 값 보정이 필요할 때 이 함수를 사용할 수 있습니다.
    ''' 
    ''' value:
    '''   화면에 표시할 ULD GLS Count 값입니다.
    '''   0보다 작은 값이 들어오면 비정상 값으로 보고 0으로 보정합니다.
    ''' </summary>
    Private Sub SetULDGLSCount(value As Integer)
        If value < 0 Then value = 0

        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of Integer)(AddressOf SetULDGLSCount), value)
        Else
            uldGlsCount = value
            lblULDGLSCount.Text = uldGlsCount.ToString()
        End If
    End Sub

End Class
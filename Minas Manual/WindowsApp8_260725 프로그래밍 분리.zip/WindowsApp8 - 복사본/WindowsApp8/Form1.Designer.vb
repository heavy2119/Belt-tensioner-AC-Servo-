﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.rtbLog = New System.Windows.Forms.RichTextBox()
        Me.btnOnline = New System.Windows.Forms.Button()
        Me.btnLotStart = New System.Windows.Forms.Button()
        Me.btnLotEnd = New System.Windows.Forms.Button()
        Me.txtCstID = New System.Windows.Forms.TextBox()
        Me.ULDtxtCSTID = New System.Windows.Forms.TextBox()
        Me.btnSendHead = New System.Windows.Forms.Button()
        Me.btnSendStructure = New System.Windows.Forms.Button()
        Me.txtRcpID = New System.Windows.Forms.TextBox()
        Me.lblLamp1 = New System.Windows.Forms.Label()
        Me.lblLDGLSCount = New System.Windows.Forms.Label()
        Me.lblULDGLSCount = New System.Windows.Forms.Label()
        Me.btnTestLDReset = New System.Windows.Forms.Button()
        Me.btnTestULDIncrease = New System.Windows.Forms.Button()
        Me.btnTestULDRST = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.lblRoom1Lot = New System.Windows.Forms.Label()
        Me.lblRoom2Lot = New System.Windows.Forms.Label()
        Me.lblRoom3Lot = New System.Windows.Forms.Label()
        Me.lblRoom4Lot = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.lblNextEndTarget1 = New System.Windows.Forms.Label()
        Me.lblNextEndTarget2 = New System.Windows.Forms.Label()
        Me.lblNextEndTarget3 = New System.Windows.Forms.Label()
        Me.lblNextEndTarget4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'rtbLog
        '
        Me.rtbLog.Location = New System.Drawing.Point(12, 255)
        Me.rtbLog.Name = "rtbLog"
        Me.rtbLog.Size = New System.Drawing.Size(1159, 313)
        Me.rtbLog.TabIndex = 0
        Me.rtbLog.Text = ""
        '
        'btnOnline
        '
        Me.btnOnline.Location = New System.Drawing.Point(12, 12)
        Me.btnOnline.Name = "btnOnline"
        Me.btnOnline.Size = New System.Drawing.Size(75, 23)
        Me.btnOnline.TabIndex = 1
        Me.btnOnline.Text = "btnOnline"
        Me.btnOnline.UseVisualStyleBackColor = True
        '
        'btnLotStart
        '
        Me.btnLotStart.Location = New System.Drawing.Point(105, 12)
        Me.btnLotStart.Name = "btnLotStart"
        Me.btnLotStart.Size = New System.Drawing.Size(75, 23)
        Me.btnLotStart.TabIndex = 2
        Me.btnLotStart.Text = "btnLotStart"
        Me.btnLotStart.UseVisualStyleBackColor = True
        '
        'btnLotEnd
        '
        Me.btnLotEnd.Location = New System.Drawing.Point(206, 12)
        Me.btnLotEnd.Name = "btnLotEnd"
        Me.btnLotEnd.Size = New System.Drawing.Size(75, 23)
        Me.btnLotEnd.TabIndex = 3
        Me.btnLotEnd.Text = "btnLotEnd"
        Me.btnLotEnd.UseVisualStyleBackColor = True
        '
        'txtCstID
        '
        Me.txtCstID.Location = New System.Drawing.Point(315, 12)
        Me.txtCstID.Name = "txtCstID"
        Me.txtCstID.Size = New System.Drawing.Size(205, 21)
        Me.txtCstID.TabIndex = 4
        Me.txtCstID.Text = "LDCSTID"
        '
        'ULDtxtCSTID
        '
        Me.ULDtxtCSTID.Location = New System.Drawing.Point(547, 14)
        Me.ULDtxtCSTID.Name = "ULDtxtCSTID"
        Me.ULDtxtCSTID.Size = New System.Drawing.Size(205, 21)
        Me.ULDtxtCSTID.TabIndex = 5
        Me.ULDtxtCSTID.Text = "ULDCSTID"
        '
        'btnSendHead
        '
        Me.btnSendHead.Location = New System.Drawing.Point(998, 191)
        Me.btnSendHead.Name = "btnSendHead"
        Me.btnSendHead.Size = New System.Drawing.Size(141, 48)
        Me.btnSendHead.TabIndex = 6
        Me.btnSendHead.Text = "헤드만전송 예제"
        Me.btnSendHead.UseVisualStyleBackColor = True
        '
        'btnSendStructure
        '
        Me.btnSendStructure.Location = New System.Drawing.Point(998, 140)
        Me.btnSendStructure.Name = "btnSendStructure"
        Me.btnSendStructure.Size = New System.Drawing.Size(141, 48)
        Me.btnSendStructure.TabIndex = 7
        Me.btnSendStructure.Text = "구조체전송 예제"
        Me.btnSendStructure.UseVisualStyleBackColor = True
        '
        'txtRcpID
        '
        Me.txtRcpID.Location = New System.Drawing.Point(315, 41)
        Me.txtRcpID.Name = "txtRcpID"
        Me.txtRcpID.Size = New System.Drawing.Size(205, 21)
        Me.txtRcpID.TabIndex = 8
        Me.txtRcpID.Text = "RcpID"
        '
        'lblLamp1
        '
        Me.lblLamp1.AutoSize = True
        Me.lblLamp1.Font = New System.Drawing.Font("굴림", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblLamp1.Location = New System.Drawing.Point(1066, 13)
        Me.lblLamp1.Name = "lblLamp1"
        Me.lblLamp1.Size = New System.Drawing.Size(125, 24)
        Me.lblLamp1.TabIndex = 9
        Me.lblLamp1.Text = "HOST상태"
        '
        'lblLDGLSCount
        '
        Me.lblLDGLSCount.AutoSize = True
        Me.lblLDGLSCount.Location = New System.Drawing.Point(949, 25)
        Me.lblLDGLSCount.Name = "lblLDGLSCount"
        Me.lblLDGLSCount.Size = New System.Drawing.Size(90, 12)
        Me.lblLDGLSCount.TabIndex = 10
        Me.lblLDGLSCount.Text = "HOST GLS갯수"
        '
        'lblULDGLSCount
        '
        Me.lblULDGLSCount.AutoSize = True
        Me.lblULDGLSCount.Location = New System.Drawing.Point(949, 74)
        Me.lblULDGLSCount.Name = "lblULDGLSCount"
        Me.lblULDGLSCount.Size = New System.Drawing.Size(104, 12)
        Me.lblULDGLSCount.TabIndex = 11
        Me.lblULDGLSCount.Text = "ULD GLS투입갯수"
        '
        'btnTestLDReset
        '
        Me.btnTestLDReset.Location = New System.Drawing.Point(760, 14)
        Me.btnTestLDReset.Name = "btnTestLDReset"
        Me.btnTestLDReset.Size = New System.Drawing.Size(172, 40)
        Me.btnTestLDReset.TabIndex = 12
        Me.btnTestLDReset.Text = "TEST버튼 LD CST 완료"
        Me.btnTestLDReset.UseVisualStyleBackColor = True
        '
        'btnTestULDIncrease
        '
        Me.btnTestULDIncrease.Location = New System.Drawing.Point(760, 60)
        Me.btnTestULDIncrease.Name = "btnTestULDIncrease"
        Me.btnTestULDIncrease.Size = New System.Drawing.Size(172, 40)
        Me.btnTestULDIncrease.TabIndex = 13
        Me.btnTestULDIncrease.Text = "TEST버튼 ULD GLS RST"
        Me.btnTestULDIncrease.UseVisualStyleBackColor = True
        '
        'btnTestULDRST
        '
        Me.btnTestULDRST.Location = New System.Drawing.Point(760, 106)
        Me.btnTestULDRST.Name = "btnTestULDRST"
        Me.btnTestULDRST.Size = New System.Drawing.Size(172, 40)
        Me.btnTestULDRST.TabIndex = 14
        Me.btnTestULDRST.Text = "TEST버튼 ULD CST 완료"
        Me.btnTestULDRST.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(39, 127)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(172, 40)
        Me.Button1.TabIndex = 15
        Me.Button1.Text = "언로드1 착공"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(39, 191)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(172, 40)
        Me.Button2.TabIndex = 16
        Me.Button2.Text = "언로드2 착공"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'lblRoom1Lot
        '
        Me.lblRoom1Lot.AutoSize = True
        Me.lblRoom1Lot.Location = New System.Drawing.Point(290, 117)
        Me.lblRoom1Lot.Name = "lblRoom1Lot"
        Me.lblRoom1Lot.Size = New System.Drawing.Size(83, 12)
        Me.lblRoom1Lot.TabIndex = 17
        Me.lblRoom1Lot.Text = "방1 : 비어있음"
        '
        'lblRoom2Lot
        '
        Me.lblRoom2Lot.AutoSize = True
        Me.lblRoom2Lot.Location = New System.Drawing.Point(290, 140)
        Me.lblRoom2Lot.Name = "lblRoom2Lot"
        Me.lblRoom2Lot.Size = New System.Drawing.Size(83, 12)
        Me.lblRoom2Lot.TabIndex = 18
        Me.lblRoom2Lot.Text = "방2 : 비어있음"
        '
        'lblRoom3Lot
        '
        Me.lblRoom3Lot.AutoSize = True
        Me.lblRoom3Lot.Location = New System.Drawing.Point(290, 158)
        Me.lblRoom3Lot.Name = "lblRoom3Lot"
        Me.lblRoom3Lot.Size = New System.Drawing.Size(83, 12)
        Me.lblRoom3Lot.TabIndex = 19
        Me.lblRoom3Lot.Text = "방3 : 비어있음"
        '
        'lblRoom4Lot
        '
        Me.lblRoom4Lot.AutoSize = True
        Me.lblRoom4Lot.Location = New System.Drawing.Point(290, 176)
        Me.lblRoom4Lot.Name = "lblRoom4Lot"
        Me.lblRoom4Lot.Size = New System.Drawing.Size(83, 12)
        Me.lblRoom4Lot.TabIndex = 20
        Me.lblRoom4Lot.Text = "방4 : 비어있음"
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(951, 321)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(172, 40)
        Me.Button3.TabIndex = 21
        Me.Button3.Text = "[방1 데이터 삭제]"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(951, 367)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(172, 40)
        Me.Button4.TabIndex = 22
        Me.Button4.Text = "[방2 데이터 삭제]"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(951, 413)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(172, 40)
        Me.Button5.TabIndex = 23
        Me.Button5.Text = "[방3 데이터 삭제]"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(951, 462)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(172, 40)
        Me.Button6.TabIndex = 24
        Me.Button6.Text = "[방4 데이터 삭제]"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'lblNextEndTarget1
        '
        Me.lblNextEndTarget1.AutoSize = True
        Me.lblNextEndTarget1.Location = New System.Drawing.Point(657, 117)
        Me.lblNextEndTarget1.Name = "lblNextEndTarget1"
        Me.lblNextEndTarget1.Size = New System.Drawing.Size(83, 12)
        Me.lblNextEndTarget1.TabIndex = 25
        Me.lblNextEndTarget1.Text = "방1 : 비어있음"
        '
        'lblNextEndTarget2
        '
        Me.lblNextEndTarget2.AutoSize = True
        Me.lblNextEndTarget2.Location = New System.Drawing.Point(657, 140)
        Me.lblNextEndTarget2.Name = "lblNextEndTarget2"
        Me.lblNextEndTarget2.Size = New System.Drawing.Size(83, 12)
        Me.lblNextEndTarget2.TabIndex = 26
        Me.lblNextEndTarget2.Text = "방1 : 비어있음"
        '
        'lblNextEndTarget3
        '
        Me.lblNextEndTarget3.AutoSize = True
        Me.lblNextEndTarget3.Location = New System.Drawing.Point(657, 158)
        Me.lblNextEndTarget3.Name = "lblNextEndTarget3"
        Me.lblNextEndTarget3.Size = New System.Drawing.Size(83, 12)
        Me.lblNextEndTarget3.TabIndex = 27
        Me.lblNextEndTarget3.Text = "방1 : 비어있음"
        '
        'lblNextEndTarget4
        '
        Me.lblNextEndTarget4.AutoSize = True
        Me.lblNextEndTarget4.Location = New System.Drawing.Point(657, 176)
        Me.lblNextEndTarget4.Name = "lblNextEndTarget4"
        Me.lblNextEndTarget4.Size = New System.Drawing.Size(83, 12)
        Me.lblNextEndTarget4.TabIndex = 28
        Me.lblNextEndTarget4.Text = "방1 : 비어있음"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1203, 580)
        Me.Controls.Add(Me.lblNextEndTarget4)
        Me.Controls.Add(Me.lblNextEndTarget3)
        Me.Controls.Add(Me.lblNextEndTarget2)
        Me.Controls.Add(Me.lblNextEndTarget1)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.lblRoom4Lot)
        Me.Controls.Add(Me.lblRoom3Lot)
        Me.Controls.Add(Me.lblRoom2Lot)
        Me.Controls.Add(Me.lblRoom1Lot)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnTestULDRST)
        Me.Controls.Add(Me.btnTestULDIncrease)
        Me.Controls.Add(Me.btnTestLDReset)
        Me.Controls.Add(Me.lblULDGLSCount)
        Me.Controls.Add(Me.lblLDGLSCount)
        Me.Controls.Add(Me.lblLamp1)
        Me.Controls.Add(Me.txtRcpID)
        Me.Controls.Add(Me.btnSendStructure)
        Me.Controls.Add(Me.btnSendHead)
        Me.Controls.Add(Me.ULDtxtCSTID)
        Me.Controls.Add(Me.txtCstID)
        Me.Controls.Add(Me.btnLotEnd)
        Me.Controls.Add(Me.btnLotStart)
        Me.Controls.Add(Me.btnOnline)
        Me.Controls.Add(Me.rtbLog)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rtbLog As RichTextBox
    Friend WithEvents btnOnline As Button
    Friend WithEvents btnLotStart As Button
    Friend WithEvents btnLotEnd As Button
    Friend WithEvents txtCstID As TextBox
    Friend WithEvents ULDtxtCSTID As TextBox
    Friend WithEvents btnSendHead As Button
    Friend WithEvents btnSendStructure As Button
    Friend WithEvents txtRcpID As TextBox
    Friend WithEvents lblLamp1 As Label
    Friend WithEvents lblLDGLSCount As Label
    Friend WithEvents lblULDGLSCount As Label
    Friend WithEvents btnTestLDReset As Button
    Friend WithEvents btnTestULDIncrease As Button
    Friend WithEvents btnTestULDRST As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents lblRoom1Lot As Label
    Friend WithEvents lblRoom2Lot As Label
    Friend WithEvents lblRoom3Lot As Label
    Friend WithEvents lblRoom4Lot As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents lblNextEndTarget1 As Label
    Friend WithEvents lblNextEndTarget2 As Label
    Friend WithEvents lblNextEndTarget3 As Label
    Friend WithEvents lblNextEndTarget4 As Label
End Class

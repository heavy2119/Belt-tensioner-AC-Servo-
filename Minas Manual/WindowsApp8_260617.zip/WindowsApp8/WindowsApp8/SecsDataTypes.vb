﻿Imports System.Text

'새로운 글래스 세부 정보가 사양서에 추가되었을 때
'상단 GlassInfoData 구조체에 변수 이름을 하나 만들고, 
'하단 Parse_S7F83 함수의 가변 항목 추출 반복문(For g = 0 To totalGlassCount - 1) 내부에 gData.새이름 = ReadNextAscii(body, idx).Trim() 
'줄을 순서에 맞게 한 줄 삽입하면 됩니다.

' ============================================================================
' [유지보수 가이드] 통신에 사용하는 데이터 구조체 정의 구역
' 변수 명칭을 바꾸거나 필드를 추가해야 할 때 여기를 수정합니다.
' ============================================================================

''' <summary>
''' 공정 시작/종료 시 사용되는 Lot 레벨의 상위 공통 정보 구조체입니다.
''' </summary>
Public Structure LotInfoData
    Public LotID As String    ' 랏 아이디
    Public CstID As String    ' 카세트(캐리어) 아이디 -> [핵심] Start/End 시점 분기 대상 변수
    Public RcpID As String    ' 레시피(PPID) 아이디
    Public PrcID As String    ' 공정/프로세스 아이디
    Public PortID As String   ' 포트 아이디 (예: "1", "2")
End Structure

''' <summary>
''' 개별 Glass(Slot) 단위의 세부 정보 구조체입니다.
''' </summary>
Public Structure GlassInfoData
    Public SlotID As String    ' 슬롯 번호 (문자열 형태)
    Public GlsID As String     ' 글래스 고유 ID
    Public SCode As Byte()     ' 소트 코드 (바이너리 1바이트 배열)
    Public GlsJudge As String  ' 글래스 판정 등급 (예: "G")
    Public PnlIf As String     ' 패널 정보 인터페이스 필드
    Public SubMdlIf As String  ' 서브 모듈 인터페이스 필드
    Public SlotRcp As String   ' 해당 슬롯 전용 레시피
End Structure


' ============================================================================
' [핵심 엔진 클래스] SECS 바이트 스트림 파싱 및 덤프 처리
' ============================================================================
Public Class SecsDecoder

    ''' <summary>
    ''' [엔진] 수신된 원시 바이트 배열을 로그창에 보기 좋은 SML(Tree) 텍스트 형태로 변환합니다.
    ''' </summary>
    ''' <param name="body">수신된 pure body 바이트 배열</param>
    ''' <param name="index">현재 읽고 있는 바이트 포인터 위치 (ByRef로 실시간 이동)</param>
    ''' <param name="depth">들여쓰기 깊이 (내부 재귀 호출용)</param>
    Public Shared Function DumpToAsciiTree(body As Byte(), ByRef index As Integer, Optional depth As Integer = 1) As String
        ' [방어 코드] 배열이 비어있거나 끝까지 다 읽었다면 조기 종료
        If body Is Nothing OrElse index >= body.Length Then Return ""

        ' 최소 헤더 데이터(Format 1바이트 + Length 1바이트 = 총 2바이트)가 남아있는지 검사
        If index + 1 >= body.Length Then Return New String(" "c, depth * 2) & "[Data Shortage Error]" & Environment.NewLine

        Dim sb As New StringBuilder()
        Dim indent As String = New String(" "c, depth * 2) ' 시각적 계층 구조용 공백(스페이스) 생성

        Try
            ' SECS 헤더 정보 취출
            Dim fmtByte As Byte = body(index)      ' 데이터 타입 정보를 가진 바이트
            Dim lengthByte As Byte = body(index + 1)  ' 뒤따라오는 데이터의 실길이 바이트
            index += 2 ' 헤더 2바이트를 읽었으므로 인덱스 2 전진

            ' 윗 6비트만 추출하여 SECS 데이터 타입 식별 (0x00=List, 0x10=ASCII, 0x08=Binary)
            Dim type As Byte = CByte((fmtByte And &HFC) >> 2)

            Select Case type
                ' ------------------------------------------------------------
                ' CASE A. 리스트 타입 (<L, 개수>) 처리
                ' ------------------------------------------------------------
                Case &H0
                    Dim listCount As Integer = CInt(lengthByte) ' 하위에 포함된 아이템 개수
                    sb.AppendLine($"{indent}<L, {listCount}")

                    ' 리스트 개수만큼 하위 아이템들을 재귀(스스로 호출) 형태로 파싱 진행
                    For i As Integer = 0 To listCount - 1
                        ' 루프 도중 배열 경계를 넘어서는 것을 방지하는 안전장치
                        If index >= body.Length Then
                            sb.AppendLine($"{indent}  [Warning: 빈 리스트 노드 조기 종료]")
                            Exit For
                        End If
                        ' 자기 자신을 다시 호출하여 트리 구조를 아래로 누적시킴
                        sb.Append(DumpToAsciiTree(body, index, depth + 1))
                    Next
                    sb.AppendLine($"{indent}>")

                ' ------------------------------------------------------------
                ' CASE B. 아스키 문자열 타입 (<A, 길이, "값">) 처리
                ' ------------------------------------------------------------
                Case &H10
                    Dim len As Integer = CInt(lengthByte) ' 아스키 문자의 순수 길이
                    Dim value As String = ""

                    If len > 0 Then
                        If index + len <= body.Length Then
                            ' 지정된 길이만큼 인코딩하여 문자열 취출
                            value = Encoding.ASCII.GetString(body, index, len)
                            index += len
                        Else
                            ' [예외 대처] 남은 바이트가 부족하면 깨지지 않도록 남은 만큼만 강제 제한 수신
                            Dim safeLen As Integer = body.Length - index
                            If safeLen > 0 Then value = Encoding.ASCII.GetString(body, index, safeLen)
                            index = body.Length
                        End If
                    End If
                    ' .Trim()을 수행하여 뒤에 붙은 공백 패딩(0x20)을 제거한 순수 데이터만 덤프에 표시
                    sb.AppendLine($"{indent}<A, {len}, ""{value.Trim()}""_>")

                ' ------------------------------------------------------------
                ' CASE C. 바이너리 타입 (<BIN, 길이, 헥사값>) 처리
                ' ------------------------------------------------------------
                Case &H8
                    Dim len As Integer = CInt(lengthByte) ' 바이너리 바이트 수
                    Dim hexStr As String = ""

                    If len > 0 Then
                        If index + len <= body.Length Then
                            Dim binData(len - 1) As Byte
                            Array.Copy(body, index, binData, 0, len)
                            ' 바이트 배열을 보기 좋은 16진수 문자열(예: "01" 또는 "00")로 변환
                            hexStr = BitConverter.ToString(binData).Replace("-", " ")
                            index += len
                        Else
                            ' [예외 대처] 남은 바이트 부족 시 잘림(Truncated) 표시 후 안전 종료
                            Dim safeLen As Integer = body.Length - index
                            If safeLen > 0 Then
                                Dim binData(safeLen - 1) As Byte
                                Array.Copy(body, index, binData, 0, safeLen)
                                hexStr = BitConverter.ToString(binData).Replace("-", " ") & " [Truncated]"
                            End If
                            index = body.Length
                        End If
                    End If
                    sb.AppendLine($"{indent}<BIN, {len}, {hexStr}>")

                    ' ------------------------------------------------------------
                    ' CASE D. 사양서 외 예외 타입 처리
                    ' ------------------------------------------------------------
                Case Else
                    Dim len As Integer = CInt(lengthByte)
                    index += len ' 분석할 수 없으므로 해당 데이터 길이만큼 패스
                    sb.AppendLine($"{indent}<UNK_TYPE, {len}>")
            End Select

        Catch ex As Exception
            ' 내부 파싱 폭탄 방어 로그 기입
            sb.AppendLine($"{indent}[Parsing Inner Error: {ex.Message}]")
        End Try

        Return sb.ToString()
    End Function

    ''' <summary>
    ''' [핵심 비즈니스 로직] 장비가 던진 S7F83 대형 바이트 데이터를 순서대로 잘라내어 구조체 리스트에 정밀 적재합니다.
    ''' </summary>
    ''' <param name="body">장비 수신 바이트 스트림</param>
    ''' <param name="outLot">추출된 Lot 공통 데이터가 담길 구조체 변수 (참조 반환)</param>
    ''' <returns>추출 완료된 Glass 리스트 결과물</returns>
    Public Shared Function Parse_S7F83(body As Byte(), ByRef outLot As LotInfoData) As List(Of GlassInfoData)
        Dim glassList As New List(Of GlassInfoData)()

        ' 1차 데이터 무결성 검사
        If body Is Nothing OrElse body.Length = 0 Then
            Console.WriteLine("[DEBUG] S7F83 수신 바디가 비어있습니다.")
            Return glassList
        End If

        ' --- [원시 바이트 추적 로그 빌더] ---
        Try
            Dim hexBuilder As New System.Text.StringBuilder()
            For Each b As Byte In body
                hexBuilder.Append(b.ToString("X2") & " ")
            Next
            ' 수신된 Hex 모양 그대로 콘솔창 출력 (계측기 대조용 마스터 로그 생성)
            Console.WriteLine($"[RAW_RECEIVE_S7F83] Body Length: {body.Length} Bytes")
            Console.WriteLine($"[RAW_BYTES]: {hexBuilder.ToString()}")
        Catch ex As Exception
            ' 로그 가동 중 오류 유발 방어
        End Try
        ' ---------------------------------

        Dim idx As Integer = 0 ' 바이트 배열의 첫 번째칸(0번 인덱스)부터 순서대로 포인터를 전진시킵니다.

        Try
            ' ----------------------------------------------------------------
            ' [단계 1] 메인 최상위 리스트 구조 확인 및 패스
            ' ----------------------------------------------------------------
            If idx >= body.Length Then Throw New Exception("바이트 부족: 메인 리스트 시작점")
            If (body(idx) And &HFC) >> 2 = &H0 Then idx += 2 ' <L, 2> 헤더 패스

            ' ----------------------------------------------------------------
            ' [단계 2] 상위 LOT 정보 블록 진입 및 순서(Index) 매핑 파싱
            ' ----------------------------------------------------------------
            If idx >= body.Length Then Throw New Exception("바이트 부족: LOT 리스트 헤더")
            If (body(idx) And &HFC) >> 2 = &H0 Then idx += 2 ' <L, 12> 헤더 패스

            ' [유지보수 포인트] 장비 로그의 순서와 100% 매칭되어 순서대로 변수에 바인딩됩니다.
            ' .Trim()을 통해 공백을 지우고 문자열 변수에 깨끗하게 할당합니다.
            outLot.LotID = ReadNextAscii(body, idx).Trim()   ' 1번째 데이터 매핑
            outLot.CstID = ReadNextAscii(body, idx).Trim()   ' 2번째 데이터 매핑
            outLot.RcpID = ReadNextAscii(body, idx).Trim()   ' 3번째 데이터 매핑
            outLot.PrcID = ReadNextAscii(body, idx).Trim()   ' 4번째 데이터 매핑
            outLot.PortID = ReadNextAscii(body, idx).Trim()  ' 5번째 데이터 매핑

            ' 6번째부터 11번째까지는 우리 프로그램에서 사용하지 않는 예약 아이템이므로 건너뜁니다.
            For i As Integer = 6 To 11
                SkipNextItem(body, idx)
            Next
            ' 12번째 데이터 뒤에 붙은 하위 예약 빈 리스트 구조 패스
            SkipNextList(body, idx)

            ' ----------------------------------------------------------------
            ' [단계 3] 가변 Glass 컨테이너 블록 진입
            ' ----------------------------------------------------------------
            ' Glass 리스트를 감싸고 있는 외곽 <L, 1> 통과
            If (body(idx) And &HFC) >> 2 = &H0 Then idx += 2

            ' 실제 가변 글래스 개수가 담겨있는 본문 리스트 <L, 가변개수> 진입
            If (body(idx) And &HFC) >> 2 = &H0 Then
                ' 중요: 두 번째 헤더 바이트(idx+1) 값이 현재 장비에 적재된 '실제 총 글래스 수량'입니다.
                Dim totalGlassCount As Integer = body(idx + 1)
                idx += 2 ' 가변 리스트 헤더 패스

                Console.WriteLine($"[DEBUG_PARSING] 선언된 총 가변항목 갯수(totalGlassCount): {totalGlassCount}개")

                ' 장비가 알려준 글래스 개수만큼 정확하게 반복문을 돌며 상세 슬롯 데이터를 추출합니다.
                For g As Integer = 0 To totalGlassCount - 1
                    If idx >= body.Length Then Exit For

                    ' 개별 Glass 항목이 정상적인 리스트 구조 체계(0x00)인지 검증
                    Dim currentFormat As Byte = CByte((body(idx) And &HFC) >> 2)
                    If currentFormat = &H0 Then
                        idx += 2 ' 개별 슬롯 리스트 헤더 패스

                        Dim gData As New GlassInfoData()
                        ' [유지보수 포인트] 개별 슬롯 구조체 내부 데이터 순서 매핑
                        gData.SlotID = ReadNextAscii(body, idx).Trim()      ' 1. 슬롯번호
                        gData.GlsID = ReadNextAscii(body, idx).Trim()       ' 2. 글래스 ID
                        gData.SCode = ReadNextBinary(body, idx)             ' 3. 소트 코드 (BIN 타입)
                        gData.GlsJudge = ReadNextAscii(body, idx).Trim()    ' 4. 판정 등급
                        gData.PnlIf = ReadNextAscii(body, idx).Trim()       ' 5. 패널 인터페이스
                        gData.SubMdlIf = ReadNextAscii(body, idx).Trim()    ' 6. 서브모듈 인터페이스
                        gData.SlotRcp = ReadNextAscii(body, idx).Trim()     ' 7. 슬롯 레시피

                        ' 데이터 끝자락에 붙어있는 미사용 서브 리스트 2개 안전 스킵
                        SkipNextList(body, idx)
                        SkipNextList(body, idx)

                        ' 콘솔창에 실시간 슬롯 파싱 데이터 트래킹 출력
                        Console.WriteLine($" -> [슬롯 파싱 확인] IDX {g + 1} - SlotID: '{gData.SlotID}', GlsID: '{gData.GlsID}', Judge: '{gData.GlsJudge}'")

                        ' [핵심 필터] 글래스 ID가 비어있지 않은 유효한 슬롯 데이터만 상위 리스트 결과물에 추가합니다.
                        If Not String.IsNullOrEmpty(gData.GlsID) Then
                            glassList.Add(gData)
                        End If
                    Else
                        ' 장비 사양서 포맷 구조와 매칭되지 않고 바이너리가 밀렸을 경우 에러 트리거 분기
                        Throw New Exception($"Glass 인덱스 [{g}]에서 List(0x00)가 아닌 잘못된 Format Byte 발견: 0x{body(idx).ToString("X2")} (현재위치 바이트 인덱스: {idx})")
                    End If
                Next
            End If

        Catch ex As Exception
            ' ★ 크리티컬 디버깅 핵심: 파싱 에러가 발생하면 무조건 어느 항목, 몇 번째 바이트 인덱스에서 터졌는지 기록합니다.
            ' 나중에 통신이 튀면 이 에러 로그의 Idx 번호만 확인하면 원인을 10분 만에 잡을 수 있습니다.
            Dim errLog As String = $"[CRITICAL_PARSE_ERROR] 파싱 중단 위치(Idx): {idx}, 원인: {ex.Message}"
            Console.WriteLine(errLog)
        End Try

        Return glassList
    End Function


    ' ============================================================================
    ' [내부 유틸리티 및 안전 도구용 하부 헬퍼 함수 구역]
    ' 여기는 인덱스를 자동으로 전진시켜 주는 도구들이므로 평소에는 건드릴 필요가 없습니다.
    ' ============================================================================

    ''' <summary>
    ''' 현재 위치의 아스키 문자열 데이터를 읽어온 뒤, 인덱스 포인터를 데이터 길이만큼 뒤로 전진시킵니다.
    ''' </summary>
    Private Shared Function ReadNextAscii(body As Byte(), ByRef idx As Integer) As String
        If idx >= body.Length Then Return ""
        Dim type As Byte = CByte((body(idx) And &HFC) >> 2)
        Dim len As Integer = body(idx + 1)
        idx += 2
        If type = &H10 AndAlso len > 0 AndAlso idx + len <= body.Length Then
            Dim res As String = Encoding.ASCII.GetString(body, idx, len)
            idx += len ' 데이터를 읽은 바이트 크기만큼 다음 읽을 위치 이동
            Return res
        End If
        Return ""
    End Function

    ''' <summary>
    ''' 현재 위치의 순수 바이너리 데이터를 읽어온 뒤, 인덱스 포인터를 데이터 길이만큼 뒤로 전진시킵니다.
    ''' </summary>
    Private Shared Function ReadNextBinary(body As Byte(), ByRef idx As Integer) As Byte()
        If idx >= body.Length Then Return New Byte() {&H0}
        Dim type As Byte = CByte((body(idx) And &HFC) >> 2)
        Dim len As Integer = body(idx + 1)
        idx += 2
        If type = &H8 AndAlso len > 0 AndAlso idx + len <= body.Length Then
            Dim res(len - 1) As Byte
            Array.Copy(body, idx, res, 0, len)
            idx += len ' 데이터를 읽은 바이트 크기만큼 다음 읽을 위치 이동
            Return res
        End If
        Return New Byte() {&H0}
    End Function

    ''' <summary>
    ''' 사용하지 않는 일반 데이터 아이템을 건너뛰고 포인터만 앞으로 전진시킵니다.
    ''' </summary>
    Private Shared Sub SkipNextItem(body As Byte(), ByRef idx As Integer)
        If idx >= body.Length Then Exit Sub
        Dim len As Integer = body(idx + 1)
        idx += 2 + len ' 헤더 2바이트 + 데이터 본문 크기만큼 포인터 강제 패스
    End Sub

    ''' <summary>
    ''' 사용하지 않는 리스트 헤더 구조를 건너뛰고 포인터만 앞으로 전진시킵니다.
    ''' </summary>
    Private Shared Sub SkipNextList(body As Byte(), ByRef idx As Integer)
        If idx >= body.Length Then Exit Sub
        idx += 2 ' 리스트 자체는 본문 데이터가 없으므로 헤더 크기 2바이트만 전진
    End Sub

    ' ----------------------------------------------------------------------------
    '이하 고정 크기 전용 구형 리더 매서드 (하부 유틸리티 호환성 유지용)
    ' ----------------------------------------------------------------------------
    Private Shared Function ReadAscii(body As Byte(), ByRef idx As Integer, defaultLen As Integer) As String
        Try
            Dim len As Integer = CInt(body(idx + 1))
            idx += 2
            If len = 0 Then Return ""
            Dim text As String = Encoding.ASCII.GetString(body, idx, len)
            idx += len
            Return text
        Catch
            idx += (2 + defaultLen)
            Return ""
        End Try
    End Function

    Private Shared Function ReadBinary(body As Byte(), ByRef idx As Integer, defaultLen As Integer) As Byte()
        Try
            Dim len As Integer = CInt(body(idx + 1))
            idx += 2
            If len = 0 Then Return New Byte() {&H0}
            Dim data(len - 1) As Byte
            Array.Copy(body, idx, data, 0, len)
            idx += len
            Return data
        Catch
            idx += (2 + defaultLen)
            Return New Byte() {&H0}
        End Try
    End Function


End Class
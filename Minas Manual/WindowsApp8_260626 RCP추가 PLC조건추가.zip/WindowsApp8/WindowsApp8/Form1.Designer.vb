﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rtbLog = New System.Windows.Forms.RichTextBox()
        Me.btnOnline = New System.Windows.Forms.Button()
        Me.btnLotStart = New System.Windows.Forms.Button()
        Me.btnLotEnd = New System.Windows.Forms.Button()
        Me.txtCstID = New System.Windows.Forms.TextBox()
        Me.ULDtxtCSTID = New System.Windows.Forms.TextBox()
        Me.btnSendHead = New System.Windows.Forms.Button()
        Me.btnSendStructure = New System.Windows.Forms.Button()
        Me.txtRcpID = New System.Windows.Forms.TextBox()
        Me.lblLamp1 = New System.Windows.Forms.Label()
        Me.lblLDGLSCount = New System.Windows.Forms.Label()
        Me.lblULDGLSCount = New System.Windows.Forms.Label()
        Me.btnTestLDReset = New System.Windows.Forms.Button()
        Me.btnTestULDIncrease = New System.Windows.Forms.Button()
        Me.btnTestULDRST = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'rtbLog
        '
        Me.rtbLog.Location = New System.Drawing.Point(12, 255)
        Me.rtbLog.Name = "rtbLog"
        Me.rtbLog.Size = New System.Drawing.Size(1159, 313)
        Me.rtbLog.TabIndex = 0
        Me.rtbLog.Text = ""
        '
        'btnOnline
        '
        Me.btnOnline.Location = New System.Drawing.Point(12, 12)
        Me.btnOnline.Name = "btnOnline"
        Me.btnOnline.Size = New System.Drawing.Size(75, 23)
        Me.btnOnline.TabIndex = 1
        Me.btnOnline.Text = "btnOnline"
        Me.btnOnline.UseVisualStyleBackColor = True
        '
        'btnLotStart
        '
        Me.btnLotStart.Location = New System.Drawing.Point(105, 12)
        Me.btnLotStart.Name = "btnLotStart"
        Me.btnLotStart.Size = New System.Drawing.Size(75, 23)
        Me.btnLotStart.TabIndex = 2
        Me.btnLotStart.Text = "btnLotStart"
        Me.btnLotStart.UseVisualStyleBackColor = True
        '
        'btnLotEnd
        '
        Me.btnLotEnd.Location = New System.Drawing.Point(206, 12)
        Me.btnLotEnd.Name = "btnLotEnd"
        Me.btnLotEnd.Size = New System.Drawing.Size(75, 23)
        Me.btnLotEnd.TabIndex = 3
        Me.btnLotEnd.Text = "btnLotEnd"
        Me.btnLotEnd.UseVisualStyleBackColor = True
        '
        'txtCstID
        '
        Me.txtCstID.Location = New System.Drawing.Point(315, 12)
        Me.txtCstID.Name = "txtCstID"
        Me.txtCstID.Size = New System.Drawing.Size(205, 21)
        Me.txtCstID.TabIndex = 4
        Me.txtCstID.Text = "LDCSTID"
        '
        'ULDtxtCSTID
        '
        Me.ULDtxtCSTID.Location = New System.Drawing.Point(547, 14)
        Me.ULDtxtCSTID.Name = "ULDtxtCSTID"
        Me.ULDtxtCSTID.Size = New System.Drawing.Size(205, 21)
        Me.ULDtxtCSTID.TabIndex = 5
        Me.ULDtxtCSTID.Text = "ULDCSTID"
        '
        'btnSendHead
        '
        Me.btnSendHead.Location = New System.Drawing.Point(998, 191)
        Me.btnSendHead.Name = "btnSendHead"
        Me.btnSendHead.Size = New System.Drawing.Size(141, 48)
        Me.btnSendHead.TabIndex = 6
        Me.btnSendHead.Text = "헤드만전송 예제"
        Me.btnSendHead.UseVisualStyleBackColor = True
        '
        'btnSendStructure
        '
        Me.btnSendStructure.Location = New System.Drawing.Point(998, 140)
        Me.btnSendStructure.Name = "btnSendStructure"
        Me.btnSendStructure.Size = New System.Drawing.Size(141, 48)
        Me.btnSendStructure.TabIndex = 7
        Me.btnSendStructure.Text = "구조체전송 예제"
        Me.btnSendStructure.UseVisualStyleBackColor = True
        '
        'txtRcpID
        '
        Me.txtRcpID.Location = New System.Drawing.Point(315, 41)
        Me.txtRcpID.Name = "txtRcpID"
        Me.txtRcpID.Size = New System.Drawing.Size(205, 21)
        Me.txtRcpID.TabIndex = 8
        Me.txtRcpID.Text = "RcpID"
        '
        'lblLamp1
        '
        Me.lblLamp1.AutoSize = True
        Me.lblLamp1.Font = New System.Drawing.Font("굴림", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.lblLamp1.Location = New System.Drawing.Point(360, 143)
        Me.lblLamp1.Name = "lblLamp1"
        Me.lblLamp1.Size = New System.Drawing.Size(125, 24)
        Me.lblLamp1.TabIndex = 9
        Me.lblLamp1.Text = "HOST상태"
        '
        'lblLDGLSCount
        '
        Me.lblLDGLSCount.AutoSize = True
        Me.lblLDGLSCount.Location = New System.Drawing.Point(949, 25)
        Me.lblLDGLSCount.Name = "lblLDGLSCount"
        Me.lblLDGLSCount.Size = New System.Drawing.Size(90, 12)
        Me.lblLDGLSCount.TabIndex = 10
        Me.lblLDGLSCount.Text = "HOST GLS갯수"
        '
        'lblULDGLSCount
        '
        Me.lblULDGLSCount.AutoSize = True
        Me.lblULDGLSCount.Location = New System.Drawing.Point(949, 74)
        Me.lblULDGLSCount.Name = "lblULDGLSCount"
        Me.lblULDGLSCount.Size = New System.Drawing.Size(104, 12)
        Me.lblULDGLSCount.TabIndex = 11
        Me.lblULDGLSCount.Text = "ULD GLS투입갯수"
        '
        'btnTestLDReset
        '
        Me.btnTestLDReset.Location = New System.Drawing.Point(760, 14)
        Me.btnTestLDReset.Name = "btnTestLDReset"
        Me.btnTestLDReset.Size = New System.Drawing.Size(172, 40)
        Me.btnTestLDReset.TabIndex = 12
        Me.btnTestLDReset.Text = "TEST버튼 LD CST 완료"
        Me.btnTestLDReset.UseVisualStyleBackColor = True
        '
        'btnTestULDIncrease
        '
        Me.btnTestULDIncrease.Location = New System.Drawing.Point(760, 60)
        Me.btnTestULDIncrease.Name = "btnTestULDIncrease"
        Me.btnTestULDIncrease.Size = New System.Drawing.Size(172, 40)
        Me.btnTestULDIncrease.TabIndex = 13
        Me.btnTestULDIncrease.Text = "TEST버튼 ULD GLS RST"
        Me.btnTestULDIncrease.UseVisualStyleBackColor = True
        '
        'btnTestULDRST
        '
        Me.btnTestULDRST.Location = New System.Drawing.Point(760, 106)
        Me.btnTestULDRST.Name = "btnTestULDRST"
        Me.btnTestULDRST.Size = New System.Drawing.Size(172, 40)
        Me.btnTestULDRST.TabIndex = 14
        Me.btnTestULDRST.Text = "TEST버튼 ULD CST 완료"
        Me.btnTestULDRST.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1203, 580)
        Me.Controls.Add(Me.btnTestULDRST)
        Me.Controls.Add(Me.btnTestULDIncrease)
        Me.Controls.Add(Me.btnTestLDReset)
        Me.Controls.Add(Me.lblULDGLSCount)
        Me.Controls.Add(Me.lblLDGLSCount)
        Me.Controls.Add(Me.lblLamp1)
        Me.Controls.Add(Me.txtRcpID)
        Me.Controls.Add(Me.btnSendStructure)
        Me.Controls.Add(Me.btnSendHead)
        Me.Controls.Add(Me.ULDtxtCSTID)
        Me.Controls.Add(Me.txtCstID)
        Me.Controls.Add(Me.btnLotEnd)
        Me.Controls.Add(Me.btnLotStart)
        Me.Controls.Add(Me.btnOnline)
        Me.Controls.Add(Me.rtbLog)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rtbLog As RichTextBox
    Friend WithEvents btnOnline As Button
    Friend WithEvents btnLotStart As Button
    Friend WithEvents btnLotEnd As Button
    Friend WithEvents txtCstID As TextBox
    Friend WithEvents ULDtxtCSTID As TextBox
    Friend WithEvents btnSendHead As Button
    Friend WithEvents btnSendStructure As Button
    Friend WithEvents txtRcpID As TextBox
    Friend WithEvents lblLamp1 As Label
    Friend WithEvents lblLDGLSCount As Label
    Friend WithEvents lblULDGLSCount As Label
    Friend WithEvents btnTestLDReset As Button
    Friend WithEvents btnTestULDIncrease As Button
    Friend WithEvents btnTestULDRST As Button
End Class

﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

' ============================================================================
' [나중에 혼자 보수할 때 봐야 할 5대 핵심 가이드]
' 
' 1. 장비 통신 포트나 대기 모드를 변경해야 할 때:
'    -> 'StartHsmsServer' 함수 내부의 'SET_PORT' 모듈 상수를 확인하세요.
'    -> 현재 IPAddress.Any를 통해 모든 대역의 연결을 수락하는 Passive(서버) 모드입니다.
' 
' 2. 데이터가 쪼개져서 오거나 밀려서 올 때 (패킷 꼬임, 잘림 현상):
'    -> 'ReceiveCallback' 내부의 'streamBuffer'와 'While streamBuffer.Count >= 4' 루프가
'       TCP 특유의 패킷 잘림/뭉침을 규격대로 칼같이 잘라주는 '스트림 커팅 엔진'입니다.
' 
' 3. 현장 로그 명세서나 슬롯 개수가 변경되었을 때:
'    -> 'btnLotEnd_Click'의 'For slotNum As Integer = 1 To 11' 루프를 고치세요.
'    -> 현재 액티브(Active) 장비 정답 로그 규격에 맞춰 빈 슬롯(1~4번)도 공백 자릿수를 
'       정밀 매핑(EncodeAscii)하여 튕기지 않게 방어해 둔 핵심 구역입니다.
' 
' 4. 특정 SECS 메시지(예: S1F1, S2F21 등) 수신 처리를 추가하고 싶을 때:
'    -> 'HandleSecsMessage' 함수 내부의 'Select Case stream' 구문에 Case를 추가하세요.
'    -> 파싱된 데이터는 'SharedGlassList'와 'SharedLotData' 전역 저장소에 안전하게 백업됩니다.
' 
' 5. 프로그램이 종료될 때 소켓이 먹통이 되거나 포트가 묶이는 현상 방지:
'    -> 'DisconnectClient'와 'Form1_FormClosing'에서 소켓을 Shutdown 후 Close하고
'       완벽하게 'Nothing'으로 초기화하여 운영체제 자원을 즉시 반환하도록 처리되어 있습니다.
' ============================================================================

''' <summary>
''' [메인 폼] HSMS Passive 통신 서버 가동, 비동기 소켓 스트림 처리, 
''' 제어 메시지 핸들링 및 유저 시나리오(온라인/LotStart/LotEnd)를 총괄하는 메인 컨트롤러입니다.
''' </summary>
Public Class Form1
    ' --- 의존성 클래스 및 인스턴스 변수 ---
    Private logger As HsmsLogger              ' UI 및 파일 로그 기록용 분리형 로거 객체

    ' --- 네트워크 소켓 엔진 변수 ---
    Private serverSocket As TcpListener       ' 상대방(Active)의 접속을 기다리는 서버 리스너 소켓
    Private clientSocket As Socket            ' 실제 연결이 수립된 클라이언트 세션 소켓
    Private isConnected As Boolean = False     ' 현재 통신 연결 성공 여부 플래그
    Private SystemBytesCounter As UInteger = 1 ' SECS 메시지 동기화용 고유 일련번호 (4바이트 카운터)

    ' --- 타이머 제어 변수 ---
    Private WithEvents tmrT7 As New Timer()   ' T7 타임아웃(연결 후 Select.req 수신 대기 제한 시간) 관리 타이머

    ' --- 전역 공용 백업 저장소 (SecsDataTypes 구조체 연동) ---
    Private SharedLotData As LotInfoData
    Private SharedGlassList As New List(Of GlassInfoData)()

    ' 방1~방4 LOT 번호 표시용 Label
    Private lblS7F83RoomLot(4) As Label

    ' ============================================================================
    ' S7F83 4방 + 출력포트 착공 순서 관리
    ' ============================================================================
    Private Enum S7F83RoomState
        Empty = 0
        WaitingOutputPort = 1
        AssignedToOutputPort = 2
    End Enum

    Private Enum OutputPortState
        Empty = 0
        WaitingS7F83 = 1
        AssignedS7F83 = 2
    End Enum

    Private Class S7F83Room
        Public RoomNo As Integer
        Public State As S7F83RoomState = S7F83RoomState.Empty
        Public AssignedOutputPortNo As Integer = 0

        Public LotData As LotInfoData
        Public GlassList As New List(Of GlassInfoData)

        Public SavedOrder As Integer = 0
        Public SavedAt As DateTime

        Public Sub Clear()
            State = S7F83RoomState.Empty
            AssignedOutputPortNo = 0
            LotData = New LotInfoData()
            GlassList = New List(Of GlassInfoData)()
            SavedOrder = 0
            SavedAt = DateTime.MinValue
        End Sub
    End Class

    Private Class OutputPortWork
        Public PortNo As Integer
        Public State As OutputPortState = OutputPortState.Empty
        Public WaitingOrder As Integer = 0
        Public AssignedRoomNo As Integer = 0

        Public Sub Clear()
            State = OutputPortState.Empty
            WaitingOrder = 0
            AssignedRoomNo = 0
        End Sub
    End Class

    Private S7F83Rooms As New List(Of S7F83Room) From {
    New S7F83Room With {.RoomNo = 1},
    New S7F83Room With {.RoomNo = 2},
    New S7F83Room With {.RoomNo = 3},
    New S7F83Room With {.RoomNo = 4}
}

    Private OutputPorts As New List(Of OutputPortWork) From {
    New OutputPortWork With {.PortNo = 1},
    New OutputPortWork With {.PortNo = 2}
}

    Private S7F83SaveOrder As Integer = 0
    Private OutputPortWaitingOrder As Integer = 0
    Private S7F83RoomLock As New Object()

    ' ============================================================================
    ' [신규] 화면 상태 표시 및 GLS Count 관리 변수
    ' ============================================================================
    ' LD GLS Count 화면 표시용 내부 카운터입니다.
    ' S7F83 등 SECS/GEM 수신 데이터에서 계산된 LD 투입 Glass 수량을 보관합니다.
    ' 화면 표시값과 내부 값을 일치시키기 위해 SetLDGLSCount 함수에서만 변경하는 것을 권장합니다.
    Private ldGlsCount As Integer = 0

    ' ULD GLS Count 화면 표시용 내부 카운터입니다.
    ' 추후 PLC Bit 신호가 들어올 때마다 IncreaseULDGLSCount 함수에서 1씩 증가시킬 예정입니다.
    ' 화면 표시값과 내부 값을 일치시키기 위해 직접 값을 바꾸지 말고 전용 함수를 통해 변경하는 것을 권장합니다.
    Private uldGlsCount As Integer = 0

    ' ============================================================================
    ' [신규] PLC Bit 상태 변화 감지용 변수
    ' ============================================================================
    ' LD CST OFF Bit의 이전 상태를 저장합니다.
    ' PLC Bit가 계속 1로 유지되는 동안 ResetLDGLSCount()가 반복 호출되는 것을 방지하기 위해 사용합니다.
    ' False = 직전 읽기에서 LD CST OFF 조건이 아니었음
    ' True  = 직전 읽기에서 LD CST OFF 조건이었음
    Private previousLDCstOffSignal As Boolean = False

    ''' <summary>
    ''' 폼이 메모리에 로드될 때 발생하는 초기화 이벤트입니다.
    ''' </summary>
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' [방어] 크로스 스레드 예외를 강제 비활성화하여 통신 스레드가 UI를 건드려도 다운되지 않도록 처리
        CheckForIllegalCrossThreadCalls = False

        ' 로거 엔진 초기화 (메인 UI의 rtbLog RichTextBox 컨트롤과 바인딩)
        logger = New HsmsLogger(rtbLog)


        ' [신규] Form 시작 시 Lamp#1을 초기 상태로 표시합니다.
        ' 아직 Host와 Socket 연결이 완료되지 않았으므로 문구는 비워두고 색상은 White로 둡니다.
        UpdateLampStatus("DISCONNECTED", Color.White)


        ' [신규] Form 시작 시 LD GLS Count를 0으로 초기화합니다.
        ' 이후 S7F83 수신 또는 LD CST OFF 조건에 따라 값이 갱신됩니다.
        SetLDGLSCount(0)

        ' [신규] Form 시작 시 ULD GLS Count를 0으로 초기화합니다.
        ' 이후 PLC Bit 신호 또는 ULD CST OFF 조건에 따라 값이 갱신됩니다.
        SetULDGLSCount(0)

        ' [추가] S7F83 방1~방4 LOT 표시창 생성
        CreateS7F83RoomLotLabels()
        UpdateS7F83RoomDisplay()

        ' T7 타이머 제한 시간을 HsmsConfig에 정의된 표준 값(밀리초)으로 셋팅
        tmrT7.Interval = T7_Timeout

        ' [핵심 1] TCP 서버 가동 (Passive Mode 시작)
        StartHsmsServer()
    End Sub

    ''' <summary>
    ''' 서버 소켓을 열고 클라이언트의 비동기 접속 대기 상태를 시작합니다.
    ''' </summary>
    Private Sub StartHsmsServer()
        Try
            ' 내부 모든 네트워크 카드(Any)와 설정된 포트(7000)를 바인딩하여 대기
            serverSocket = New TcpListener(IPAddress.Any, SET_PORT)
            serverSocket.Start()
            logger.WriteLog($"[SYSTEM] HSMS Server Open (Port: {SET_PORT}, Passive Mode)")

            ' 비동기 접속 수락 시작 (대기 상태 중에도 메인 UI가 멈추지 않음)
            serverSocket.BeginAcceptSocket(AddressOf AcceptCallback, Nothing)
        Catch ex As Exception
            logger.WriteLog($"[ERROR] Server Start Fail: {ex.Message}")
        End Try
    End Sub

    ''' <summary>
    ''' 클라이언트가 실제로 접속했을 때 호출되는 비동기 콜백 함수입니다.
    ''' </summary>
    Private Sub AcceptCallback(ar As IAsyncResult)
        Try
            ' 접속한 클라이언트 소켓 세션을 인스턴스에 할당
            clientSocket = serverSocket.EndAcceptSocket(ar)
            isConnected = True
            logger.WriteLog($"[SYSTEM] Client Connected: {clientSocket.RemoteEndPoint.ToString()}")

            ' [신규] Socket 연결은 완료되었지만 아직 Online 승인 상태는 아니므로 OFFLINE으로 표시합니다.
            ' 연결 완료 상태를 작업자에게 명확히 보여주기 위해 Lamp#1을 Red로 표시합니다.
            UpdateLampStatus("OFFLINE", Color.Red)

            ' [HSMS 표준 규격] 연결은 맺어졌으므로, T7 타이머를 가동하여 정해진 시간 내에 Select.req가 오는지 감시 시작
            tmrT7.Start()

            ' 데이터 수신용 버퍼(64KB)를 개설하고 비동기 데이터 수신(Receive) 대기 전송
            Dim buffer(65535) As Byte
            clientSocket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, AddressOf ReceiveCallback, buffer)

            ' 다음 대형 후속 클라이언트 접속을 위해 서버 소켓 접속 수락 대기를 재호출 (멀티 세션 예방 가드)
            serverSocket.BeginAcceptSocket(AddressOf AcceptCallback, Nothing)
        Catch ex As Exception
            logger.WriteLog($"[ERROR] Accept Error: {ex.Message}")
        End Try
    End Sub

    ' TCP 스트림 파편화/뭉침 현상을 완벽 방어하기 위한 바이트 누적 버퍼
    Private streamBuffer As New List(Of Byte)()

    ''' <summary>
    ''' [핵심 2] 소켓을 통해 로우 데이터(바이트)가 들어올 때마다 호출되는 정밀 패킷 정형화 엔진입니다.
    ''' </summary>
    Private Sub ReceiveCallback(ar As IAsyncResult)
        Dim buffer As Byte() = CType(ar.AsyncState, Byte())
        If clientSocket Is Nothing Then Exit Sub

        Try
            ' 소켓으로부터 실제 읽어온 바이트 크기를 반환받음
            Dim bytesRead As Integer = clientSocket.EndReceive(ar)

            ' 상대방이 정상적으로 소켓 연결을 종료(Shutdown)한 경우 0 바이트가 들어옵니다.
            If bytesRead = 0 Then
                logger.WriteLog("[INFO] Active가 연결을 먼저 종료했습니다. (bytesRead = 0)")
                DisconnectClient()
                Exit Sub
            End If

            ' 멀티스레드 환경에서 누적 스트림 버퍼가 꼬이지 않도록 동기화 락(SyncLock)을 겁니다.
            SyncLock streamBuffer
                ' 1. 이번에 새로 들어온 바이트 덩어리를 임시 배열에 복사 후 누적 스트림 버퍼 뒤에 병합
                Dim tempBytes(bytesRead - 1) As Byte
                Array.Copy(buffer, 0, tempBytes, 0, bytesRead)
                streamBuffer.AddRange(tempBytes)

                ' 2. 누적 버퍼 내에서 완전한 패킷 단위(헤더4바이트 크기 기반)로 정밀 컷팅 반복 실행
                While streamBuffer.Count >= 4
                    ' 앞의 4바이트를 복사하여 전체 메시지 길이(MsgLength) 파악 진행
                    Dim msgLenBytes(3) As Byte
                    streamBuffer.CopyTo(0, msgLenBytes, 0, 4)

                    ' 네트워크 표준(Big Endian)에서 C#/.NET 표준(Little Endian) 환경으로 바이트 역전 처리
                    If BitConverter.IsLittleEndian Then Array.Reverse(msgLenBytes)
                    Dim msgLength As UInteger = BitConverter.ToUInt32(msgLenBytes, 0)

                    ' [보안 방어막] 비정상적인 유령 크기(5MB 초과)가 오면 소켓 버퍼 오염으로 간주하고 즉시 초기화하여 좀비 상태 방지
                    If msgLength > 5000000 Then
                        logger.WriteLog($"[SOCKET WARNING] 유령 패킷 크기 감지({msgLength} 바이트). 스트림 리셋을 실시합니다.")
                        streamBuffer.Clear()
                        Exit While
                    End If

                    ' 전체 패킷 실제 크기 = 길이 헤더 공간(4바이트) + 알맹이 데이터 길이(msgLength)
                    Dim totalPacketSize As Integer = CInt(msgLength) + 4

                    ' [완전성 검사] 버퍼에 쌓인 데이터가 계산된 전체 패킷 크기보다 작다면 데이터가 아직 덜 온 것입니다.
                    ' 다음 비동기 데이터가 뒤에 더 붙을 때까지 가공하지 않고 루프를 즉시 탈출합니다. (TCP 파편화 방어 핵심)
                    If streamBuffer.Count < totalPacketSize Then
                        Exit While
                    End If

                    ' 완벽한 패킷 하나가 통째로 다 수집되었으므로 가공 시작
                    Dim packetBytes(totalPacketSize - 1) As Byte
                    streamBuffer.CopyTo(0, packetBytes, 0, totalPacketSize)

                    ' 처리할 분량만큼 누적 버퍼의 앞부분을 완전히 도려내어 인덱스 꼬임을 차단합니다.
                    streamBuffer.RemoveRange(0, totalPacketSize)

                    ' 실제 헤더 10바이트 추출 (앞의 4바이트 길이 정보 스킵한 위치부터 시작)
                    Dim header(9) As Byte
                    Array.Copy(packetBytes, 4, header, 0, 10)

                    Dim sType As Byte = header(5)               ' HSMS 제어 메시지 타입 (0이면 일반 SECS, 1:Select, 5:Linktest 등)
                    Dim stream As Byte = header(2) And &H7F     ' Stream 번호 추출 (W-Bit 최상위 비트 마스킹 제거)
                    Dim func As Byte = header(3)                 ' Function 번호 추출
                    Dim sysBytes(3) As Byte
                    Array.Copy(header, 6, sysBytes, 0, 4)        ' 동기화용 고유 System Bytes 4바이트 추출

                    logger.WriteLog($"[SOCKET STREAM] 패킷 조립 성공 -> S{stream}F{func}, Type: {sType}, 순수Body: {msgLength - 10} bytes")

                    ' 3. 제어 패킷과 데이터 패킷 분기 처리 핸들러 호출
                    If sType <> 0 Then
                        ' HSMS 자체 제어 메시지 처리 구역 (Select, Linktest, Separate)
                        HandleHsmsControl(sType, sysBytes)
                    Else
                        ' 순수 SECS-II 데이터 메시지 처리 구역
                        Dim bodySize As Integer = CInt(msgLength) - 10
                        Dim body() As Byte = New Byte() {}

                        ' 헤더 10바이트를 제외한 데이터 알맹이(Body)가 존재할 경우 바디 배열 적재
                        If bodySize > 0 Then
                            ReDim body(bodySize - 1)
                            Array.Copy(packetBytes, 14, body, 0, bodySize)
                        End If

                        HandleSecsMessage(stream, func, body)
                    End If
                End While
            End SyncLock

            ' 4. 다음 비동기 소켓 데이터 수신 상태로 대기 전환
            If clientSocket IsNot Nothing AndAlso clientSocket.Connected Then
                Dim nextBuffer(65535) As Byte
                clientSocket.BeginReceive(nextBuffer, 0, nextBuffer.Length, SocketFlags.None, AddressOf ReceiveCallback, nextBuffer)
            End If

        Catch ex As Exception
            logger.WriteLog($"[SOCKET CRITICAL] 스트림 동기화 최종 예외: {ex.Message} -> {ex.StackTrace}")
            DisconnectClient()
        End Try
    End Sub

    ''' <summary>
    ''' HSMS 규격 상의 제어 패킷(연결 수락, 링크 테스트 등)을 자동 응답 처리하는 핸들러입니다.
    ''' </summary>
    Private Sub HandleHsmsControl(sType As Byte, sysBytes As Byte())
        Select Case sType
            Case 1 ' Select.req (상대방이 통신 프로세스 시작을 요청함)
                logger.WriteLog("[RECV] HSMS Select.req")
                tmrT7.Stop() ' 연결이 정상 승인되었으므로 T7 타임아웃 타이머 정지

                ' 승인 응답 발송 (Select.rsp, 성공 코드 0,0,0,0 주입)
                SendControlResponse(2, sysBytes, New Byte() {0, 0, 0, 0})
                logger.WriteLog("[SEND] HSMS Select.rsp")

                ' [요구사항 6] 연결 성립 즉시 비즈니스 규격에 맞게 S6F95 (RCSMode = "F") 자동 전송
                Send_S6F95("F")

            Case 5 ' Linktest.req (상대방이 통신 회선 생존 여부를 체크함)
                logger.WriteLog("[RECV] HSMS Linktest.req")
                ' 즉시 응답 패킷 발송 (Linktest.rsp)
                SendControlResponse(6, sysBytes, New Byte() {})
                logger.WriteLog("[SEND] HSMS Linktest.rsp")

            Case 9 ' Separate.req (상대방이 소켓을 완전히 끊겠다고 정중히 통보함)
                logger.WriteLog("[RECV] HSMS Separate.req")
                DisconnectClient()
        End Select
    End Sub

    ''' <summary>
    ''' [핵심 4] 순수 SECS-II 메시지(S1, S6, S7 등) 스트림/펑션을 분기하여 가공하는 비즈니스 핸들러입니다.
    ''' </summary>
    Private Sub HandleSecsMessage(stream As Byte, func As Byte, body As Byte())
        Try
            logger.WriteLog($"[RECV] S{stream}F{func}")

            ' [방어] 디코더 가시화 함수 내부 오류로 전체 통신 루프가 다운되는 현상 완전 방어
            If body IsNot Nothing AndAlso body.Length > 0 Then
                Try
                    Dim parseIndex As Integer = 0
                    Dim asciiTree As String = SecsDecoder.DumpToAsciiTree(body, parseIndex)
                    logger.WriteLog($"[RECV S{stream}F{func} BODY 아스키 트리]" & Environment.NewLine & asciiTree)
                Catch exDecoder As Exception
                    logger.WriteLog($"[ERROR] 디코더 가시화 실패 (S{stream}F{func} 바디 파싱 에러): {exDecoder.Message}")
                End Try
            End If

            Dim lastA120Message As String = ""
            Dim hasLastA120Message As Boolean = False

            If body IsNot Nothing AndAlso body.Length > 0 Then
                Try
                    hasLastA120Message = SecsDecoder.TryReadLastAsciiItem(body, 120, lastA120Message)

                    If hasLastA120Message Then
                        logger.WriteLog($"[A120 MESSAGE] S{stream}F{func} 마지막 ASCII 메시지 수신: {lastA120Message}")
                        ShowErrorPopup($"[장비 회신 오류 메시지 수신]{vbCrLf}S{stream}F{func}{vbCrLf}{vbCrLf}{lastA120Message}")
                    End If
                Catch exA120 As Exception
                    logger.WriteLog($"[ERROR] A120 메시지 감지 실패 (S{stream}F{func}): {exA120.Message}")
                End Try
            End If

            ' 스트림별 기능 상세 분석 분기
            Select Case stream
                Case 1
                    If func = 2 Then ' S1F2 Online Ack 수신 시
                        logger.WriteLog("[RECV] S1F2 Online Ack -> Send S6F95('H')")
                        ' 온라인 승인이 떨어졌으므로 장비 RCS 모드를 "H"로 변경 통보

                        ' [신규] S1F2 응답을 정상 수신했으므로 장비 Online 상태로 판단합니다.
                        ' 작업자 화면의 Lamp#1을 ONLINE / Green 상태로 갱신합니다.
                        UpdateLampStatus("ONLINE", Color.Green)

                        Send_S6F95("H")

                        ' ★ 추가 포인트: S1F74 수신 처리
                    ElseIf func = 74 Then
                        logger.WriteLog("[RECV] S1F74 Structure Data Acknowledge 수신 완료")
                        ' 필요 시 여기에 바디 파싱 로직 연동 (예: SecsDecoder.Parse_S1F74(body))
                    End If

                Case 2
                    ' ★ 추가 포인트: S2F18 수신 처리
                    If func = 18 Then
                        logger.WriteLog("[RECV] S2F18 Date and Time Data (시간 회신) 수신 완료")
                        ' 보통 시간 데이터 <A[12]> 이거나 <A[16]> 구조체 형태로 옴
                    End If

                Case 7
                    If func = 83 Then ' S7F83 데이터 구조체 수신 시 내부 백업 및 메모리 로드 진행
                        logger.WriteLog("[SYSTEM] S7F83 구조체 데이터 내부 메모리 적재 백업 시작...")

                        ' [가시성] 원시 바이트 배열을 분석하기 좋게 16진수 바둑판 헥사 뷰문자열로 정형화 출력
                        Try
                            Dim cleanHexView As String = FormatBytesToHexView(body)
                            logger.WriteLog($"[DEBUG HEX VIEW] S7F83 Body ({body.Length} bytes):" & Environment.NewLine & cleanHexView)
                        Catch : End Try

                        ' 1. 기존 파싱 엔진 엔진을 기동하여 데이터를 임시 리스트에 복사
                        Dim parsedLotData As New LotInfoData()
                        Dim parsedList As List(Of GlassInfoData) = Nothing
                        Try
                            parsedList = SecsDecoder.Parse_S7F83(body, parsedLotData)
                            If Not String.IsNullOrWhiteSpace(parsedLotData.RcpID) Then
                                SetRcpIdText(parsedLotData.RcpID)
                            End If
                        Catch exParse As Exception
                            logger.WriteLog($"[CRITICAL] SecsDecoder.Parse_S7F83 내부 런타임 예외 발생: {exParse.Message}")
                        End Try
                        If parsedList Is Nothing Then
                            logger.WriteLog("[WARNING] S7F83 파싱 결과가 빈 값(Nothing)입니다. 빈 리스트로 처리합니다.")
                            parsedList = New List(Of GlassInfoData)()
                        End If
                        logger.WriteLog($"[SYSTEM] S7F83 파싱 완료! Glass 개수: {parsedList.Count}개")
                        SetLDGLSCount(parsedList.Count)
                        SharedLotData = parsedLotData
                        SharedGlassList = parsedList
                        UpdateRoomLotDisplay()
                        Dim savedOk As Boolean = SaveS7F83ToEmptyRoom(parsedLotData, parsedList)

                        ' =====================================================================
                        ' ★ 핵심 수정 포인트: S7F83 데이터 적재 완료 후 S6F81 연동 자동 전송
                        ' =====================================================================
                        If savedOk Then
                            logger.WriteLog("[SYSTEM] S7F83 데이터 저장 완료 -> 이어서 S6F81 자동 연동 발송을 시작합니다.")

                            Dim targetCstId As String = parsedLotData.CstID
                            If String.IsNullOrEmpty(targetCstId) Then targetCstId = txtCstID.Text
                            If String.IsNullOrEmpty(targetCstId) Then targetCstId = "CSTCST000100"

                            Threading.Thread.Sleep(200)
                            Send_S6F81(targetCstId)
                        Else
                            logger.WriteLog("[WARNING] S7F83 저장 실패로 인해 S6F81 자동 송신은 수행하지 않습니다.")
                        End If

                    End If

                Case 10
                    If func = 3 Then
                        logger.WriteLog("[RECV] S10F3 Terminal Display Single 메시지 수신")

                        Try
                            ' S10F3 표준 구조는 대개 <L, 2> 구조 내부에 [TID(B1)], [TEXT(An)] 가 들어있거나,
                            ' 단순하게 단일 노드로 <A[n], "메시지내용">만 들어오는 경우가 많습니다.
                            ' 안전하게 처리하기 위해 SECS 구조를 파싱하여 마지막 ASCII 문자열만 추출합니다.

                            Dim terminalMsg As String = ""

                            If hasLastA120Message Then
                                terminalMsg = lastA120Message
                            ElseIf body IsNot Nothing AndAlso body.Length > 0 Then
                                SecsDecoder.TryReadLastAsciiItem(body, 0, terminalMsg)
                            End If

                            ' 메시지가 비어있지 않다면 호스트 터미널 팝업 실행
                            If Not String.IsNullOrEmpty(terminalMsg) AndAlso Not hasLastA120Message Then
                                logger.WriteLog($"[HOST MESSAGE] {terminalMsg}")

                                ' 이전에 만들어 둔 UI 안전 호출 함수로 호스트 터미널 메시지 팝업 트리거
                                ShowErrorPopup($"[호스트 터미널 메시지 수신]{vbCrLf}{vbCrLf}{terminalMsg}")
                            End If

                            ' S10F3은 수신 후 장비가 정상적으로 메시지를 표시했다면, 
                            ' 호스트에게 S10F4 (Terminal Display ACK, 대개 단일 바이너리 B[1] = 0)로 회신을 주는 것이 표준 명세입니다.
                            ' 필요 시 아래와 같이 S10F4 응답 패킷을 자동 송신하도록 구성할 수 있습니다.
                            Dim ackBody As New List(Of Byte)()
                            ackBody.AddRange(EncodeBinary(New Byte() {&H0})) ' ACK = 0 (성공)
                            SendPacket(CreateHeader(10, 4, 0), ackBody.ToArray())
                            logger.WriteLog("[SEND] S10F4 Terminal Display Acknowledge 회신 완료 (ACK=0)")

                        Catch ex As Exception
                            logger.WriteLog($"[ERROR] S10F3 호스트 메시지 처리 중 오류: {ex.Message}")
                        End Try
                    End If
            End Select

        Catch ex As Exception
            ' 통신 최상위 메인 생존 방어선
            logger.WriteLog($"[FATAL ERROR] HandleSecsMessage 치명적 오류: {ex.Message} -> {ex.StackTrace}")
        End Try
    End Sub

    ' =========================================================================
    ' UI 버튼 액션 및 고유 송신 패킷 빌드 메커니즘 구역
    ' =========================================================================

    Private Function SaveS7F83ToEmptyRoom(lotData As LotInfoData, glassList As List(Of GlassInfoData)) As Boolean
        SyncLock S7F83RoomLock
            Dim emptyRoom = S7F83Rooms.FirstOrDefault(Function(r) r.State = S7F83RoomState.Empty)

            If emptyRoom Is Nothing Then
                logger.WriteLog("[WARNING] S7F83 저장 실패 - 4개 방이 모두 사용 중입니다. 신규 데이터는 저장하지 않습니다.")
                Return False
            End If

            S7F83SaveOrder += 1

            emptyRoom.LotData = lotData
            emptyRoom.GlassList = New List(Of GlassInfoData)(glassList)
            emptyRoom.SavedOrder = S7F83SaveOrder
            emptyRoom.SavedAt = DateTime.Now
            emptyRoom.State = S7F83RoomState.WaitingOutputPort
            emptyRoom.AssignedOutputPortNo = 0

            logger.WriteLog($"[SYSTEM] S7F83 저장 완료 - 방{emptyRoom.RoomNo}, 순번:{emptyRoom.SavedOrder}, LotID:{lotData.LotID}, Glass:{glassList.Count}")

            UpdateS7F83RoomDisplay()
            MatchWaitingS7F83AndOutputPorts()

            Return True
        End SyncLock
    End Function

    Private Function RegisterOutputPortStart(outputPortNo As Integer) As Boolean
        SyncLock S7F83RoomLock
            Dim targetPort = OutputPorts.FirstOrDefault(Function(p) p.PortNo = outputPortNo)

            If targetPort Is Nothing Then
                logger.WriteLog($"[ERROR] 출력포트 번호 오류: {outputPortNo}")
                Return False
            End If

            If targetPort.State <> OutputPortState.Empty Then
                logger.WriteLog($"[WARNING] 출력포트{outputPortNo} 착공 등록 실패 - 이미 진행 중인 데이터가 있습니다.")
                Return False
            End If

            OutputPortWaitingOrder += 1

            targetPort.State = OutputPortState.WaitingS7F83
            targetPort.WaitingOrder = OutputPortWaitingOrder
            targetPort.AssignedRoomNo = 0

            logger.WriteLog($"[SYSTEM] 출력포트{outputPortNo} 착공 등록 완료 - 착공순번:{targetPort.WaitingOrder}")

            MatchWaitingS7F83AndOutputPorts()

            Return True
        End SyncLock
    End Function

    Private Sub MatchWaitingS7F83AndOutputPorts()
        Dim waitingRoom = S7F83Rooms.
        Where(Function(r) r.State = S7F83RoomState.WaitingOutputPort).
        OrderBy(Function(r) r.SavedOrder).
        FirstOrDefault()

        Dim waitingPort = OutputPorts.
        Where(Function(p) p.State = OutputPortState.WaitingS7F83).
        OrderBy(Function(p) p.WaitingOrder).
        FirstOrDefault()

        While waitingRoom IsNot Nothing AndAlso waitingPort IsNot Nothing
            waitingRoom.State = S7F83RoomState.AssignedToOutputPort
            waitingRoom.AssignedOutputPortNo = waitingPort.PortNo

            waitingPort.State = OutputPortState.AssignedS7F83
            waitingPort.AssignedRoomNo = waitingRoom.RoomNo

            logger.WriteLog($"[SYSTEM] 매칭 완료 - 방{waitingRoom.RoomNo} -> 출력포트{waitingPort.PortNo}, LotID:{waitingRoom.LotData.LotID}")

            waitingRoom = S7F83Rooms.
            Where(Function(r) r.State = S7F83RoomState.WaitingOutputPort).
            OrderBy(Function(r) r.SavedOrder).
            FirstOrDefault()

            waitingPort = OutputPorts.
            Where(Function(p) p.State = OutputPortState.WaitingS7F83).
            OrderBy(Function(p) p.WaitingOrder).
            FirstOrDefault()
        End While

        UpdateS7F83RoomDisplay()
    End Sub

    Private Function GetAssignedRoomForOutputPort(outputPortNo As Integer) As S7F83Room
        SyncLock S7F83RoomLock
            Dim targetPort = OutputPorts.FirstOrDefault(Function(p) p.PortNo = outputPortNo)

            If targetPort Is Nothing Then Return Nothing
            If targetPort.State <> OutputPortState.AssignedS7F83 Then Return Nothing

            Return S7F83Rooms.FirstOrDefault(Function(r) r.RoomNo = targetPort.AssignedRoomNo)
        End SyncLock
    End Function

    Private Sub ClearAfterS6F77(outputPortNo As Integer)
        SyncLock S7F83RoomLock
            Dim targetPort = OutputPorts.FirstOrDefault(Function(p) p.PortNo = outputPortNo)

            If targetPort Is Nothing Then Exit Sub

            Dim roomNo As Integer = targetPort.AssignedRoomNo
            Dim targetRoom = S7F83Rooms.FirstOrDefault(Function(r) r.RoomNo = roomNo)

            If targetRoom IsNot Nothing Then
                logger.WriteLog($"[SYSTEM] S6F77 송신 후 방{targetRoom.RoomNo} 클리어 - 출력포트{outputPortNo}")
                targetRoom.Clear()
            End If

            targetPort.Clear()

            targetPort.Clear()
            UpdateS7F83RoomDisplay()
        End SyncLock
    End Sub

    Private Sub UpdateRoomLotDisplay()
        SyncLock S7F83RoomLock
            lblRoom1Lot.Text = GetRoomLotDisplayText(1)
            lblRoom2Lot.Text = GetRoomLotDisplayText(2)
            lblRoom3Lot.Text = GetRoomLotDisplayText(3)
            lblRoom4Lot.Text = GetRoomLotDisplayText(4)
        End SyncLock
    End Sub

    Private Function GetRoomLotDisplayText(roomNo As Integer) As String
        Dim targetRoom As S7F83Room = Nothing

        For Each room As S7F83Room In S7F83Rooms
            If room.RoomNo = roomNo Then
                targetRoom = room
                Exit For
            End If
        Next

        If targetRoom Is Nothing Then
            Return $"방{roomNo} : 비어있음"
        End If

        If targetRoom.State = S7F83RoomState.Empty Then
            Return $"방{roomNo} : 비어있음"
        End If

        If String.IsNullOrWhiteSpace(targetRoom.LotData.LotID) Then
            Return $"방{roomNo} : 비어있음"
        End If

        Return $"방{roomNo} : {targetRoom.LotData.LotID}"
    End Function

    ''' <summary>
    ''' 방1~방4 LOT 번호 표시용 Label을 폼에 자동 생성합니다.
    ''' </summary>
    Private Sub CreateS7F83RoomLotLabels()
        For i As Integer = 1 To 4
            lblS7F83RoomLot(i) = New Label()
            lblS7F83RoomLot(i).Name = $"lblS7F83RoomLot{i}"
            lblS7F83RoomLot(i).Text = $"방{i}: 비어있음"
            lblS7F83RoomLot(i).AutoSize = False
            lblS7F83RoomLot(i).Width = 360
            lblS7F83RoomLot(i).Height = 24
            lblS7F83RoomLot(i).Left = 20
            lblS7F83RoomLot(i).Top = 420 + ((i - 1) * 28)
            lblS7F83RoomLot(i).BorderStyle = BorderStyle.FixedSingle

            Me.Controls.Add(lblS7F83RoomLot(i))
        Next
    End Sub

    ''' <summary>
    ''' 현재 방1~방4 상태를 폼 Label에 표시합니다.
    ''' </summary>
    Private Sub UpdateS7F83RoomDisplay()
        SyncLock S7F83RoomLock
            For i As Integer = 1 To 4
                Dim roomText As String = $"방{i}: 비어있음"

                For Each room As S7F83Room In S7F83Rooms
                    If room.RoomNo = i Then
                        If room.State <> S7F83RoomState.Empty Then
                            roomText = $"방{i}: LOT={room.LotData.LotID} / 상태={room.State.ToString()}"

                            If room.AssignedOutputPortNo > 0 Then
                                roomText &= $" / 출력포트{room.AssignedOutputPortNo}"
                            End If
                        End If

                        Exit For
                    End If
                Next

                If lblS7F83RoomLot(i) IsNot Nothing Then
                    lblS7F83RoomLot(i).Text = roomText
                End If
            Next
        End SyncLock
    End Sub

    ''' <summary>
    ''' 온라인 요청 버튼 클릭 이벤트입니다. (S1F1 송신)
    ''' </summary>
    Private Sub btnOnline_Click(sender As Object, e As EventArgs) Handles btnOnline.Click
        ' 응답을 요구하므로 Stream 번호 최상위 비트(W-Bit)를 On 처리하여 &H81(S1, W-Bit On)로 생성
        Dim header() As Byte = CreateHeader(&H81, 1, 0)
        SendPacket(header, New Byte() {})
        logger.WriteLog("[SEND] S1F1 Online Request (W-Bit On: 81 01)")
    End Sub

    ''' <summary>
    ''' Lot 시작 이벤트 유저 동작 유도 버튼입니다. (S7F87 송신 및 S6F81 자동 전송)
    ''' </summary>
    Private Sub btnLotStart_Click(sender As Object, e As EventArgs) Handles btnLotStart.Click
        ' [보안 방어] UI 컨트롤 박스 자체가 누락되었거나 공백일 경우의 시스템 다운 완벽 보호
        Dim cstId As String = "CSTCST000100" ' 안전한 기본 디폴트 텍스트 할당

        If txtCstID IsNot Nothing AndAlso Not String.IsNullOrEmpty(txtCstID.Text) Then
            cstId = txtCstID.Text
        End If

        ' SECS 표준 바이너리 인코딩 구조 직접 빌딩 시작
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 7}) ' <L, 7> 리스트 선언
        body.AddRange(EncodeAscii("LCWLCW01", 16))
        body.AddRange(EncodeAscii("LCWLCW0101", 16))
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(EncodeAscii("H", 1))
        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeAscii(cstId, 14))
        body.AddRange(EncodeAscii("A", 1))

        ' Stream 7번 + W-Bit On (&H87) 헤더 조합 후 물리 소켓 전송
        SendPacket(CreateHeader(&H87, 87, 0), body.ToArray())
        logger.WriteLog($"[SEND] S7F87 LotStart Request (W-Bit On: 87 57, CSTID: {cstId.Trim()})")

        ' 현장 시나리오 상의 요구조건에 의거하여 300ms 인터벌을 준 뒤 S6F81 연속 자동 연동 전송 진행
        'Threading.Thread.Sleep(300)
        'end_S6F81(cstId)
    End Sub

    Private TestCompletedOutputPortNo As Integer = 1
    ''' <summary>
    ''' [핵심 3] 수신 적재해 두었던 S7F83 실데이터를 믹싱하여 정답 규격의 S6F77 LotEnd 패킷을 조립 송신합니다.
    ''' </summary>
    Private Sub btnLotEnd_Click(sender As Object, e As EventArgs) Handles btnLotEnd.Click
        Try

            ' TODO: 사용자가 만든 출력포트 완공 신호에 맞게 넣습니다.
            ' 출력포트1 완공이면 1, 출력포트2 완공이면 2
            Dim completedOutputPortNo As Integer = TestCompletedOutputPortNo

            Dim assignedRoom As S7F83Room = GetAssignedRoomForOutputPort(completedOutputPortNo)

            If assignedRoom Is Nothing Then
                logger.WriteLog($"[WARNING] S6F77 송신 실패 - 출력포트{completedOutputPortNo}에 배정된 S7F83 방이 없습니다.")
                Exit Sub
            End If

            SharedLotData = assignedRoom.LotData
            SharedGlassList = New List(Of GlassInfoData)(assignedRoom.GlassList)

            Dim body As New List(Of Byte)()

            ' 1. 최상위 레이어 구조체 리스트 배치 빌딩 <L, 1> 하부 <L, 15>
            body.AddRange(New Byte() {&H1, 15})

            ' 상위 고정 명세 데이터 규격 바인딩 및 정밀 자릿수 패딩 채우기
            body.AddRange(EncodeAscii("H", 1))
            body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
            body.AddRange(EncodeAscii("LCWLCW0101", 16)) '장비 Sub EQP
            body.AddRange(EncodeAscii("", 16))
            body.AddRange(EncodeAscii("N", 1))

            ' [실데이터 믹싱] S7F83 수신 시 메모리에 보관해 둔 필드를 연동 (비어있을 시 디코더 오류 예방 디폴트 매핑)
            ' 변수에 먼저 담아두어 하단 루프 내 유효 슬롯 매핑 시 동일한 값을 사용하도록 합니다.
            Dim lotId As String = If(String.IsNullOrEmpty(SharedLotData.LotID), "LOTIDLOTID00", SharedLotData.LotID)
            body.AddRange(EncodeAscii(lotId, 16))

            'body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.CstID), "CSTCST000100", SharedLotData.CstID), 14))
            body.AddRange(EncodeAscii(ULDtxtCSTID.Text, 14))
            body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.RcpID), "RCPRCP11", SharedLotData.RcpID), 24))
            body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.PrcID), "44444", SharedLotData.PrcID), 8))

            body.AddRange(EncodeAscii("E", 1))
            'body.AddRange(EncodeAscii(If(String.IsNullOrEmpty(SharedLotData.PortID), "1", SharedLotData.PortID), 16))
            body.AddRange(EncodeAscii("2", 16)) 'PortID
            body.AddRange(EncodeAscii("", 2))
            body.AddRange(EncodeAscii("N", 1))
            body.AddRange(New Byte() {&H1, 0}) ' 하부 공백 노드 세트 배치 <L, 0>

            ' 2. Glass 목록 컨테이너 빌딩 구역 (★현장 요구 규격: 무조건 11개 슬롯 세트 형태 고정 유지)
            body.AddRange(New Byte() {&H1, 1})  ' <L, 1>
            body.AddRange(New Byte() {&H1, 11}) ' 총 11개의 루프를 돌며 바디 구조 조립

            ' S7F83 L9의 GLSID 수신 순서를 역순으로 슬롯에 배치 (1번째 -> 11번, 2번째 -> 10번, ...)
            ' ★ 안전 보정: SharedGlassList 내부 데이터 개수가 11개보다 적거나 많을 때의 예외를 방어합니다.
            Dim reversedSlotMap As New Dictionary(Of Integer, GlassInfoData)()
            For i As Integer = 0 To SharedGlassList.Count - 1
                Dim targetSlot As Integer = 11 - i

                ' 만약 데이터가 11개 이상 들어와서 계산된 targetSlot이 1보다 작아지면 바인딩을 스킵하여 방어합니다.
                If targetSlot >= 1 AndAlso targetSlot <= 11 Then
                    Dim mappedGlass As GlassInfoData = SharedGlassList(i)
                    mappedGlass.SlotID = targetSlot.ToString()
                    reversedSlotMap(targetSlot) = mappedGlass
                End If
            Next

            For slotNum As Integer = 1 To 11
                Dim targetGlass As GlassInfoData = Nothing
                Dim hasData As Boolean = False

                If reversedSlotMap.ContainsKey(slotNum) Then
                    targetGlass = reversedSlotMap(slotNum)
                    hasData = True
                End If

                ' 개별 항목 규격 선언 : 진짜 로그 구조 매칭 <L, 12> 구조체 생성
                body.AddRange(New Byte() {&H1, 12})

                If hasData Then
                    ' [Case A] 메모리에 매핑에 성공했던 실제 유효 슬롯 데이터 부위 결합 기입 (5~11번 등)
                    body.AddRange(EncodeAscii(targetGlass.SlotID, 3))     ' <A[3]> 슬롯번호
                    body.AddRange(EncodeAscii(targetGlass.GlsID, 16))     ' <A[16]> GlassID
                    body.AddRange(EncodeBinary(targetGlass.SCode))        ' <B[1]> 바이너리 상태 코드
                    body.AddRange(EncodeAscii(targetGlass.GlsJudge, 2))   ' <A[2]> 판정 문자열
                    body.AddRange(EncodeAscii(targetGlass.PnlIf, 96))     ' <A[96]> Panel 정보
                    body.AddRange(EncodeAscii(targetGlass.SubMdlIf, 96))  ' <A[96]> SubMdl 정보
                    body.AddRange(EncodeAscii(targetGlass.SlotRcp, 24))   ' <A[24]> 레시피 명칭
                Else
                    ' [Case B] 빈 슬롯 공백 부위 (1~4번 등) - 정답 로그 매세 규격 원본 준수
                    body.AddRange(EncodeAscii(slotNum.ToString(), 3))     ' <A[3]> 슬롯 번호 강제 대입
                    body.AddRange(EncodeAscii("", 16))                    ' <A[16]> 공백 문자열
                    body.AddRange(EncodeBinary(New Byte() {&H0}))         ' <B[1]> 0x00 바이너리
                    body.AddRange(EncodeAscii("", 2))                     ' <A[2]> 공백
                    body.AddRange(EncodeAscii("", 96))                    ' <A[96]> 공백
                    body.AddRange(EncodeAscii("", 96))                    ' <A[96]> 공백
                    body.AddRange(EncodeAscii("", 24))                    ' <A[24]> 공백
                End If

                ' 개별 슬롯 구조 하단부 트리 고정 규격 양식 강제 생성부 복사 조립
                body.AddRange(EncodeAscii("0", 1))
                body.AddRange(EncodeAscii("2", 1))

                ' =====================================================================
                ' ★ 핵심 수정 포인트 반영 구역
                ' 매핑에 성공한 실제 유효 슬롯(hasData = True)에만 S7F83에서 받아온 LotID를 기입합니다.
                ' =====================================================================
                If hasData Then
                    body.AddRange(EncodeAscii(lotId, 16)) ' 상단에서 가져온 유효 LotID 주입
                Else
                    body.AddRange(EncodeAscii("0", 16))   ' 데이터가 없는 빈 슬롯은 기존 원본과 동일하게 "0" 처리
                End If
                ' =====================================================================

                body.AddRange(New Byte() {&H1, 0})  ' <L, 0>
                'body.AddRange(New Byte() {&H1, 1})  ' <L, 1>
                body.AddRange(New Byte() {&H1, 0})  ' <L, 0>
            Next

            ' 조립 완성된 최종 대형 로우 바이너리 팩을 전송 (S6F77 헤더 장착)
            SendPacket(CreateHeader(&H86, 77, 0), body.ToArray())
            logger.WriteLog($"[SEND] S6F77 LotEnd 정답 규격 패킷 전송 성공 (출력포트:{completedOutputPortNo}, 방:{assignedRoom.RoomNo}, LotID:{lotId})")

            ClearAfterS6F77(completedOutputPortNo)

        Catch ex As Exception
            logger.WriteLog($"[ERROR] btnLotEnd_Click 런타임 예외 발생: {ex.Message}")
        End Try
    End Sub
    Private Sub btnSendHead_Click(sender As Object, e As EventArgs) Handles btnSendHead.Click
        Try
            logger.WriteLog("[SEND] S2F17 Date and Time Request 송신 시작...")

            ' S2F17은 보통 바디가 비어있거나(<L, 0>) 명세에 따라 다름. 여기서는 빈 바디로 세팅
            Dim body As New List(Of Byte)()

            ' Stream 2, Function 17 (W-Bit On: &H82) 헤더 장착 후 전송
            SendPacket(CreateHeader(&H82, 17, 0), body.ToArray())
            logger.WriteLog("[SEND] S2F17 Date and Time Request 전송 완료 (W-Bit On)")
        Catch ex As Exception
            logger.WriteLog($"[ERROR] btnSendHead_Click 예외 발생: {ex.Message}")
        End Try
    End Sub


    ' [구조체전송] 버튼 클릭 시 - S1F73 송신
    ' HandleSecsMessage에 회신받을 S1F74을 추가해야함
    Private Sub btnSendStructure_Click(sender As Object, e As EventArgs) Handles btnSendStructure.Click
        Try
            logger.WriteLog("[SEND] S1F73 Structure Data 전송 시작...")

            Dim body As New List(Of Byte)()

            ' 최상위 <L, 3>
            body.AddRange(New Byte() {&H1, 3})

            ' 1. <A[1], "H"> [RCS]
            body.AddRange(EncodeAscii("H", 1))

            ' 2. <A[16], "LCWLCW01"> [EQP]
            body.AddRange(EncodeAscii("LCWLCW01", 16))

            ' 3. <L, 1> [Port 개수, 여기서는 n=1로 고정 예시]
            body.AddRange(New Byte() {&H1, 1})

            ' 하부 포트 구조체 <L, 3>
            body.AddRange(New Byte() {&H1, 3})

            ' 3-1. <A[16], "LCWLCW0101"> [MACHINE]
            body.AddRange(EncodeAscii("LCWLCW0101", 16))

            ' 3-2. <A[16], ""> [UNITID] 공백 패딩
            body.AddRange(EncodeAscii("", 16))

            ' 3-3. <L, 0> 하부 공백 노드
            body.AddRange(New Byte() {&H1, 0})

            ' Stream 1, Function 73 (W-Bit On: &H81) 헤더 장착 후 전송
            SendPacket(CreateHeader(&H81, 73, 0), body.ToArray())
            logger.WriteLog("[SEND] S1F73 Structure 패킷 전송 완료 (W-Bit On)")
        Catch ex As Exception
            logger.WriteLog($"[ERROR] btnSendStructure_Click 예외 발생: {ex.Message}")
        End Try
    End Sub

    ' =========================================================================
    ' 하부 로우레벨 제어/송신 패킷 빌더 래핑 유틸리티
    ' =========================================================================

    ''' <summary>
    ''' 장비 제어 권한 모드 전환 이벤트를 호스트에 던집니다. (S6F95 송신)
    ''' </summary>
    Private Sub Send_S6F95(rcsMode As String)
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 5})
        body.AddRange(EncodeAscii(rcsMode, 1))
        body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
        body.AddRange(EncodeAscii("LCWLCW0101", 16)) ''장비 Sub EQP
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(New Byte() {&H1, 1})
        body.AddRange(New Byte() {&H1, 3})
        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeAscii("E", 1))
        body.AddRange(EncodeBinary(New Byte() {&H1}))

        ' 헤더를 W-Bit 가 활성화된 0x86 (Stream6, W-Bit On) 형식으로 정상 보정 송신
        SendPacket(CreateHeader(&H86, 95, 0), body.ToArray())
        logger.WriteLog($"[SEND] S6F95 RCS Msg Sent (W-Bit On: 86 5F, Mode: {rcsMode})")
    End Sub

    ''' <summary>
    ''' 카세트 투입 인식 이벤트를 연동 송신합니다. (S6F81 송신)
    ''' </summary>
    Private Sub Send_S6F81(cstId As String)
        Dim body As New List(Of Byte)()
        body.AddRange(New Byte() {&H1, 12})
        body.AddRange(EncodeAscii("H", 1))
        body.AddRange(EncodeAscii("LCWLCW01", 16))  '장비 Main EQP
        body.AddRange(EncodeAscii("LCWLCW0101", 16)) ''장비 Sub EQP
        body.AddRange(EncodeAscii("", 16))
        body.AddRange(EncodeAscii("N", 1))
        body.AddRange(EncodeAscii(cstId, 14))

        ' [보정 완료] 기존 하드코딩 구역을 수신 보관 중이던 실데이터 레시피 아이디와 안전하게 바인딩 처리 완료
        body.AddRange(EncodeAscii(SharedLotData.RcpID, 24))

        body.AddRange(EncodeAscii("1", 16))
        body.AddRange(EncodeBinary(New Byte() {&H0}))
        body.AddRange(EncodeAscii(SharedLotData.LotID, 16))
        body.AddRange(EncodeAscii("P", 1))
        body.AddRange(EncodeAscii("", 2))

        ' Stream 6번 + W-Bit On (&H86) 조합 전송
        SendPacket(CreateHeader(&H86, 81, 0), body.ToArray())
        logger.WriteLog($"[SEND] S6F81 Msg Sent (W-Bit On: 86 51)")
    End Sub

    ''' <summary>
    ''' HSMS 표준 규격에 부합하는 10바이트 고유 메시지 헤더 구조를 정밀 조합 반환합니다.
    ''' </summary>
    Private Function CreateHeader(stream As Byte, func As Byte, sType As Byte) As Byte()
        Dim header(9) As Byte

        ' 1. Device ID 인코딩 (2바이트 공간 - 상위/하위 나누어 Big Endian 주입)
        header(0) = CByte((SET_DEVICE_ID >> 8) And &HFF)
        header(1) = CByte(SET_DEVICE_ID And &HFF)

        ' 2. 통신 스트림 번호, 펑션 번호, 메시지 유형 주입
        header(2) = stream
        header(3) = func
        header(4) = 0 ' PType 규격은 표준상 무조건 0 고정
        header(5) = sType

        ' 3. 고유 System Bytes 4바이트 처리 (네트워크 표준 순서 배정)
        ' 매 송신 메시지마다 카운터 일련번호를 1씩 고유 누적 가산합니다.
        SystemBytesCounter += 1

        header(6) = CByte((SystemBytesCounter >> 24) And &HFF)
        header(7) = CByte((SystemBytesCounter >> 16) And &HFF)
        header(8) = CByte((SystemBytesCounter >> 8) And &HFF)
        header(9) = CByte(SystemBytesCounter And &HFF)

        Return header
    End Function

    ''' <summary>
    ''' 완성된 헤더와 바디 정보를 최종 결합하여 4바이트 길이 필드를 동반한 로우 패킷을 소켓에 직접 밀어 넣습니다.
    ''' </summary>
    Private Sub SendPacket(header As Byte(), body As Byte())
        Try
            ' 소켓 정상 생존 유무 가드 코드
            If clientSocket Is Nothing OrElse Not clientSocket.Connected Then Exit Sub

            ' 총 패킷 바디 길이 계산 = 헤더 공간(10바이트) + 바디 내용 크기
            Dim totalLen As UInteger = 10 + CUInt(body.Length)
            Dim lenBytes() As Byte = BitConverter.GetBytes(totalLen)

            ' 엔디안 포맷 바이트 정렬 변환
            If BitConverter.IsLittleEndian Then Array.Reverse(lenBytes)

            ' 전체 최종 송신 바이트 팩 어레이 선언 및 복사 진행
            Dim packet(4 + 10 + body.Length - 1) As Byte
            Array.Copy(lenBytes, 0, packet, 0, 4)
            Array.Copy(header, 0, packet, 4, 10)
            If body.Length > 0 Then Array.Copy(body, 0, packet, 14, body.Length)

            ' 동기 실데이터 소켓 전송
            clientSocket.Send(packet)

            ' [추가] 내가 송신 처리한 패킷의 바이너리 알맹이도 분석 편의를 위해 아스키 트리 형태로 가시화 로그 적재
            If body IsNot Nothing AndAlso body.Length > 0 Then
                Dim stream As Byte = header(2) And &H7F
                Dim func As Byte = header(3)
                Dim parseIndex As Integer = 0
                Dim asciiTree As String = SecsDecoder.DumpToAsciiTree(body, parseIndex)
                logger.WriteLog($"[SEND S{stream}F{func} BODY 아스키 트리]" & Environment.NewLine & asciiTree)
            End If

        Catch ex As Exception
            logger.WriteLog($"[ERROR] Send Fail: {ex.Message}")
        End Try
    End Sub

    ''' <summary>
    ''' 제어 메시지에 대응하는 승인 응답용 패킷 전송용 유틸 단축 함수입니다.
    ''' </summary>
    Private Sub SendControlResponse(sType As Byte, sysBytes As Byte(), body As Byte())
        Try
            Dim header(9) As Byte
            header(0) = &HFF : header(1) = &HFF ' 제어 응답의 Device ID 필드는 상위 표준 규격상 0xFFFF 고정
            header(5) = sType
            Array.Copy(sysBytes, 0, header, 6, 4) ' 상대방이 보냈던 일련번호 그대로 반사 매핑(동기화 핵심)
            SendPacket(header, body)
        Catch
        End Try
    End Sub

    ''' <summary>
    ''' 일반 문자열(String) 데이터를 SECS 표준 구조 아스키 형태[0x41] 바이트 배열로 자동 인코딩합니다.
    ''' </summary>
    Private Function EncodeAscii(txt As String, len As Integer) As Byte()
        ' [★ 런타임 에러 완전 방어] 인자로 넘어온 데이터 문자열이 Nothing(Null)일 경우에도 
        ' .PadRight 함수 호출에서 시스템이 다운되지 않도록 공백 문자로 자동 안전 우회 변환
        If txt Is Nothing Then txt = ""

        ' 지정된 전체 고정 길이에 도달할 때까지 우측에 빈 공백 패딩 주입
        Dim raw() As Byte = Encoding.ASCII.GetBytes(txt.PadRight(len))

        ' SECS 데이터 포맷 식별자 [0x41 = ASCII 타입]와 길이값을 헤드로 삽입하여 결합 반환
        Dim res As New List(Of Byte) From {&H41, CByte(len And &HFF)}
        res.AddRange(raw)
        Return res.ToArray()
    End Function

    ''' <summary>
    ''' 순수 바이트 배열을 SECS 표준 구조 바이너리 형태[0x21] 바이트 배열로 인코딩합니다.
    ''' </summary>
    Private Function EncodeBinary(data As Byte()) As Byte()
        ' SECS 데이터 포맷 식별자 [0x21 = BINARY 타입]
        Dim res As New List(Of Byte) From {&H21, CByte(data.Length And &HFF)}
        res.AddRange(data)
        Return res.ToArray()
    End Function

    ''' <summary>
    ''' 연결 수립 후 일정 시간(T7) 동안 무반응 방치 시 클라이언트를 강제 강등 탈퇴시키는 타이머 틱 이벤트입니다.
    ''' </summary>
    Private Sub tmrT7_Tick(sender As Object, e As EventArgs) Handles tmrT7.Tick
        logger.WriteLog("[TIMEOUT] T7 Timeout! No Select.req.")
        DisconnectClient()
    End Sub

    ''' <summary>
    ''' [핵심 5] 작동중인 클라이언트 소켓 세션을 안전하고 확실하게 닫고 사용하던 시스템 자원을 운영체제에 즉시 반납합니다.
    ''' </summary>
    Private Sub DisconnectClient()
        Try
            If clientSocket IsNot Nothing Then
                logger.WriteLog("[SYSTEM] 클라이언트 소켓 자원 해제 진행...")

                ' 연결이 살아있다면 양방향 송수신 통로를 먼저 안전하게 소프트 차단
                If clientSocket.Connected Then
                    clientSocket.Shutdown(SocketShutdown.Both)
                End If

                ' 소켓 커넥션 클로즈
                clientSocket.Close()
                clientSocket = Nothing ' 완전히 비워주어야 'ReceiveCallback' 내부 가드 구문이 정상 반응을 인지함
                logger.WriteLog("[SYSTEM] 소켓 연결이 안전하게 완전히 해제되었습니다.")
            End If
        Catch ex As Exception
            logger.WriteLog($"[ERROR] DisconnectClient 오류: {ex.Message}")
        Finally
            clientSocket = Nothing
            isConnected = False

            ' [신규] 연결 해제 최종 상태를 화면에 반영합니다.
            ' 정상 종료, 예외 종료, T7 Timeout 등 어떤 경로로 DisconnectClient가 호출되어도 동일하게 표시됩니다.
            UpdateLampStatus("DISCONNECTED", Color.White)
        End Try
    End Sub

    ''' <summary>
    ''' 윈도우 폼 창이 완전히 닫히기 직전 실행되는 파괴자 성격의 이벤트 함수입니다.
    ''' </summary>
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' 실행 중이던 하부 통신 채널 자원 및 활성화된 파일 스트림을 순차적으로 완전 격리 소멸 처리 진행
        DisconnectClient()
        If serverSocket IsNot Nothing Then serverSocket.Stop()
        If logger IsNot Nothing Then logger.CloseFile()
    End Sub

    ''' <summary>
    ''' 로우 바이트 배열 데이터를 우측 아스키 창을 제외한 순수 16진수 바둑판 헥사(Hex) 뷰 꼴로 깔끔하게 문자열 변환합니다.
    ''' </summary>
    Private Shared Function FormatBytesToHexView(bytes As Byte()) As String
        If bytes Is Nothing OrElse bytes.Length = 0 Then Return "No Data"

        Dim sb As New System.Text.StringBuilder()
        Dim lineLength As Integer = 16 ' 가로 가독성 한계선인 16바이트 정렬

        For i As Integer = 0 To bytes.Length - 1 Step lineLength
            ' 1. 좌측 오프셋 인덱스 번호 마킹 (예: 00000020:)
            sb.Append(i.ToString("X8") & ": ")

            ' 2. 16바이트 가로 배열 나열 실행
            For j As Integer = 0 To lineLength - 1
                If (i + j) < bytes.Length Then
                    sb.Append(bytes(i + j).ToString("X2") & " ")
                Else
                    sb.Append("   ") ' 데이터가 마감되어 채워지지 못한 빈 슬롯 공간 정렬용 공백 확보
                End If
            Next

            sb.AppendLine()
        Next

        Return sb.ToString()
    End Function

    ''' <summary>
    ''' 통신 스레드에서 안전하게 에러 팝업창을 띄우기 위한 Invoke 대리자 함수
    ''' </summary>
    Private Sub ShowErrorPopup(message As String)
        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of String)(AddressOf ShowErrorPopup), message)
        Else
            ' 현장 요구사항 반영: 경고 아이콘과 함께 팝업창 생성
            MessageBox.Show(message, "SECS/GEM 통신 오류 알림", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub SetRcpIdText(rcpId As String)
        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of String)(AddressOf SetRcpIdText), rcpId)
        Else
            txtRcpID.Text = If(rcpId, "").Trim()
        End If
    End Sub

    ''' <summary>
    ''' Lamp#1의 상태 문구와 배경색을 안전하게 갱신합니다.
    ''' 
    ''' 이 함수는 Socket 수신 콜백, HSMS 제어 메시지 처리, Disconnect 처리 등
    ''' UI 스레드가 아닌 위치에서도 호출될 수 있으므로 InvokeRequired를 사용합니다.
    ''' 
    ''' statusText:
    '''   Lamp에 표시할 상태 문자열입니다.
    '''   예: "", "OFFLINE", "ONLINE", "DISCONNECTED"
    ''' 
    ''' lampColor:
    '''   Lamp에 표시할 배경색입니다.
    '''   예: Color.White, Color.Red, Color.Green
    ''' </summary>
    Private Sub UpdateLampStatus(statusText As String, lampColor As Color)
        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of String, Color)(AddressOf UpdateLampStatus), statusText, lampColor)
        Else
            lblLamp1.Text = statusText
            lblLamp1.BackColor = lampColor
        End If
    End Sub

    ''' <summary>
    ''' LD GLS Count 값을 지정된 값으로 설정하고 화면 표시값을 갱신합니다.
    ''' 
    ''' 이 함수는 S7F83 파싱 결과, 또는 추후 LD 관련 SECS/GEM 수신 데이터에서
    ''' LD 투입 Glass 수량을 계산한 뒤 호출하는 용도로 사용합니다.
    ''' 
    ''' value:
    '''   화면에 표시할 LD GLS Count 값입니다.
    '''   0보다 작은 값이 들어오면 비정상 값으로 보고 0으로 보정합니다.
    ''' </summary>
    Private Sub SetLDGLSCount(value As Integer)
        If value < 0 Then value = 0

        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of Integer)(AddressOf SetLDGLSCount), value)
        Else
            ldGlsCount = value
            lblLDGLSCount.Text = ldGlsCount.ToString()
        End If
    End Sub

    ''' <summary>
    ''' LD GLS Count를 0으로 초기화하고 화면 표시값도 0으로 갱신합니다.
    ''' 
    ''' 추후 LD CST 신호가 OFF 되는 조건을 구현할 때,
    ''' 해당 조건문 내부에서 이 함수를 호출하면 됩니다.
    ''' 
    ''' 현재 요청 범위에서는 LD CST OFF 판정 로직은 작성하지 않고,
    ''' 외부에서 호출 가능한 리셋 함수만 준비합니다.
    ''' </summary>
    Private Sub ResetLDGLSCount()
        SetLDGLSCount(0)
    End Sub


    ''' <summary>
    ''' ULD GLS Count 값을 지정된 값으로 설정하고 화면 표시값을 갱신합니다.
    ''' 
    ''' ULD Count는 주로 PLC Bit 신호 발생 시 IncreaseULDGLSCount 함수로 증가시키지만,
    ''' 초기화 또는 특정 값 보정이 필요할 때 이 함수를 사용할 수 있습니다.
    ''' 
    ''' value:
    '''   화면에 표시할 ULD GLS Count 값입니다.
    '''   0보다 작은 값이 들어오면 비정상 값으로 보고 0으로 보정합니다.
    ''' </summary>
    Private Sub SetULDGLSCount(value As Integer)
        If value < 0 Then value = 0

        If Me.InvokeRequired Then
            Me.Invoke(New Action(Of Integer)(AddressOf SetULDGLSCount), value)
        Else
            uldGlsCount = value
            lblULDGLSCount.Text = uldGlsCount.ToString()
        End If
    End Sub


    ''' <summary>
    ''' ULD GLS Count를 1 증가시키고 화면 표시값을 갱신합니다.
    ''' 
    ''' 추후 PLC Bit 신호가 1회 발생할 때마다 이 함수를 한 번 호출하면 됩니다.
    ''' 예: PLC Bit Rising Edge 감지 시 IncreaseULDGLSCount()
    ''' 
    ''' 실제 PLC Bit 판정 로직은 이 함수에 넣지 않습니다.
    ''' 이 함수는 "이미 신호가 발생했다고 판단된 후" 호출되는 카운트 증가 전용 함수입니다.
    ''' </summary>
    Private Sub IncreaseULDGLSCount()
        SetULDGLSCount(uldGlsCount + 1)
    End Sub



    ''' <summary>
    ''' [테스트 버튼] LD CST OFF 조건을 수동으로 발생시켜 LD GLS Count Reset 동작을 확인합니다.
    ''' 실제 운영에서는 PLC Bit 조건 성립 시 HandleLDCstOffDetected("PLC ...")를 호출합니다.
    ''' </summary>
    Private Sub btnTestLDReset_Click(sender As Object, e As EventArgs) Handles btnTestLDReset.Click
        HandleLDCstOffDetected("TEST BUTTON")
    End Sub

    ''' <summary>
    ''' LD CST OFF 조건이 실제로 발생했을 때 실행할 공통 처리 함수입니다.
    ''' 
    ''' 이 함수는 테스트 버튼에서도 호출하고,
    ''' 추후 PLC Bit 조건이 성립했을 때도 동일하게 호출합니다.
    ''' 
    ''' sourceText:
    '''   이 처리가 어디서 발생했는지 로그에 남기기 위한 문자열입니다.
    '''   예: "TEST BUTTON", "PLC M1"
    ''' </summary>
    Private Sub HandleLDCstOffDetected(sourceText As String)
        ResetLDGLSCount()
        If logger IsNot Nothing Then
            logger.WriteLog($"[{sourceText}] LD CST OFF 감지 -> LD GLS Count Reset")
        End If
    End Sub


    ''' <summary>
    ''' PLC에서 읽어온 LD CST OFF Bit 상태를 처리합니다.
    ''' 
    ''' currentLDCstOffSignal:
    '''   PLC에서 현재 읽은 LD CST OFF 조건 상태입니다.
    '''   True  = LD CST OFF 조건 성립
    '''   False = LD CST OFF 조건 미성립
    ''' 
    ''' 중요:
    '''   PLC Bit가 1인 동안 계속 Reset이 반복되지 않도록,
    '''   False -> True로 바뀌는 순간에만 HandleLDCstOffDetected()를 호출합니다.
    ''' </summary>
    Private Sub ProcessLDCstOffSignal(currentLDCstOffSignal As Boolean)
        If previousLDCstOffSignal = False AndAlso currentLDCstOffSignal = True Then
            HandleLDCstOffDetected("PLC 접점")
        End If
        previousLDCstOffSignal = currentLDCstOffSignal
    End Sub


    '==========================================================================================================================================
    '아래 코드처럼 추가 할것.

    '6. 왜 If mValues(1) = 1 Then Reset...만 쓰면 안 좋은가
    '이렇게 쓰면

    '    If mValues(1) = 1 Then
    '    ResetLDGLSCount()
    'End If
    'PLC M1이 1로 유지되는 동안 UpdateLabels()가 호출될 때마다 계속 Reset됩니다.

    '예를 들어 Timer가 100ms마다 돈다면:

    'M1 = 1 유지
    '0.1초마다 Reset
    '0.1초마다 로그 기록
    '0.1초마다 화면 갱신
    '그래서 반드시 “처음 1이 되는 순간”만 잡는 게 좋습니다.

    'If previousLDCstOffSignal = False AndAlso currentLDCstOffSignal = True Then
    '    HandleLDCstOffDetected("PLC M1")
    'End If
    '이게 바로 Rising Edge 처리입니다.

    '======================================================================================================================================================
    'PLC에 UpdataLables()세부에다가, DIm .. 아래를 추가할것.

    'Private Sub UpdateLabels() 
    'Dim currentLDCstOffSignal As Boolean = (mValues(1) = 1)
    'ProcessLDCstOffSignal(currentLDCstOffSignal)
    '    Next













    ''' <summary>
    ''' [테스트 버튼] PLC Bit Rising Edge가 1회 발생한 상황을 수동으로 테스트합니다.
    ''' 
    ''' 실제 PLC Bit 신호 판정 로직은 추후 별도로 구현할 예정이므로,
    ''' 현재 버튼은 PLC Bit가 OFF에서 ON으로 1회 변했다고 가정하고
    ''' IncreaseULDGLSCount()만 호출합니다.
    ''' 
    ''' 테스트 결과:
    '''   - 내부 uldGlsCount 값이 1 증가합니다.
    '''   - 화면의 ULD GLS Count 표시값도 증가된 값으로 갱신됩니다.
    ''' </summary>
    Private Sub btnTestULDIncrease_Click(sender As Object, e As EventArgs) Handles btnTestULDIncrease.Click
        IncreaseULDGLSCount()
        If logger IsNot Nothing Then
            logger.WriteLog("[TEST] PLC Bit Rising Edge 테스트 버튼 클릭 -> ULD GLS Count +1")
        End If
    End Sub



    ''' <summary>
    ''' ULD GLS Count를 0으로 초기화하고 화면 표시값도 0으로 갱신합니다.
    ''' 
    ''' 추후 ULD CST 신호가 OFF 되는 조건을 구현할 때,
    ''' 해당 조건문 내부에서 이 함수를 호출하면 됩니다.
    ''' 
    ''' 현재 요청 범위에서는 ULD CST OFF 판정 로직은 작성하지 않고,
    ''' 외부에서 호출 가능한 리셋 함수만 준비합니다.
    ''' </summary>
    ''' 
    Private Sub btnTestULDRST_Click(sender As Object, e As EventArgs) Handles btnTestULDRST.Click
        SetULDGLSCount(0)
        If logger IsNot Nothing Then
            logger.WriteLog("[TEST] PLC Bit ULD CST OFF 테스트 버튼 클릭 -> ULD CST OFF")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        RegisterOutputPortStart(1)
        TestCompletedOutputPortNo = 1
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RegisterOutputPortStart(2)
        TestCompletedOutputPortNo = 2
    End Sub
End Class
﻿Imports System.IO
Imports System.Text

' ============================================================================
' [나중에 혼자 보수할 때 봐야 할 3대 핵심 가이드]
' 
' 1. 로그 파일이 저장되는 위치(경로)를 바꾸고 싶을 때:
'    -> 하단의 'WriteToFile' 함수 내부에 있는 [Dim logDir As String = ...] 줄을 고치세요.
'    -> 예: Dim logDir As String = "D:\MyLogs" 형태로 바꾸면 D드라이브에 저장됩니다.
' 
' 2. 화면의 로그가 자꾸 지워져서 1000줄보다 더 길게 보고 싶을 때:
'    -> 하단의 'UpdateUiLog' 함수 내부에 있는 [If _rtb.Lines.Length > 1000 Then] 줄을 고치세요.
'    -> 숫자를 5000이나 10000으로 늘리면 이전 로그가 화면에 훨씬 오래 유지됩니다.
' 
' 3. 로그가 물리 파일에 즉시 저장되지 않고 누락되는 느낌이 들 때:
'    -> 본 클래스는 데이터가 들어올 때마다 '_fileWriter.Flush()'를 강제로 호출하여
'       버퍼에 머물지 않고 즉시 하드디스크에 쓰도록 완벽히 방어되어 있으니 안심하셔도 됩니다.
' ============================================================================

''' <summary>
''' [엔진] 통신 및 설비의 모든 이벤트를 UI 화면과 텍스트 파일에 기록하는 로깅 엔진입니다.
''' 화면 멈춤(Freeze) 방지를 위한 스레드 안전 처리와 메모리 과부하 방지 로직이 포함되어 있습니다.
''' </summary>
Public Class HsmsLogger
    ' --- 내부 관리용 변수 구역 ---
    Private _rtb As RichTextBox              ' 로그를 표시할 메인 화면의 RichTextBox 컨트롤 저장소
    Private _currentLogDate As String = ""   ' 현재 로그를 쓰고 있는 일자 정보 (날짜 변경 감지용: "20260614")
    Private _fileWriter As StreamWriter      ' 파일에 텍스트를 밀어 넣는 스트림 객체

    ''' <summary>
    ''' [생성자] 메인 화면(Form)이 켜질 때 화면의 RichTextBox를 연동하여 가져옵니다.
    ''' </summary>
    ''' <param name="targetRichTextBox">메인 UI에 배치된 로그 출력용 RichTextBox 이름</param>
    Public Sub New(targetRichTextBox As RichTextBox)
        _rtb = targetRichTextBox
    End Sub

    ''' <summary>
    ''' [외부 호출 메인 매서드] 프로그램 전체에서 로그를 남기고 싶을 때 무조건 이 함수를 호출합니다.
    ''' (예: Logger.WriteLog("S7F87 송신 성공"))
    ''' </summary>
    ''' <param name="msg">기록할 로그 본문 내용</param>
    Public Sub WriteLog(msg As String)
        ' 밀리초(.fff) 단위까지 칼같이 타임스탬프를 생성합니다. (장비 통신 트래킹 필수 조건)
        Dim timestamp As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")
        Dim fullMsg As String = $"[{timestamp}] {msg}"

        ' 1. 메인 UI 화면(RichTextBox) 출력 처리 (크로스 스레드 방어)
        If _rtb IsNot Nothing Then
            If _rtb.InvokeRequired Then
                _rtb.Invoke(Sub() UpdateUiLog(fullMsg))
            Else
                UpdateUiLog(fullMsg)
            End If
        End If

        ' 2. 일자별 하드디스크 텍스트 파일 저장 처리
        WriteToFile(fullMsg)
    End Sub

    ''' <summary>
    ''' [UI 전용 내부 함수] 화면 텍스트 박스에 로그 문자열을 누적하고 스크롤을 맨 아래로 내립니다.
    ''' </summary>
    Private Sub UpdateUiLog(msg As String)
        _rtb.AppendText(msg & Environment.NewLine)

        ' [핵심 포인트 2] 메모리 보호를 위해 1000줄 넘으면 화면을 초기화 (필요시 이 숫자를 조정)
        If _rtb.Lines.Length > 1000 Then _rtb.Clear()

        ' 로그가 추가될 때마다 스크롤바를 맨 아래로 강제 자동 이동시킵니다.
        _rtb.SelectionStart = _rtb.TextLength
        _rtb.ScrollToCaret()
    End Sub

    ''' <summary>
    ''' [파일 I/O 내부 함수] 프로그램 실행 폴더 내 "Logs" 폴더에 일자별로 파일을 분리하여 저장합니다.
    ''' </summary>
    Private Sub WriteToFile(msg As String)
        Try
            Dim todayStr As String = DateTime.Now.ToString("yyyyMMdd")

            ' 자정이 지나 날짜가 바뀌면 새 파일을 생성하는 로직
            If todayStr <> _currentLogDate Then
                CloseFile() ' 기존에 열려있던 어제 날짜 파일 스트림을 닫아줍니다.

                ' [핵심 포인트 1] 실행 폴더 내 "Logs" 하위 폴더 경로 생성 (필요시 고정 경로로 변경 가능)
                Dim logDir As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs")

                ' Logs 폴더가 하드디스크에 없다면 자동으로 폴더를 만들어 줍니다.
                If Not Directory.Exists(logDir) Then Directory.CreateDirectory(logDir)

                ' 최종 로그 파일 명칭 정의 (예: Logs\HSMS_LOG_20260614.txt)
                Dim logPath As String = Path.Combine(logDir, $"HSMS_LOG_{todayStr}.txt")

                ' 파일을 이어서 쓰기(Append: True) 모드로 열고, UTF-8 인코딩 적용
                _fileWriter = New StreamWriter(logPath, True, Encoding.UTF8)
                _currentLogDate = todayStr ' 현재 기록중인 날짜 갱신
            End If

            ' 실제 파일에 텍스트를 기입하고 하드디스크에 완전 물리 저장(Flush)
            If _fileWriter IsNot Nothing Then
                _fileWriter.WriteLine(msg)
                ' [핵심 포인트 3] 즉시 물리 저장(Flush)을 수행하여 데이터 유실을 방지합니다.
                _fileWriter.Flush()
            End If
        Catch
            ' 파일 쓰기 중 발생하는 예외로 인해 프로그램 전체가 죽는 것을 완벽 방어
        End Try
    End Sub

    ''' <summary>
    ''' [자원 해제] 프로그램이 종료되거나 날짜가 바뀔 때, 점유 중인 파일 스트림을 완전히 닫아줍니다.
    ''' </summary>
    Public Sub CloseFile()
        If _fileWriter IsNot Nothing Then
            Try
                _fileWriter.Flush()
                _fileWriter.Close()
                _fileWriter.Dispose()
            Catch
            Finally
                _fileWriter = Nothing
            End Try
        End If
    End Sub
End Class